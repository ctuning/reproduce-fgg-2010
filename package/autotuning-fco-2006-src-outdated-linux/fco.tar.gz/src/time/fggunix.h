//
// Functions for Linux (Converting from Windows)
//
// Copyright (C) 2000-2004 by Grigori G.Fursin
//
// http://homepages.inf.ed.ac.uk/gfursin
//
// ICSA, School of Informatics,
// University of Edinburgh, UK
//

#if !defined(FGGUNIX_INCLUDED_)
#define FGGUNIX_INCLUDED_ 

char* strlwr(char*);

#endif
