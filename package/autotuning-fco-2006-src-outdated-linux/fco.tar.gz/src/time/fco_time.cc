/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "param.h"

#include "global.h"
#include "clparse.h"

#include <string.h>

#include <fstream.h>
#include <iostream.h>

#include <stdlib.h>
#ifndef W32
#  include <sys/resource.h> //for cpu usage
#endif
#include <time.h>

int main(int argc, char* argv[])
{
  long misc;
  char FileOpt[]="eos_time.cl";

  char str1[1024]="";
  char str2[1024]="";
  
  double clk=CLOCKS_PER_SEC;
  double user, sys;
#ifdef W32
  clock_t start, finish;
#else
  struct rusage	childusage;
#endif

  //***********************************************************************
  cout.setf(ios::unitbuf);
//  cout << "EOS Time   V1.03   (C) by Grigori G.Fursin   November,2000\n";

  //Declaration of class with global variables
  CGlobal* glob = new CGlobal();
    
  //Declaration of class for command-line parsing
  glob->clp = new CCLParse();
     
  if (glob->clp->Init(10, 32, 256, 1, FileOpt)!=0)
  //                   |   |    |  |  | 
  //                   |   |    |  |  |---- Name of File with Options
  //                   |   |    |  |
  //                   |   |    |  |------- Case Sensitive (0) or not (1)
  //                   |   |    |
  //                   |   |    |---------- Max Length of Parameter
  //                   |   |
  //                   |   |--------------- Max Length of Option
  //                   |
  //                   |------------------- Max Number of Options
  {
    cerr << "\nError: Can't initialize object CCLParse!\n";
    return 1;
  }

  misc=0;
  
  misc =glob->clp->Add("--help",       "-h",  "-?", "", 0);             //Param 0
  misc+=glob->clp->Add("--version",    "-v",  "",   "", 0);             //Param 1
#ifdef W32
  misc+=glob->clp->Add("--file_exe",   "-fe", "",   "a.exe", 1);        //Param 2
#else
  misc+=glob->clp->Add("--file_exe",   "-fe", "",   "./a.out", 1);      //Param 2
#endif
  misc+=glob->clp->Add("--file_param", "-fp", "",   "", 1);             //Param 3
  misc+=glob->clp->Add("--file_time",  "-ft", "",   "eos_time.dat", 1); //Param 4

  if (misc!=0)
  {
    cerr << "\nError: Internal, while initializing CCLParse!\n";
    return 1;
  }

  misc=glob->clp->Parse(argc, argv);
  if (misc==1)
  {
    cerr << "\nError: Unknown option in command line!\n";
    return 1;
  }
  else if (misc==2)
  {
    cerr << "\nError: Option can't be used without parameter in command line!\n";
    return 1;
  }
  else if (misc==3)
  {
    cerr << "\nError: Option can't be used without parameter in file with options!\n";
    return 1;
  }
  else if (misc==4)
  {
    cerr << "\nError: Unknown option in file with options!\n";
    return 1;
  }
  else if (misc>0)
  {
    cerr << "\nError: Internal, while parsing command line!\n";
    return 1;
  }

  if (glob->clp->GetParamLong(paramVersion)==1)
  {
    cout << "\n";
    cout << "Version information:\n";
    cout << "  Version 1.02, released on 2000.Nov.10\n";

    return 0;
  }

  if (glob->clp->GetParamLong(paramHelp)==1)
  {
    //Help
    cout << "\n";
    cout << "Brief information:\n";    
    cout << "  This is FCO Time Function\n";
    cout << "\n";
    cout << "Copyright (C) 2004-2005 by Grigori G.Fursin\n";
    cout << "\n";
    cout << "http://homepages.inf.ed.ac.uk/gfursin\n";
    cout << "\n";
    cout << "INRIA Futurs, France\n";
    cout << "and ICSA, University of Edinburgh, UK\n";
    cout << "\n";
    cout << "Options (you can also add options into file " << FileOpt << "):\n";
    cout << "  --help, -h, -?               Help;\n";
    cout << "  --version, -v                Print version;\n";
#ifdef W32
    cout << "  --file_exe, -fe <filename>   File to execute [Default=./a.exe];\n";
#else
    cout << "  --file_exe, -fe <filename>   File to execute [Default=./a.out];\n";
#endif
    cout << "  --file_param, -fp <filename> File with parameters;\n";
    cout << "  --file_time, -ft <filename>  File with time [Default=eos_time.dat].\n";

    return 0;
  }

  //Reading parameter
  if (strcmp(glob->clp->GetParamStr(paramFileParam), "")!=0)
  {
    //Don't use ios::nocreate in Unix!
#ifdef W32
    ifstream fin(glob->clp->GetParamStr(paramFileParam), ios::nocreate);
#else
    ifstream fin(glob->clp->GetParamStr(paramFileParam));
#endif

    if (!fin)
    {
      cerr << "\nError: Can't find file with parameters!\n";
      exit(1);  
    }

    fin.getline(str1, 1023);
  
    fin.close();
  }

  strcpy(str2, glob->clp->GetParamStr(paramFileExe));
  strcat(str2, " ");
  strcat(str2, str1);
  
  cout << "Running application:\n";
  cout << str2 << "\n";
  
#ifdef W32
  strcpy(str1, "start /b /high /wait ");
  strcat(str1, str2);
  strcpy(str2, str1);

  start=clock();
  system(str2);
  finish=clock();

  user = (double)(finish - start) / clk;
  sys  =  0;
#else
  system(str2);

  //Getting user & system time
  if (getrusage(RUSAGE_CHILDREN, &childusage) < 0)
  {
    cerr << "\nError: Can't use function 'getrusage'!\n";
    exit(1);  
  }

  user = (double) childusage.ru_utime.tv_sec +
          childusage.ru_utime.tv_usec/clk;
  sys =  (double) childusage.ru_stime.tv_sec +
          childusage.ru_stime.tv_usec/clk;
#endif

  cout << "\n";
  cout << "User   time: " << user << " s.\n";
  cout << "System time: " << sys  << " s.\n";

  //Saving time to file
  ofstream fout(glob->clp->GetParamStr(paramFileTime));

  if (!fout)
  {
    cerr << "\nError: Can't open file to write time!\n";
    exit(1);  
  }    

  fout << user << "\n";
  fout << sys << "\n";
  
  fout.close();

  cout << "\nProgram finished successfully!\n";
  return 0;
}
