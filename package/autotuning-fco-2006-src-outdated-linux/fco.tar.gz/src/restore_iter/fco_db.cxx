/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "futils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fic       "_finfo_iter"        //current iteration
#define _fic_rep   ".report.txt"        //file with report
#define _fic_repc  ".report.c.dat"      //compilation time
#define _fic_repe  ".report.e.dat"      //execution time
#define _fic_cur   ".cur"               //extension for current iteration
#define _fic_db    ".fdb"               //extension for transformation database
#define _fic_tim   ".time"              //extension for time (run)
#define _fic_timc  ".timec"             //extension for time (compilation)
#define _fic_inf   ".info"              //extension for info
#define _fic_tri1  ".tr_i1"             //extension for transformation info
#define _fic_tri2  ".tr_i2"             //extension for transformation info

#define _ftime_threshold 0.5       //Problems with execution

#define sep "==============================================================================="

char str1[1024];
char str2[1024];

int main(int argc, char* argv[])
{
  FILE* fin=NULL;
  FILE* fin1=NULL;

  printf("FCO DB   V1.00   (C) by Grigori G.Fursin   July,2005\n");

  if (argc<=1)
  {
    printf("\n");
    printf("Usage: fco_db <No_database_to_recreate>\n");
    exit(1);
  }
 
  int iter=atoi(argv[1]);
  printf("\n");
  printf("Recreating database for the iteration %u ...\n", iter);

  sprintf(str1, _fic ".%06u" _fic_tri1, iter);   //info about transformations
  sprintf(str2, _fic ".%06u" _fic_tri2, iter);   //info about transformations

  //read transformation list
  initReadTR();  




  iter=1;
  int finish=0;

  while (finish==0)
  {
    printf("Adding iteration %u ...\n", iter);

    sprintf(str1, _fic ".%06u" _fic_inf, iter);

    if ((fin=fopen(str1, "r"))==NULL) finish=1;
    else
    {
      appendOut(_fic _fic_rep, sep);
      sprintf(str1, "Iteration = {%06u}", iter);
      appendOut(_fic _fic_rep, str1);
      appendOut(_fic _fic_rep, "");

      sprintf(str1, _fic ".%06u" _fic_tri, iter);

      if ((fin1=fopen(str1, "r"))==NULL) finish=1;
      else
      {
        while ((fgets(str1, 1023, fin1)!=NULL) && (feof(fin1)==0))
        {
          fparse1(str1);

          appendOut(_fic _fic_rep, str1);
        }
        fclose(fin1);
        appendOut(_fic _fic_rep, "");
      }      

      int inf1=0;
      int inf2=0;
      int inf3=0;
      
      fgets(str1, 1023, fin);
      inf1=atoi(str1);
      fgets(str1, 1023, fin);
      inf2=atoi(str1);
      fgets(str1, 1023, fin);
      inf3=atoi(str1);
      
      fclose(fin);

      if (inf1==0)
      {
        appendOut(_fic _fic_rep, "executable =          {0}, not created");

        sprintf(str1, "%.f", 0);
        appendOut(_fic _fic_repe, str1);
        sprintf(str1, "%.f", 0);
        appendOut(_fic _fic_repc, str1);
      }
      else
      {
        appendOut(_fic _fic_rep, "executable =          {1}, ok");

        if (inf2==0) appendOut(_fic _fic_rep, "time is not too low = {0}, too low");
	else appendOut(_fic _fic_rep, "time is not too low = {1}, ok");

        if (inf3==0) appendOut(_fic _fic_rep, "output is correct   = {0}, potential problem");
	else appendOut(_fic _fic_rep, "output is correct   = {1}, ok");
	
        sprintf(str1, _fic ".%06u" _fic_tim, iter);
        tx1r=getTime1(str1);
        tx2r=getTime2(str1);
        txtr=tx1r+tx2r;

        sprintf(str1, _fic ".%06u" _fic_timc, iter);
        tx1c=getTime1(str1);
        tx2c=getTime2(str1);
        txtc=tx1c+tx2c;

        appendOut(_fic _fic_rep, "");
        sprintf(str1, "EXE: total={%6.1f}, user={%6.1f}, sys={%6.1f}; COMP: total={%6.1f}, user={%6.1f}, sys={%6.1f}; compilation:", txtr, tx1r, tx2r, txtc, tx1c, tx2c);
        appendOut(_fic _fic_rep, str1);

        sprintf(str1, "%.1f", txtr);
        appendOut(_fic _fic_repe, str1);
        sprintf(str1, "%.1f", txtc);
        appendOut(_fic _fic_repc, str1);

        if (txtr<ttr)
	{
          double impr=((ttr-txtr)/ttr)*100;
          sprintf(str1, "performance change = %3.1f%% (IMPROVEMENT)", impr);
	}
        else
	{
          double impr=((ttr-txtr)/ttr)*100;
          sprintf(str1, "performance change = %3.1f%%", impr);
	}

        appendOut(_fic _fic_rep, "");
        appendOut(_fic _fic_rep, str1);
      }
    }
    iter++;
  }
  printf("\nProgram finished!\n");
  
  return 0;
}
