FCO Compilation

Add new manual iteration to the end of the queue 
based on iteration X or on the last iteration
if X is skipped
						  
Usage:
 fco_comp (X)
