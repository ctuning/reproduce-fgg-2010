/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "ftransformations.h"
#include "futils.h"
#include "fids.h"
#include "param.h"
#include "clparse.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fcomp     "_fbcomp"          //compile batch file
#define _frun      "_fbrun"           //run batch file
#define _fcopy     "_fbcopy"          //copy1 batch file
#define _fdiff     "_fbdiff"          //diff1 batch file
#define _fclean1   "_fbclean1"        //clean std files
#define _fff       "_finfo_funcs"     //file with the list of functions to transform
#define _ftr       "_finfo_tr"        //file with the list of transformations used
#define _fic       "_finfo_iter"      //current iteration
#define _fic_cur   ".cur"             //extension for current iteration
#define _fic_db    ".fdb"             //extension for transformation database
#define _fic_tim   ".time"            //extension for time (run)
#define _fic_timc  ".timec"           //extension for time (compilation)
#define _fic_inf   ".info"            //extension for info
#define _fic_tri1  ".tr_i1"           //extension for transformation info1
#define _fic_tri2  ".tr_i2"           //extension for transformation info2
#define _fcomp1    "fcompilation"     //file for FCompilation
#define _fout      "a.out"            //exe file
#define _ftime     "ftmp_time"        //file with time (run)
#define _ftimec    "ftmp_timec"       //file with time (compilation)
#define _ftmp_diff "ftmp_diff"        //file with diff
#define _ftmp_dbr  "ftmp_dbr.tmp"     //tmp db file (read)
#define _ftmp_dbr1 "ftmp_dbr1.tmp"    //tmp db file (read)
#define _ftmp_dbw  "ftmp_dbw.tmp"     //tmp db file (write)
#define _ftmp_dbw1 "ftmp_dbw1.tmp"    //tmp1 db file (write)

#define _fcomp_mode_0  0         
#define _fcomp_mode_w  2
#define _fcomp_mode_r  3
#define _fcomp_mode_rw 4

int mode_tr;                  //1 - produce error if transformation didn't change
int mode_ign;                 //1 - don't compare time if output is different

//#define mode_acc 0          //1 - accumulate best result
//#define mode_exh 0          //1 - exhaustive mode otherwise random mode
//#define mode_dis 0          //1 - disable all transformations after the current

int tr_rnd=5;                 //number of random tries if mode is random 

double _ftime_threshold;      //Problems with execution
double _ftime_compare;        //threshold to compare best time

#define sep1 "==============================================================================="
#define sep2 "-------------------------------------------------------------------------------"

void trPrep(long iter);
void trFail(long iter);
void trSuccess(void);
int trCompile(long iter, double* t1, double* t2, char* dbr, char* dbw);
void trRun(long iter, double* t1, double* t2, int* inf1, int* inf2, 
           long* iterB, double* ttB, int mode, bool* found);
void trFound(long iterB);

char str1[1024];  //Not very clean, should change when have time
char str2[1024];

char db_r[1024];
char db_w[1024];
char db_rs[1024]; //save original db_r during LNT

long iter0=0;     //transformation for current iteration is based on this one
long iterB=0;     //iteration with best execution time

int main(int argc, char* argv[])
{
  double tt=0;
  double t1=0;
  double t2=0;

  long   iter=1;
  long   iterX=1;
  double ttB=0; //best time
  bool   found=false; //found best time for the set of parameters 

  int param=0;
  int paramr=0;

  int inf1=0;
  int inf2=0;

  bool start=false;
  bool found1=false;

  printf("FCO Compilation\n");

  //*********************************************************  
  printf("Reading original execution time: ");

  sprintf(str2, _fic ".%06u" _fic_tim, 0);
  t1=getTime1(str2);
  t2=getTime2(str2);
  ttB=t1+t2;
  printf("user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, ttB);

  printf("\n");
  printf("Reading last iteration number ...\n");
  
  iterX=readLastIteration(_fic _fic_cur);
  iterX++;

  if (iterX==0)
  {
    printf("Mode: first run\n");
    printf("\n");
    printf("Please, run fco first!\n");
  }
  else
  {
    printf("Last iteration=%u\n", iterX-1);

    //prepare db_r
    iter0=iterX-1;
    iter=iterX;
    sprintf(db_r, _fic ".%06u" _fic_db, iter0);

    if (argc>=2)
    {
      iter0=atoi(argv[1]);
      sprintf(db_r, _fic ".%06u" _fic_db, iter0);
    }    
  
    printf("\n");
    printf("Create new iteration %u based on iteration %u\n", iter, iter0);

    sprintf(db_w, _fic ".%06u" _fic_db, iter);
    setDBIO(db_r, db_w);

    trPrep(iter);

    if (trCompile(iter, &t1, &t2, db_r, db_w)>=0)
        trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found);
            
    writeIteration(_fic _fic_cur, iter);
    if (found) trFound(iterB);

    printf(sep1 "\n");
    printf(sep1 "\n");
    printf("FINAL RESULTS:\n");

    sprintf(str2, _fic ".%06u" _fic_tim, 0);
    t1=getTime1(str2);
    t2=getTime2(str2);
    tt=t1+t2;

    printf("\n");

    if (iterB==0)
    {
      printf("Time original = %6.1f\n", tt);
      printf("\n");
      printf("Better transformations not found!\n");
    }
    else
    {
      printf("Time original = %6.1f s.\n", tt);
      printf("Time best     = %6.1f s.\n", ttB);
      
      printf("\n");
      printf("Iter best     = %06u\n", iterB);

      double impr=((tt-ttB)/tt)*100;
      sprintf(str1, "Performance improvement = %3.1f%%\n", impr);

      printf("\n");
      printf(str1);

      printf(sep1 "\n");
      printf("\n");
    }
  }
  
  return 0;
}

void trFail(long iter)
{
  recordLineTR(id1_performed, "0", 2);
  sprintf(str2, "transformation failed (%s)!\n", getLastTransformationMessage());
  recordLineTR(id1_warn, str2, 2);

  printf("\n");
  printf("Warning: %s\n", str2);
  printf("\n");

  sprintf(str2, _fic ".%06u" _fic_inf, iter);
  writeIterStatus(str2, 0, 0, 0);
}

void trPrep(long iter)
{
  setDBIO(db_r, _ftmp_dbw);

  sprintf(str1, _fic ".%06u" _fic_tri1, iter);   //info about transformations
  sprintf(str2, _fic ".%06u" _fic_tri2, iter);   //info about transformations
  startTRInfo(str1, str2);
 
  sprintf(str1, "%u", iter0);
  recordLineTR(id1_in, str1, 1);

  sprintf(str1, _fic ".%06u" _fic_tri1, iter0); 
  sprintf(str2, "%u", iter);                
  appendLineTR(str1, id1_out, str2);

  startNewTR(2);
  recordLineTR(id1_tr, id_tr_manual,2);
}

void trSuccess(void)
{
  recordLineTR(id1_performed, "1", 2);
}

int trCompile(long iter, double* t1, double* t2, char* dbr, char* dbw)
{
  int ret=0;
  
  printf("Set fcompilation to Read/Write\n");
  setFComp(_fcomp1, _fcomp_mode_rw, dbr, dbw);

  printf("Compile program ...\n");
  system(_fcomp);

  *t1=getTime1(_ftimec);
  *t2=getTime2(_ftimec);
  double tt=(*t1)+(*t2);
  printf("Compile Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", *t1, *t2, tt);

  sprintf(str2, _fic ".%06u" _fic_timc, iter);
  writeTime(str2, *t1, *t2);
    
  if (fileExist(_fout)!=1)
  {
    printf("Warning: a.out is not created!\n");
    ret=-1;
    sprintf(str2, _fic ".%06u" _fic_inf, iter);
    writeIterStatus(str2, 0, 0, 0);
  }

  return ret;
}

void trRun(long iter, double* t1, double* t2, int* inf1, int* inf2, 
           long* iterB, double* ttB, int mode, bool* found)
{
  printf("Run program ...\n");
  system(_frun);

  printf("\n");
      
  *t1=getTime1(_ftime);
  *t2=getTime2(_ftime);
  double tt=(*t1)+(*t2);
  printf("Run Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", *t1, *t2, tt);
  printf("                                        best=(%6.1f), iter=(%06u)\n", *ttB, *iterB);

  sprintf(str2, _fic ".%06u" _fic_tim, iter);
  writeTime(str2, *t1, *t2);

  *inf1=1;
  *inf2=1;
	
  printf("\n");
  if (tt<_ftime_threshold)
  {
    *inf1=0;
    printf("Warning: Execution time too low!\n");
  }
  if (fileDiffCorrect(_fdiff, _ftmp_diff)!=1)
  {
    *inf2=0;
    printf("Warning: Output is different from the original!\n");
  }

  if (((*inf2==0) && (mode==0)) || (*inf2==1))
  {
    //compare time
    if (tt<((*ttB)-_ftime_compare))
    {
      printf("\n");
      printf("BETTER TIME (%6.1f [iter=%06u]   <   %6.1f [iter=%06u]\n", tt, iter, *ttB, *iterB);

      *ttB=tt;
      *iterB=iter;

      *found=true;

      recordLineTR(id1_better, "1", 2);
    }
  }

  sprintf(str2, _fic ".%06u" _fic_inf, iter);
  writeIterStatus(str2, 1, *inf1, *inf2);

  //saving executable file
  sprintf(str1, _fic ".%06u." _fout, iter);
  rename(_fout, str1);
}

void trFound(long iterB)
{
#ifdef mode_acc
  iter0=iterB;

  printf("-------------------------------------------------------------------------------\n");
  printf("Following transformations will be based on iter=%06u\n", iter0);
  sprintf(db_r, _fic ".%06u" _fic_db, iter0);

  setDBIO(db_r, db_w);
#endif
}
