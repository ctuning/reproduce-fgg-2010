/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#ifndef futils_INCLUDED
#define futils_INCLUDED

void setFComp(char* name, int mode, char* fr, char* fw);
double getTime1(char* name);
double getTime2(char* name);
int fileExist(char* name);
int fileDiffCorrect(char* bat, char* name);
long readLastIteration(char* name);
long readLastIterationS(char* name);
void writeIteration(char* name, long mode);
void writeIterationS(char* name, long mode, long mode1);
void writeTime(char* name, double t1, double t2);
void writeIterStatus(char* name, int inf0, int inf1, int inf2);
void cleanFile(char* name);
void writeInfo(char* name, char* str);
void appendOut(char* name, char* str);
void appendOutPrint(char* name, char* str);
void fparse(char* str);
void fparse1(char* str);
int copyFile(char* fin, char* fout);

#endif // futils_INCLUDED
