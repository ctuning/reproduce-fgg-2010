/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "ftransformations.h"
#include "futils.h"
#include "fids.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fcomp     "_fbcomp"          //compile batch file
#define _frun      "_fbrun"           //run batch file
#define _fcopy     "_fbcopy"          //copy1 batch file
#define _fdiff     "_fbdiff"          //diff1 batch file
#define _fclean1   "_fbclean1"        //clean std files
#define _fff       "_finfo_funcs"     //file with the list of functions to transform
#define _fic       "_finfo_iter"      //current iteration
#define _fic_cur   ".cur"             //extension for current iteration
#define _fic_db    ".fdb"             //extension for transformation database
#define _fic_bak   ".bak"             //extension for transformation database (backup)
#define _fic_tim   ".time"            //extension for time (run)
#define _fic_timc  ".timec"           //extension for time (compilation)
#define _fic_inf   ".info"            //extension for info
#define _fic_tri   ".tr_info"         //extension for transformation info
#define _fic_tri1  ".tr_i1"           //extension for transformation info 
                                      //(transformation derivations)
#define _fcomp1    "fcompilation"     //file for FCompilation
#define _fout      "a.out"            //exe file
#define _ftime     "ftmp_time"        //file with time
#define _ftmp_diff "ftmp_diff"        //file with diff
#define _ftmp_dbr  "ftmp_dbr.tmp"     //tmp db file (read)
#define _ftmp_dbr1 "ftmp_dbr1.tmp"    //tmp db file (read)
#define _ftmp_dbw  "ftmp_dbw.tmp"     //tmp db file (write)
#define _dis0      ".dis0"            //
#define _fic_lst   ".lst"             //this program output

#define _ftime_threshold 0.5       //Problems with execution

#define _fcomp_mode_0  0         
#define _fcomp_mode_w  2
#define _fcomp_mode_r  3
#define _fcomp_mode_rw 4

char str1[1024]; //Not very clean, should change when have time
char str2[1024];
char str3[1024];
char str4[1024];
char str5[1024];
char str6[1024];

int main(int argc, char* argv[])
{
  double tt=0;
  double t1=0;
  double t2=0;
  double tta=0;

  int iter=0;

  printf("FCO Disable all transformations\n");

  printf("\n");

  sprintf(str1, _fic ".%06u." _fout, 0);
  sprintf(str2, _fic ".%06u." _fout _fic_bak, 0);
  printf("Renaming %s to %s ...\n", str1, str2);
//  if (fileExist(str1)!=1)
//  {
//    printf("\nError: File %s doesn't exist!\n", str1);
//    exit(1);
//  }
  rename(str1, str2);

  sprintf(str1, _fic ".%06u" _fic_inf, 0);
  sprintf(str2, _fic ".%06u" _fic_inf _fic_bak, 0);
  printf("Renaming %s to %s ...\n", str1, str2);
//  if (fileExist(str1)!=1)
//  {
//    printf("\nError: File %s doesn't exist!\n", str1);
//    exit(1);
//  }
  rename(str1, str2);

  sprintf(str1, _fic ".%06u" _fic_tim, 0);
  sprintf(str2, _fic ".%06u" _fic_tim _fic_bak, 0);
  printf("Renaming %s to %s ...\n", str1, str2);
  if (fileExist(str1)!=1)
  {
    printf("\nError: File %s doesn't exist!\n", str1);
    exit(1);
  }
  rename(str1, str2);

  sprintf(str1, _fic ".%06u" _fic_timc, 0);
  sprintf(str2, _fic ".%06u" _fic_timc _fic_bak, 0);
  printf("Renaming %s to %s ...\n", str1, str2);

  if (fileExist(str1)!=1)
  {
    printf("\nError: File %s doesn't exist!\n", str1);
    exit(1);
  }
  rename(str1, str2);

  sprintf(str1, _fic ".%06u" _fic_tri1, 0);
  sprintf(str2, _fic ".%06u" _fic_tri1 _fic_bak, 0);
  printf("Renaming %s to %s ...\n", str1, str2);
//  if (fileExist(str1)!=1)
//  {
//    printf("\nError: File %s doesn't exist!\n", str1);
//    exit(1);
//  }
  rename(str1, str2);

  sprintf(str1, _fic ".%06u" _fic_db, 0);
  sprintf(str2, _fic ".%06u" _fic_db _fic_bak, 0);
  printf("Renaming %s to %s ...\n", str1, str2);
  if (fileExist(str1)!=1)
  {
    printf("\nError: File %s doesn't exist!\n", str1);
    exit(1);
  }
  rename(str1, str2);

  //init
  strcpy(str3, str2);
  strcpy(str4, _ftmp_dbr);
  strcpy(str5, _ftmp_dbw);
  iter=1;
  
  //check number of all transformations
  long tr_max=2;

  sprintf(str6, _fic ".%06u" _fic_lst _dis0, 0);
  cleanFile(str6);

  printf("\n");
  bool finish=false;
  while ((!finish) && (iter<=tr_max))
  {
    //check number of all transformations
    tr_max=findNumberOfTransformations(str3);

    sprintf(str1, "===============================================================================\n");
    appendOutPrint(str6, str1);

    sprintf(str1, "Current iteration: %u (of max %u) - disabling all transformations ...\n", iter, tr_max);
    appendOutPrint(str6, str1);

    setDBIO(str3, str4);

    //to transform all functions, put "" instead of _fff
    if (disableAllAfterTrFast(iter-1, _fff, _ftmp_dbr1)==0)
    {
      appendOutPrint(str6, "disabling of all transformations finished!\n");
      appendOutPrint(str6, "\n");
      finish=true;
    }
    else
    {
      //compile
      appendOutPrint(str6, "\n");

      appendOutPrint(str6, "Set fcompilation to Read/Write\n");

//        sprintf(str2, _fic ".%06u" _fic_db, iter);
//        we do not create db each iteration anymore
//        because we can recreate it
      setFComp(_fcomp1, _fcomp_mode_rw, str4, str5);
    
      appendOutPrint(str6, "Compile program ...\n");
      system(_fcomp);

      t1=getTime1(_ftime);
      t2=getTime2(_ftime);
      tt=t1+t2;
      tta+=tt;
      sprintf(str1, "Compile Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);
      appendOutPrint(str6, str1);
      sprintf(str1, "Time from start:                                 (%6.1f)\n", tta);
      appendOutPrint(str6, str1);

      if (fileExist(_fout)!=1)
      {
        //don't disable transformation
        appendOutPrint(str6, "\n");
	appendOutPrint(str6, "Warning: a.out has not been created!\n");
	appendOutPrint(str6, "Roll back transformation!\n");
	
        //if iter==1 then we already use .bak file
	//so do not need to kill/rename
        if (iter!=1)
	{
  	  //kill _ftmp_dbw
          remove(_ftmp_dbw);
	  //rename _ftmp_dbr to _ftmp_dbw
          rename(_ftmp_dbr, _ftmp_dbw);
	}
      }
      else
      {
        strcpy(str3, _ftmp_dbw);
      }
    }      

    iter++;
  }

  //rename the last one (_ftmp_dbw into fdb)
  appendOutPrint(str6, "===============================================================================\n");
 
  //writing final compilation time
  sprintf(str2, _fic ".%06u" _fic_timc _dis0, 0);
  writeTime(str2, tta, 0);
  sprintf(str2, _fic ".%06u" _fic_timc, 0);
  writeTime(str2, tta, 0);

  appendOutPrint(str6, "Creating final database ...\n");
  
  sprintf(str1, _fic ".%06u" _fic_db, 0);
  rename(_ftmp_dbw, str1);

  appendOutPrint(str6, "Set fcompilation to Read\n");
  setFComp(_fcomp1, _fcomp_mode_r, str1, _ftmp_dbw);
    
  appendOutPrint(str6, "Compile program ...\n");
  system(_fcomp);

  if (fileExist(_fout)!=1)
  {
    appendOutPrint(str6, "Error: Executable is not created!\n");
    exit(1);
  }

  appendOutPrint(str6, "Run program ...\n");
  system(_frun);

  appendOutPrint(str6, "\n");
    
  t1=getTime1(_ftime);
  t2=getTime2(_ftime);
  tt=t1+t2;
  sprintf(str1, "Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);
  appendOutPrint(str6, str1);
  
  sprintf(str2, _fic ".%06u" _fic_tim _dis0, 0);
  writeTime(str2, t1, t2);

  sprintf(str2, _fic ".%06u" _fic_tim, 0);
  writeTime(str2, t1, t2);

  int inf1=1;
  int inf2=1;
 
  printf("\n");
  if (tt<_ftime_threshold)
  {
    inf1=0;
    appendOutPrint(str6, "Warning: Execution time too low!\n");
  }
  if (fileDiffCorrect(_fdiff, _ftmp_diff)!=1)
  {
    int inf2=0;
    appendOutPrint(str6, "Warning: Output is different from the original!\n");
  }

  sprintf(str2, _fic ".%06u" _fic_inf, 0);
  writeIterStatus(str2, 1, inf1, inf2);

  writeIteration(_fic _fic_cur, 0);

  sprintf(str1, _fic ".%06u." _fout, 0);
  rename(_fout, str1);

  exit(0);
}
