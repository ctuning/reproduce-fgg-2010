/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "fids.h"
#include "futils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

//This is the filename with the FCompilation status
//which should be created in the working directory
//of the application
#define fstatename    "fcompilation"
#define ffuncsname    "ffuncs"

//This file should contain the following number:

//f_comp_state = 0 - not initialized
//               1 - initialized, NO FCompilation (not really needed)
//               2 - initialized, FCompilation, Write parameters
//               3 - initialized, FCompilation, Read parameters
//               4 - initialized, FCompilation, Read/Write parameters
static int f_comp_state=0;
static int f_funcs=0;

//not very clean, should change later
#define funcs_max         32
#define funcs_max_length 128
static char ffuncs[funcs_max][funcs_max_length];

static long long f_pos=0;
static long long f_pos_w=0;
static long long f_pos_x=0;

static long long f_pos5=0;

//Database filenames
static char f_db_r[1024]=fstatename ".fdb.fin";
static char f_db_w[1024]=fstatename ".fdb.fout";
static char f_tr1[1024]="";
static char f_tr2[1024]="";
static char f_tr5[1024]="";

#define sep_tr          "================================================================================"

#define f_tmp         "ftmp.db"

char strx1[1024]; //Not very clean, should change when have time
char strx2[1024];

//Check FCompilation state
int FCheckCompState(void)
{
  FILE* fstate;

  if (f_comp_state==0)
  {
    if (((fstate=fopen(fstatename, "r"))!=NULL) || ((fstate=fopen("../" fstatename, "r"))!=NULL))
    {
      fscanf(fstate, "%u", &f_comp_state);
      if (feof(fstate)==0) fscanf(fstate, "%s", f_db_r);
      if (feof(fstate)==0) fscanf(fstate, "%s", f_db_w);
      fclose(fstate);
    }
    else
      f_comp_state=1;

    if (((fstate=fopen(ffuncsname, "r"))!=NULL) || ((fstate=fopen("../" ffuncsname, "r"))!=NULL))
    {
      f_funcs=0;
      while ((fgets(strx1, funcs_max_length, fstate)!=NULL) && 
             (feof(fstate)==0) && (f_funcs<funcs_max))
      {
        fparse1(strx1);
        strcpy(ffuncs[f_funcs], strx1);
	f_funcs++;
      }
      fclose(fstate);
    }
  }

  return f_comp_state;
}

//return 1 if this function should be included
int FuncCheck(char* str)
{
  int i=0;

  if (f_funcs==0) return 1;

  for (i=0; i<f_funcs; i++)
    if (strcmp(str, ffuncs[i])==0) return 1;

  return 0;
}

FILE* openDBForAppend()
{
  FILE* fstate=NULL;
  if ((fstate=fopen("../" fstatename, "r"))!=NULL)
  {
    fclose(fstate);
    strcpy(strx1, "../");
    strcat(strx1, f_db_w);
    if ((fstate=fopen(strx1, "a"))==NULL)
    {
      printf("FCompilation ERROR: Can't open database file for appending!\n");
      exit(1);
    }
  }
  else if ((fstate=fopen(fstatename, "r"))!=NULL)
  {
    fclose(fstate);
    if ((fstate=fopen(f_db_w, "a"))==NULL)
    {
      printf("FCompilation ERROR: Can't open database file for appending!\n");
      exit(1);
    }
  }
  else
  {
    printf("FCompilation ERROR: Can't find fdatabase file!\n");
    exit(1);
  }

  return fstate;
}

void rewriteDBfromTMP()
{
  FILE* fstate=NULL;
  FILE* fstate1=NULL;

  if ((fstate=fopen("../" fstatename, "r"))!=NULL)
  {
    fclose(fstate);
    strcpy(strx1, "../");
    strcat(strx1, f_db_w);
    if ((fstate=fopen(strx1, "w"))==NULL)
    {
      printf("FCompilation ERROR: Can't open database file for writing!\n");
      exit(1);
    }
  }
  else if ((fstate=fopen(fstatename, "r"))!=NULL)
  {
    fclose(fstate);
    if ((fstate=fopen(f_db_w, "w"))==NULL)
    {
      printf("FCompilation ERROR: Can't open database file for writing!\n");
      exit(1);
    }
  }

  if ((fstate1=fopen(f_tmp, "r"))==NULL)
  {
    printf("FCompilation ERROR: Can't find fdatabase tmp file!\n");
    exit(1);
  }

  while ((fgets(strx1, 1023, fstate1)!=NULL) && (feof(fstate1)==0))
  {
    fputs(strx1, fstate);
  }

  fclose(fstate1);
  fclose(fstate);

  remove(f_tmp);
}

FILE* openDBTMPForAppend()
{
  FILE* fstate=NULL;
  if ((fstate=fopen(f_tmp, "a"))==NULL)
  {
    printf("FCompilation ERROR: Can't open database TMP file for writing!\n");
    exit(1);
  }

  return fstate;
}

FILE* openDBForReading()
{
  FILE* fstate=NULL;

  strcpy(strx1, "../");
  strcat(strx1, f_db_r);

  fstate=fopen(strx1, "r");
  if (fstate==NULL) fstate=fopen(f_db_r, "r");

  if (fstate==NULL)
  {
    printf("FCompilation ERROR: Can't find database!\n");
    exit(1);
  }

  return fstate;
}

FILE* openDBForReadingW()
{
  FILE* fstate=NULL;
  FILE* fstate1=NULL;
  if ((fstate=fopen("../" fstatename, "r"))!=NULL)
  {
    fclose(fstate);
    strcpy(strx1, "../");
    strcat(strx1, f_db_w);
    fstate1=fopen(strx1, "r");
  }
  else if ((fstate=fopen(fstatename, "r"))!=NULL)
  {
    fclose(fstate);
    fstate1=fopen(f_db_w, "r");
  }
  else
  {
    printf("FCompilation ERROR: Can't find database!\n");
    exit(1);
  }

  return fstate1;
}

void startNewRecord()
{
  FILE* fstate;
  fstate=openDBForAppend();

  fprintf(fstate, sep_tr "\n");
  fclose(fstate);
}

void startTMP(void)
{
  FILE* fstate=NULL;

  if ((fstate=fopen(f_tmp, "w"))!=NULL)
  {
    fclose(fstate);
  }
}

void startNewRecordTMP(void)
{
  FILE* fstate=NULL;

  if ((fstate=fopen(f_tmp, "a"))!=NULL)
  {
    fprintf(fstate, sep_tr "\n");
    fclose(fstate);
  }
}

void startNewTR(int i)
{
  FILE* fstate;

  strcpy(strx1, f_tr2);
  if (i==1) strcpy(strx1, f_tr1);

  if ((fstate=fopen(strx1, "w"))!=NULL)
  {
    fprintf(fstate, sep_tr "\n");
    fclose(fstate);
  }
}

void recordLine(char* id, char* str)
{
  FILE* fstate;
  fstate=openDBForAppend();
  
  fprintf(fstate, "%s%s\n", id, str);
  fclose(fstate);
}

void recordLineTR(char* id, char* str, int i)
{
  FILE* fstate=NULL;

  strcpy(strx1, f_tr2);
  if (i==1) strcpy(strx1, f_tr1);

  if ((fstate=fopen(strx1, "a"))!=NULL)
  {
    fprintf(fstate, "%s%s\n", id, str);
    fclose(fstate);
  }
}

int findLineFromCurrentTransformationTR(char* id, char* str, int m)
{
  FILE* fstate=NULL;
  int found=0;
  int i=0;

  strcpy(str, "");

  strcpy(strx1, f_tr2);
  if (m==1) strcpy(strx1, f_tr1);

  if ((fstate=fopen(strx1, "r"))!=NULL)
  {
    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
           && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strlen(strx1)>=strlen(id))
      {
        if (strncmp(strx1,id,strlen(id))==0)
	{
          found=1;
	  for (i=strlen(id); i<strlen(strx1); i++) str[i-strlen(id)]=strx1[i];
	  str[i-strlen(id)]=0;
	}
      }
    }
   
    fclose(fstate);
  }

  return found;
}

int findLineFromCurrentTransformationY(char* id, char* str, char* fl)
{
  FILE* fstate=NULL;
  int found=0;
  int i=0;

  strcpy(str, "");

  if ((fstate=fopen(fl, "r"))!=NULL)
  {
    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
           && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strlen(strx1)>=strlen(id))
      {
        if (strncmp(strx1,id,strlen(id))==0)
	{
          found=1;
	  for (i=strlen(id); i<strlen(strx1); i++) str[i-strlen(id)]=strx1[i];
	  str[i-strlen(id)]=0;
	}
      }
    }
   
    fclose(fstate);
  }

  return found;
}

int findLineFromFile(char* id, char* str, char* fl)
{
  FILE* fstate=NULL;
  int found=0;
  int i=0;

  strcpy(str, "");

  if ((fstate=fopen(fl, "r"))!=NULL)
  {
    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
           && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strlen(strx1)>=strlen(id))
      {
        if (strncmp(strx1,id,strlen(id))==0)
	{
          found=1;
	  for (i=strlen(id); i<strlen(strx1); i++) str[i-strlen(id)]=strx1[i];
	  str[i-strlen(id)]=0;
	}
      }
    }
   
    fclose(fstate);
  }

  return found;
}

void appendLineTR(char* str1, char* str2, char* str3)
{
  FILE* fstate=NULL;

  if ((fstate=fopen(str1, "a"))!=NULL)
  {
    fprintf(fstate, "%s%s\n", str2, str3);
    fclose(fstate);
  }
}

void recordLineTMP(char* id, char* str)
{
  FILE* fstate;
  fstate=openDBTMPForAppend();
  
  fprintf(fstate, "%s%s\n", id, str);
  fclose(fstate);
}

void recordFromFile(char* id, char* ftmpname)
{
  FILE* fstate=NULL;
  FILE* ftmp=NULL;

  fstate=openDBForAppend();
  if ((ftmp=fopen(ftmpname, "r"))==NULL)
  {
    printf("FCompilation ERROR: Can't find tmp file with prefetch info!\n");
    exit(1);
  }
  else
  {
    while ((fgets(strx1, 1023, ftmp)!=NULL) && (feof(ftmp)==0))
    {
      fparse1(strx1);
      fprintf(fstate, "%s%s\n", id, strx1);
    }
 
    fclose(ftmp);
  }

  fclose(fstate);
}

void setPositionToStart(void)
{
  f_pos=0;
}

int findTransformation(char* id)
{
  FILE* fstate=NULL;
  int found=0;
  long long f_pos1=f_pos;
  int i=0;

  fstate=openDBForReading();

  if (fstate!=NULL)
  {
    fseek(fstate, f_pos1, SEEK_SET);

    int cont=0;
    int itr=0; //to detect ignore_the_rest
    while ((itr==0) && (found==0) && ((cont==1) || (fgets(strx1, 1023, fstate)!=NULL) && (feof(fstate)==0)))
    {
      if (cont==1) cont=0;
      
      fparse1(strx1);

      if (strcmp(strx1, sep_tr)==0)
      {
        f_pos1=ftell(fstate);

        while ((itr==0) && (fgets(strx1, 1023, fstate)!=NULL) 
            && (feof(fstate)==0))
        {
          fparse1(strx1);

          if (strcmp(strx1, sep_tr)==0)
	  {
            cont=1;
	    break;
	  }
          else if ((strlen(strx1)>=strlen(id_ignore_the_rest)) && 
	           (strncmp(strx1,id_ignore_the_rest,strlen(id_ignore_the_rest))==0))
          {
            for (i=strlen(id_ignore_the_rest); i<strlen(strx1); i++) 
             strx2[i-strlen(id_ignore_the_rest)]=strx1[i];
            strx2[i-strlen(id_ignore_the_rest)]=0;

            if (strcmp(strx2, "1")==0) itr=1;
          }
          else if ((strlen(strx1)>=strlen(id_tr)) && 
                   (strncmp(strx1,id_tr,strlen(id_tr))==0))
          {
            for (i=strlen(id_tr); i<strlen(strx1); i++) strx2[i-strlen(id_tr)]=strx1[i];
            strx2[i-strlen(id_tr)]=0;

            if (strcmp(strx2, id)==0)
            {
              found=1;
              f_pos=f_pos1;
            }
          }
        }
      }
    }
   
    fclose(fstate);
  }

  return found;
}

int findTransformationByNumber(long num)
{
  FILE* fstate=NULL;
  int found=0;
  int i=0;
  long num1=0;

  fstate=openDBForReading();

  if (fstate!=NULL)
  {
    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strcmp(strx1, sep_tr)==0)
      {
        f_pos=ftell(fstate);
        f_pos_x=ftell(fstate);
        num1++;
	
	if (num1>=num) found=1;
      }
    }
   
    fclose(fstate);
  }

  return found;
}

int findLineFromCurrentTransformation(char* id, char* str)
{
  FILE* fstate=NULL;
  int found=0;
  int i=0;

  strcpy(str, "");

  fstate=openDBForReading();

  if (fstate!=NULL)
  {
    fseek(fstate, f_pos, SEEK_SET);

    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
           && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strcmp(strx1, sep_tr)==0) break;
      else if (strlen(strx1)>=strlen(id))
      {
        if (strncmp(strx1,id,strlen(id))==0)
	{
          found=1;
	  for (i=strlen(id); i<strlen(strx1); i++) str[i-strlen(id)]=strx1[i];
	  str[i-strlen(id)]=0;
	}
      }
    }
   
    fclose(fstate);
  }

  return found;
}

int findLineFromCurrentTransformationX(char* id, char* str, int position)
{
  FILE* fstate=NULL;
  int found=0;
  int i=0;
  int pos=0;

  strcpy(str, "");

  fstate=openDBForReading();

  if (fstate!=NULL)
  {
    fseek(fstate, f_pos, SEEK_SET);

    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
           && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strcmp(strx1, sep_tr)==0) break;
      else if (strlen(strx1)>=strlen(id))
      {
        if (strncmp(strx1,id,strlen(id))==0)
	{
	  if (pos>=position)
	  {
            found=1;
  	    for (i=strlen(id); i<strlen(strx1); i++) str[i-strlen(id)]=strx1[i];
	    str[i-strlen(id)]=0;
	  }
	  else pos++;
	}
      }
    }
   
    fclose(fstate);
  }

  return found;
}

void setPositionToStartW(void)
{
  f_pos_w=0;
}

int findTransformationW(char* id)
{
  FILE* fstate=NULL;
  int found=0;
  long long f_pos1_w=f_pos_w;
  int i=0;

  fstate=openDBForReadingW();

  if (fstate!=NULL)
  {
    fseek(fstate, f_pos1_w, SEEK_SET);

    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strcmp(strx1, sep_tr)==0)
      {
        f_pos1_w=ftell(fstate);

        while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
            && (feof(fstate)==0))
        {
          fparse1(strx1);

          if (strcmp(strx1, sep_tr)==0) break;
          else if (strlen(strx1)>=strlen(id_tr))
          {
            if (strncmp(strx1,id_tr,strlen(id_tr))==0)
    	    {
              for (i=strlen(id_tr); i<strlen(strx1); i++) strx2[i-strlen(id_tr)]=strx1[i];
              strx2[i-strlen(id_tr)]=0;

              if (strcmp(strx2, id)==0)
              {
                found=1;
                f_pos_w=f_pos1_w;
	      }
            }
          }
        }
      }
    }
   
    fclose(fstate);
  }

  return found;
}

int findLineFromCurrentTransformationW(char* id, char* str)
{
  FILE* fstate=NULL;
  int found=0;
  int i=0;

  strcpy(str, "");

  fstate=openDBForReadingW();

  if (fstate!=NULL)
  {
    fseek(fstate, f_pos_w, SEEK_SET);

    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
           && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strcmp(strx1, sep_tr)==0) break;
      else if (strlen(strx1)>=strlen(id))
      {
        if (strncmp(strx1,id,strlen(id))==0)
	{
          found=1;
	  for (i=strlen(id); i<strlen(strx1); i++) str[i-strlen(id)]=strx1[i];
	  str[i-strlen(id)]=0;
	}
      }
    }
   
    fclose(fstate);
  }

  return found;
}

void writeDBtoTMPbeforeCurTrW(void)
{
  FILE* fstate=NULL;
  FILE* fstate1=NULL;

  long long f_pos1_w=0;

  int found=0;

  if ((fstate=fopen(f_tmp, "w"))!=NULL)
  {
    fstate1=openDBForReadingW();

    while ((found==0) && (fgets(strx1, 1023, fstate1)!=NULL) && (feof(fstate1)==0))
    {
      fputs(strx1, fstate);

      if (ftell(fstate1)>=f_pos_w) found=1;
    }

    fclose(fstate1);
    fclose(fstate);    
  }
  else
  {
    printf("FCompilation ERROR: Can't open tmp file for writing!\n");
    exit(1);
  }
}

void writeDBtoTMPbeforeCurTr(void)
{
  FILE* fstate=NULL;
  FILE* fstate1=NULL;

  long long f_pos1=0;

  int found=0;

  if ((fstate=fopen(f_tmp, "w"))!=NULL)
  {
    fstate1=openDBForReading();

    while ((found==0) && (fgets(strx1, 1023, fstate1)!=NULL) && (feof(fstate1)==0))
    {
      fputs(strx1, fstate);

      if (ftell(fstate1)>=f_pos) found=1;
    }

    fclose(fstate1);
    fclose(fstate);    
  }
  else
  {
    printf("FCompilation ERROR: Can't open tmp file for writing!\n");
    exit(1);
  }
}

void appendDBtoTMPonlyCurTr(void)
{
  FILE* fstate1=NULL;
  FILE* fstate=NULL;
  int i=0;

  if ((fstate1=fopen(f_tmp, "a"))!=NULL)
  {
    fstate=openDBForReading();

    if (fstate!=NULL)
    {
      fseek(fstate, f_pos, SEEK_SET);

      while ((fgets(strx1, 1023, fstate)!=NULL) 
             && (feof(fstate)==0))
      {
        strcpy(strx2, strx1);
        fparse1(strx1);

        if (strcmp(strx1, sep_tr)==0) break;
        else fputs(strx2, fstate1);
      }
   
      fclose(fstate1);
      fclose(fstate);
    }
  }
  else
  {
    printf("FCompilation ERROR: Can't open tmp file for writing!\n");
    exit(1);
  }
}

int appendDBtoTMPbeforeID(char* id, char* str)
{
  FILE* fstate1=NULL;
  FILE* fstate=NULL;
  int found=0;
  int i=0;

  strcpy(str, "");

  if ((fstate1=fopen(f_tmp, "a"))!=NULL)
  {
    fstate=openDBForReading();

    if (fstate!=NULL)
    {
      fseek(fstate, f_pos, SEEK_SET);

      while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
             && (feof(fstate)==0))
      {
        strcpy(strx2, strx1);
        fparse1(strx1);

        if (strcmp(strx1, sep_tr)==0) break;
        else if ((strlen(strx1)>=strlen(id)) && (strncmp(strx1,id,strlen(id))==0))
        {
          found=1;
          for (i=strlen(id); i<strlen(strx1); i++) str[i-strlen(id)]=strx1[i];
          str[i-strlen(id)]=0;
        }
        else fputs(strx2, fstate1);
      }
   
      fclose(fstate1);
      fclose(fstate);
    }
  }
  else
  {
    printf("FCompilation ERROR: Can't open tmp file for writing!\n");
    exit(1);
  }

  return found;
}

void writeDBtoTMPafterCurTrAndRenameBackW(void)
{
  FILE* fstate=NULL;
  FILE* fstate1=NULL;

  int found=0;
  long long f_pos1_w=f_pos_w;

  fstate=openDBForReadingW();

  if ((fstate1=fopen(f_tmp, "a"))==NULL)
  {
    printf("FCompilation ERROR: Can't find database tmp file!\n");
    exit(1);
  }

  if (fstate!=NULL)
  {
    fseek(fstate, f_pos1_w, SEEK_SET);

    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strcmp(strx1, sep_tr)==0)
      {
        fprintf(fstate1, sep_tr "\n");

        while ((fgets(strx1, 1023, fstate)!=NULL) && (feof(fstate)==0))
        {
          fputs(strx1, fstate1);
        }

        found=1;
      }
    }

    fclose(fstate1);
    fclose(fstate);

    rewriteDBfromTMP();
  }
}

void renameBack(void)
{
  rename(f_tmp, f_db_w);
}

void writeDBtoTMPafterCurTrAndRenameBack(char* id)
{
  FILE* fstate=NULL;
  FILE* fstate1=NULL;

  int found=0;

  fstate=openDBForReading();

  if ((fstate1=fopen(f_tmp, "a"))==NULL)
  {
    printf("FCompilation ERROR: Can't find database tmp file!\n");
    exit(1);
  }

  if (fstate!=NULL)
  {
    fseek(fstate, f_pos_x, SEEK_SET);

    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
           && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strlen(strx1)>=strlen(id))
      {
        if (strncmp(strx1,id,strlen(id))==0)
        {
          found=1;
          while ((fgets(strx1, 1023, fstate)!=NULL) && (feof(fstate)==0))
          {
            fputs(strx1, fstate1);
            fparse1(strx1);
          }
        }
      }
    }

    fclose(fstate1);
    fclose(fstate);

    rename(f_tmp, f_db_w);
  }
}

/* From current directory */
long findNumberOfTransformations(char* db)
{
  FILE* fstate=NULL;
  long ret=-1;
  long trs=0;

  if ((fstate=fopen(db, "r"))!=NULL)
  {
    while ((fgets(strx1, 1023, fstate)!=NULL) && (feof(fstate)==0))
    {
      fparse1(strx1);
      if (strcmp(strx1, sep_tr)==0) trs++;
    }
   
    fclose(fstate);
    
    ret=trs;
  }

  return ret;
}

char* getDBR(void)
{
  return f_db_r;
}

char* getDBW(void)
{
  return f_db_w;
}

void setDBIO(char* str1, char* str2)
{
  strcpy(f_db_r, str1);
  strcpy(f_db_w, str2);
}

void startTRInfo(char* str1, char* str2)
{
  strcpy(f_tr1, str1);
  strcpy(f_tr2, str2);

  remove(f_tr1);
  remove(f_tr2);
}

void startTRInfo1(char* str1, char* str2)
{
  strcpy(f_tr1, str1);
  strcpy(f_tr2, str2);
}

int getCurTransformationID(char* str)
{
  int ret=-1;

  ret=findLineFromCurrentTransformation(id_tr, str);
  ret=matchTransformationWithID(str);
  
  return ret;
}

int getCurTransformationFunc(char* str)
{
  int ret=-1;

  strcpy(str, "");
  ret=findLineFromCurrentTransformation(id_func, str);
  
  return ret;
}

int checkCurFuncToTransform(char* fname)
{
  int ret=1;
  FILE* fstate=NULL;

  if (getCurTransformationFunc(strx2)==1)
  {
    if ((fstate=fopen(fname, "r"))!=NULL)
    {
      ret=0;
      int found=0;
      
      while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
             && (feof(fstate)==0))
      {
        fparse1(strx1);

        if (strcmp(strx1, strx2)==0)
	{
	  ret=1;
	  found=1;
	}
      }
      fclose(fstate);
    }
  }
  
  return ret;
}

int matchTransformationWithID(char* str)
{
  int ret=-1;
  
  if (strcmp(str, id_tr_pf)==0) ret=iid_tr_pf;
  else if (strcmp(str, id_tr_snl)==0) ret=iid_tr_snl;
  else if (strcmp(str, id_tr_simd)==0) ret=iid_tr_simd;
  else if (strcmp(str, id_tr_unroll)==0) ret=iid_tr_unroll;
  else if (strcmp(str, id_tr_ff)==0) ret=iid_tr_ff;
  else if (strcmp(str, id_tr_inline)==0) ret=iid_tr_inline;
  else if (strcmp(str, id_tr_pad_local)==0) ret=iid_tr_pad_local;
  else if (strcmp(str, id_tr_pad_global)==0) ret=iid_tr_pad_global;

  return ret;
}

void matchIDWithTransformation(char* str, int id)
{
  strcpy(str, "");
  
  if (id==iid_tr_pf) strcpy(str, id_tr_pf);
  else if (id==iid_tr_snl) strcpy(str, id_tr_snl);
  else if (id==iid_tr_simd) strcpy(str, id_tr_simd);
  else if (id==iid_tr_unroll) strcpy(str, id_tr_unroll);
  else if (id==iid_tr_ff) strcpy(str, id_tr_ff);
  else if (id==iid_tr_inline) strcpy(str, id_tr_inline);
  else if (id==iid_tr_pad_local) strcpy(str, id_tr_pad_local);
  else if (id==iid_tr_pad_global) strcpy(str, id_tr_pad_global);
}

long long getCurrentPosition(void)
{
  return f_pos;
}

long long getLastTransformationPOS(void)
{
  return getCurrentPosition();
}

void initReadTR(char* str)
{
  f_pos5=0;
  strcpy(f_tr5, str);
}

int findNextTR(void)
{
  FILE* fstate=NULL;
  int found=0;
  int i=0;

  if ((fstate=fopen(f_tr5, "r"))!=NULL)
  {
    fseek(fstate, f_pos5, SEEK_SET);

    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
           && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strcmp(strx1, sep_tr)==0)
      {
        f_pos5=ftell(fstate);
        found=1;
      }
    }
   
    fclose(fstate);
  }

  return found;
}

int findLineFromCurrentTR(char* id, char* str)
{
  FILE* fstate=NULL;
  int found=0;
  int i=0;

  strcpy(str, "");
  if ((fstate=fopen(f_tr5, "r"))!=NULL)
  {
    fseek(fstate, f_pos5, SEEK_SET);

    while ((found==0) && (fgets(strx1, 1023, fstate)!=NULL) 
           && (feof(fstate)==0))
    {
      fparse1(strx1);

      if (strcmp(strx1, sep_tr)==0) break;
      else if (strlen(strx1)>=strlen(id))
      {
        if (strncmp(strx1,id,strlen(id))==0)
	{
          found=1;
	  for (i=strlen(id); i<strlen(strx1); i++) str[i-strlen(id)]=strx1[i];
	  str[i-strlen(id)]=0;
	}
      }
    }
   
    fclose(fstate);
  }

  return found;
}
