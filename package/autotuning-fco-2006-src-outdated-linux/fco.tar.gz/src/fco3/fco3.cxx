/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "ftransformations.h"
#include "futils.h"
#include "fids.h"
#include "param.h"
#include "clparse.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fcomp     "_fbcomp"          //compile batch file
#define _frun      "_fbrun"           //run batch file
#define _fcopy     "_fbcopy"          //copy1 batch file
#define _fdiff     "_fbdiff"          //diff1 batch file
#define _fclean1   "_fbclean1"        //clean std files
#define _fff       "_finfo_funcs"     //file with the list of functions to transform
#define _ftr       "_finfo_tr"        //file with the list of transformations used
#define _fic       "_finfo_iter"      //current iteration
#define _fic_cur   ".cur"             //extension for current iteration
#define _fic_db    ".fdb"             //extension for transformation database
#define _fic_tim   ".time"            //extension for time (run)
#define _fic_timc  ".timec"           //extension for time (compilation)
#define _fic_inf   ".info"            //extension for info
#define _fic_tri1  ".tr_i1"           //extension for transformation info1
#define _fic_tri2  ".tr_i2"           //extension for transformation info2
#define _fcomp1    "fcompilation"     //file for FCompilation
#define _fout      "a.out"            //exe file
#define _ftime     "ftmp_time"        //file with time (run)
#define _ftimec    "ftmp_timec"       //file with time (compilation)
#define _ftmp_diff "ftmp_diff"        //file with diff
#define _ftmp_dbr  "ftmp_dbr.tmp"     //tmp db file (read)
#define _ftmp_dbr1 "ftmp_dbr1.tmp"    //tmp db file (read)
#define _ftmp_dbw  "ftmp_dbw.tmp"     //tmp db file (write)
#define _ftmp_dbw1 "ftmp_dbw1.tmp"    //tmp1 db file (write)

#define _fcomp_mode_0  0         
#define _fcomp_mode_w  2
#define _fcomp_mode_r  3
#define _fcomp_mode_rw 4

int mode_tr;                  //1 - produce error if transformation didn't change
int mode_ign;                 //1 - don't compare time if output is different

//#define mode_acc 0          //1 - accumulate best result
//#define mode_exh 0          //1 - exhaustive mode otherwise random mode
//#define mode_dis 0          //1 - disable all transformations after the current

int tr_rnd=3;                 //number of random tries if mode is random 

double _ftime_threshold;      //Problems with execution
double _ftime_compare;        //threshold to compare best time

int tr_snl=           1;
int tr_simd=          1;
int tr_ff=            1;
int tr_inline=        1;

int tr_unroll=        2;
int tr_unroll_min=    1;
int tr_unroll_max=   16;
int tr_unroll_step=   1;

int tr_interchange=   1;

int tr_regt=          1;
int tr_regt_min=      1;
int tr_regt_max=     12;
int tr_regt_step=     1;

int tr_t=             1;
int tr_t_min=         0;
int tr_t_max=       512;
int tr_t_step=        4;

int tr_pf=        -1024;
int tr_pf_min=        0;
int tr_pf_max=     1024;
int tr_pf_step=      16;

int tr_pl=            1;
int tr_pl_min=        0;
int tr_pl_max=      128;
int tr_pl_step=       1;

int tr_pg=            1;
int tr_pg_min=        0;
int tr_pg_max=      128;
int tr_pg_step=       1;

#define sep1 "==============================================================================="
#define sep2 "-------------------------------------------------------------------------------"

void trPrep(long iter, long t);
void trPrepSNL(int n, int* ai, int* ar, int bn, int* b1, int* b2, int* b3);
void trFail(long iter);
void trSuccess(void);
int trCompile(long iter, double* t1, double* t2, char* dbr, char* dbw);
void trRun(long iter, double* t1, double* t2, int* inf1, int* inf2, 
           long* iterB, double* ttB, int mode, bool* found, bool* infl);
void trCheck(long iter, long* iterB, double* ttB, bool* found, bool* infl);
void trFound(long iterB);
int trDisable(long iter, long tr, char* func);

char str1[1024];  //Not very clean, should change when have time
char str2[1024];

char db_r[1024];
char db_w[1024];
char db_rs[1024]; //save original db_r during LNT

long iter0=0;     //transformation for current iteration is based on this one
long iter0s=0;    //save original iter0
long iterB=0;     //iteration with best execution time
long iterD=0;     //iteration with execution time when transformation is disabled
double ttB0s=0;

int snl_i[32];    //interchange position
int snl_r[32];    //register tiling

int snl_bi[32];   //interchange position
int snl_br[32];   //register tiling

int snl_t1[32];   //lnt_internal_loop_number
int snl_t2[32];   //lnt_loop_strip
int snl_t3[32];   //lnt_cache_level

int snl_bt1[32];  //lnt_internal_loop_number
int snl_bt2[32];  //lnt_loop_strip
int snl_bt3[32];  //lnt_cache_level

int main(int argc, char* argv[])
{
  double tt=0;
  double t1=0;
  double t2=0;

  long   iter=1;
  long   iterX=1;
  double ttB=0; //best time
  bool   found=false; //found best time for the set of parameters 
  bool   infl=false;  //if didn't find best time but the change in time
                      //was dramatic - means that influence performance

  int param=0;
  int paramr=0;

  int inf1=0;
  int inf2=0;

  bool start=false;
  bool found1=false;

  char FileOpt[]="fco3.cl";

  printf("FCO Strategy 2\n");

  //*********************************************************  
  //Declaration of class for command-line parsing
  CCLParse*	 clp = new CCLParse();
         
  if (clp->Init(10, 32, 256, 1, FileOpt)!=0)
  //             |   |    |  |  | 
  //             |   |    |  |  |------ Name of File with Options
  //             |   |    |  |
  //             |   |    |  |--------- Case Sensitive (0) or not (1)
  //             |   |    |
  //             |   |    |------------ Max Length of Parameter
  //             |   |
  //             |   |----------------- Max Length of Option
  //             |
  //             |--------------------- Max Number of Options
  {
    printf("\nError: Can't initialize object CCLParse!\n");
    return 1;
  }

  int misc=0;
  
  misc =clp->Add("--help", "-h", "-?", "", 0);               //Param 0
  misc+=clp->Add("--version", "-v", "", "", 0);              //Param 1
  misc+=clp->Add("--verbose", "-vb", "", "", 0);             //Param 2
  misc+=clp->Add("--mode_tr", "-mtr", "", "0", 1);           //Param 3
  misc+=clp->Add("--mode_ign", "-mig", "", "1", 1);          //Param 4
  misc+=clp->Add("--time_threshold", "-tt", "", "0.5", 1);   //Param 5
  misc+=clp->Add("--time_compare", "-tc", "", "0.3", 1);     //Param 6
  misc+=clp->Add("--tr_rnd", "-tr", "", "5", 1);             //Param 7

  if (misc!=0)
  {
    printf("\nError: Internal, while initializing CCLParse!\n");
    return 1;
  }

  misc=clp->Parse(argc, argv);
  if (misc==1)
  {
    printf("\nError: Unknown option in command line!\n");
    return 1;
  }
  else if (misc==2)
  {
    printf("\nError: Option can't be used without parameter in command line!\n");
    return 1;
  }
  else if (misc==3)
  {
    printf("\nError: Option can't be used without parameter in file with options!\n");
    return 1;
  }
  else if (misc==4)
  {
    printf("\nError: Unknown option in file with options!\n");
    return 1;
  }
  else if (misc>0)
  {
    printf("\nError: Internal, while parsing command line!\n");
    return 1;
  }

  mode_tr=clp->GetParamInt(paramMTR);
  mode_ign=clp->GetParamInt(paramMIG);
  _ftime_threshold=atof(clp->GetParamStr(paramTT));
  _ftime_compare=atof(clp->GetParamStr(paramTC));
  tr_rnd=clp->GetParamInt(paramTR);

  //*********************************************************  
  printf("\n");
  printf("Reading transformation configuration\n");

  if (findLineFromFile(ido_mtr, str1, _ftr)==1) mode_tr=atoi(str1);
  if (findLineFromFile(ido_mig, str1, _ftr)==1) mode_ign=atoi(str1);
  if (findLineFromFile(ido_tt, str1, _ftr)==1) _ftime_threshold=atof(str1);
  if (findLineFromFile(ido_tc, str1, _ftr)==1) _ftime_compare=atof(str1);
  if (findLineFromFile(ido_tr, str1, _ftr)==1) tr_rnd=atoi(str1);

  if (findLineFromFile(ido_tr_snl, str1, _ftr)==1) tr_snl=atoi(str1);
  if (findLineFromFile(ido_tr_simd, str1, _ftr)==1) tr_simd=atoi(str1);
  if (findLineFromFile(ido_tr_ff, str1, _ftr)==1) tr_ff=atoi(str1);
  if (findLineFromFile(ido_tr_inline, str1, _ftr)==1) tr_inline=atoi(str1);

  if (findLineFromFile(ido_tr_unroll, str1, _ftr)==1) tr_unroll=atoi(str1);
  if (findLineFromFile(ido_tr_unroll_min, str1, _ftr)==1) tr_unroll_min=atoi(str1);
  if (findLineFromFile(ido_tr_unroll_max, str1, _ftr)==1) tr_unroll_max=atoi(str1);
  if (findLineFromFile(ido_tr_unroll_step, str1, _ftr)==1) tr_unroll_step=atoi(str1);

  if (findLineFromFile(ido_tr_interchange, str1, _ftr)==1) tr_interchange=atoi(str1);

  if (findLineFromFile(ido_tr_regt, str1, _ftr)==1) tr_regt=atoi(str1);
  if (findLineFromFile(ido_tr_regt_min, str1, _ftr)==1) tr_regt_min=atoi(str1);
  if (findLineFromFile(ido_tr_regt_max, str1, _ftr)==1) tr_regt_max=atoi(str1);
  if (findLineFromFile(ido_tr_regt_step, str1, _ftr)==1) tr_regt_step=atoi(str1);

  if (findLineFromFile(ido_tr_t, str1, _ftr)==1) tr_t=atoi(str1);
  if (findLineFromFile(ido_tr_t_min, str1, _ftr)==1) tr_t_min=atoi(str1);
  if (findLineFromFile(ido_tr_t_max, str1, _ftr)==1) tr_t_max=atoi(str1);
  if (findLineFromFile(ido_tr_t_step, str1, _ftr)==1) tr_t_step=atoi(str1);

  if (findLineFromFile(ido_tr_pf, str1, _ftr)==1) tr_pf=atoi(str1);
  if (findLineFromFile(ido_tr_pf_min, str1, _ftr)==1) tr_pf_min=atoi(str1);
  if (findLineFromFile(ido_tr_pf_max, str1, _ftr)==1) tr_pf_max=atoi(str1);
  if (findLineFromFile(ido_tr_pf_step, str1, _ftr)==1) tr_pf_step=atoi(str1);

  if (findLineFromFile(ido_tr_pl, str1, _ftr)==1) tr_pl=atoi(str1);
  if (findLineFromFile(ido_tr_pl_min, str1, _ftr)==1) tr_pl_min=atoi(str1);
  if (findLineFromFile(ido_tr_pl_max, str1, _ftr)==1) tr_pl_max=atoi(str1);
  if (findLineFromFile(ido_tr_pl_step, str1, _ftr)==1) tr_pl_step=atoi(str1);

  if (findLineFromFile(ido_tr_pg, str1, _ftr)==1) tr_pg=atoi(str1);
  if (findLineFromFile(ido_tr_pg_min, str1, _ftr)==1) tr_pg_min=atoi(str1);
  if (findLineFromFile(ido_tr_pg_max, str1, _ftr)==1) tr_pg_max=atoi(str1);
  if (findLineFromFile(ido_tr_pg_step, str1, _ftr)==1) tr_pg_step=atoi(str1);

  if (clp->GetParamLong(paramVersion)==1)
  {
    printf("\n");
    printf("Version information:\n");
    printf("  Version 1.0, released on 2006.January.20\n");

    return 0;
  }

  if (clp->GetParamLong(paramHelp)==1)
  {
    //Help
    printf("\n");
    printf("Brief information:\n");
    printf("  \"Fresh Continuous Optimizations\" Search Strategy 3\n");
    printf("\n");
    printf("  Copyright (C) 2004-2006 by Grigori G.Fursin\n");
    printf("  Partially based on EOS Software (Copyright (C) 2000-2004)\n");
    printf("\n");
    printf("  http://homepages.inf.ed.ac.uk/gfursin\n");
    printf("\n");
    printf("  INRIA Futurs, France\n");
    printf("  and ICSA, University of Edinburgh, UK\n");
    printf("\n");
    printf("Options (you can also add options into file %s):\n", FileOpt);
    printf("  --help, -h, -?                Help;\n");
    printf("  --version, -v                 Print version;\n");
    printf("  --verbose, -vb                Print additional diagnostic messages;\n");
    printf("\n");
    printf("  --mode_tr, -mtr <param>       Transformation mode:\n");
    printf("                                 1 - produce error if transformation is incorrect;\n");
    printf("  --mode_ign, -mig <param>       1 - ignore incorrect output;\n");
    printf("  --time_threshold, -tt <param> Time threshold for the execution to ignore;\n");
    printf("  --time_compare, -tc <param>   Time delta when selecting best transformation;\n");
    printf("  --tr_rnd, -tr <param>         Number of random tries;\n");

    return 0;
  }

  if (clp->GetParamLong(paramVerbose)==1)
  {
    //Help
    printf("\n");
    printf("Options:\n");
    printf("  Mode transformation     = %5u\n",    mode_tr);
    printf("  Mode ignore output      = %5u\n",    mode_ign);
    printf("\n");
    printf("  Time threshold          = %5.1f\n", _ftime_threshold);
    printf("  Time compare            = %5.1f\n", _ftime_compare);
    printf("\n");
    printf("  Random transformations  = %5u\n",   tr_rnd);
    printf("\n");
    printf("  SNL          in use     = %5u\n", tr_snl);
    printf("  SIMD         in use     = %5u\n", tr_simd);
    printf("  FF           in use     = %5u\n", tr_ff);
    printf("  Inline       in use     = %5u\n", tr_inline);
    printf("  Unroll       in use     = %5u\n", tr_unroll);
    printf("  Unroll       parameters = %5u, %5u, %5u\n", tr_unroll_min, tr_unroll_max, tr_unroll_step);
    printf("  Interchange  in use     = %5u\n", tr_interchange);
    printf("  Reg. tiling  in use     = %5u\n", tr_regt);
    printf("  Reg. tiling  parameters = %5u, %5u, %5u\n", tr_regt_min,   tr_regt_max,   tr_regt_step);
    printf("  Tiling       in use     = %5u\n", tr_t);
    printf("  Tiling       parameters = %5u, %5u, %5u\n", tr_t_min,      tr_t_max,      tr_t_step);
    printf("  Prefetch     in use     = %5u\n", tr_pf);
    printf("  Prefetch     parameters = %5u, %5u, %5u\n", tr_pf_min,     tr_pf_max,     tr_pf_step);
    printf("  Pad. global  in use     = %5u\n", tr_pg);
    printf("  Pad. global  parameters = %5u, %5u, %5u\n", tr_pg_min,     tr_pg_max,     tr_pg_step);
    printf("  Pad. local   in use     = %5u\n", tr_pl);
    printf("  Pad. local   parameters = %5u, %5u, %5u\n", tr_pl_min,     tr_pl_max,     tr_pl_step);
    printf("\n");
  }

  //*********************************************************  
  printf("Reading original execution time: ");

  sprintf(str2, _fic ".%06u" _fic_tim, 0);
  t1=getTime1(str2);
  t2=getTime2(str2);
  ttB=t1+t2;
  printf("user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, ttB);

  printf("\n");
  printf("Reading last iteration number ...\n");
  
  iterX=readLastIteration(_fic _fic_cur);
  iterX++;

  if (iterX==0)
  {
    printf("Mode: first run\n");
    printf("\n");
    printf("Please, run fco first!\n");
  }
  else
  {
    printf("Mode: continuous optimizations\n");
    printf("      last iteration=%u\n", iterX-1);

    //prepare db_r
    iter0=0;
    sprintf(db_r, _fic ".%06u" _fic_db, iter0);

    long tr_max=findNumberOfTransformations(db_r);

    printf("\n");
    printf("Number of original transformations: %u\n", tr_max);

    long trx=1;    

    while(trx<=tr_max)
    {
      printf(sep1 "\n");
      printf("Current transformation: %u\n", trx);

      //to transform all functions, put "" instead of _fff
      int tr=0;
      
      setDBIO(db_r, db_w);
      tr=getTransformation(trx, _fff);

      getCurTransformationFunc(str1);
      printf("Current function      : %s\n", str1);
      
      getCurTransformationID(str1);
      printf("Current tr. name      : %s\n", str1);

      if (tr<0) 
      {
        printf("\n");
        printf("This transformation is skipped!\n");
      }
      else
      {
        if (tr_unroll==1 && tr==iid_tr_unroll)
        {
          //************************************* UNROLL *************************************
          found=false;
          infl=false;

          //disable transformation if needed
          findLineFromCurrentTransformation(id_unroll_fully, str2);
          if (atoi(str2)==1)
  	  {
            //1) disable full unroll
            iterD=iterB;
            printf(sep2 "\n");
            printf("Current sub-transformation: disable unroll fully (iter=%06u)\n", iter);

            if (iter>=iterX)
            {
              trPrep(iter, trx);
              recordLineTR(id_unroll_fully, "0", 2);
              recordLineTR(id_unroll_factor, "1", 2);

              if (disableTransformation(trx, _fff)<0) trFail(iter);
              else
              {
                trSuccess();

                sprintf(db_w, _fic ".%06u" _fic_db, iter);
                if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                  trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
              }
            }
            else trCheck(iter, &iterB, &ttB, &found, &infl);
             
            writeIteration(_fic _fic_cur, iter);
            iter++;
          }

          findLineFromCurrentTransformation(id_unroll_factor, str2);
          if (atoi(str2)!=1)
  	  {
            iterD=iterB;
            //1) disable full unroll
            printf(sep2 "\n");
            printf("Current sub-transformation: disable unroll (iter=%06u)\n", iter);

            if (iter>=iterX)
            {
              trPrep(iter, trx);
              recordLineTR(id_unroll_fully, "0", 2);
              recordLineTR(id_unroll_factor, "1", 2);

              if (disableTransformation(trx, _fff)<0) trFail(iter);
              else
              {
                trSuccess();

                sprintf(db_w, _fic ".%06u" _fic_db, iter);
                if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                  trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
              }
            }
            else trCheck(iter, &iterB, &ttB, &found, &infl);
             
            writeIteration(_fic _fic_cur, iter);
            iter++;
          }

	  //2) change parameters
#ifdef mode_exh
	  for (param=tr_unroll_min; param<=tr_unroll_max; param+=tr_unroll_step)
	  {
#else
	  for (paramr=1; paramr<=tr_rnd; paramr++)
	  {
            param=tr_unroll_min+(rand()%tr_unroll_max-tr_unroll_min);
#endif	 
            printf(sep2 "\n");
            printf("Current sub-transformation: unroll with factor %u (iter=%06u)\n", param, iter);

            if (iter>=iterX)
	    {
              trPrep(iter, trx);
              recordLineTR(id_unroll_fully, "0", 2);
              sprintf(str1, "%u", param);
              recordLineTR(id_unroll_factor, str1, 2);

              if (trUnroll(trx, _fff, param, mode_tr)<0) trFail(iter);
  	      else
	      {
                if (trDisable(iter, trx, _fff)>=0)
 	        {
                  trSuccess();
                  sprintf(db_w, _fic ".%06u" _fic_db, iter);
                  if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                    trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
	        }
              }
            }
            else trCheck(iter, &iterB, &ttB, &found, &infl);
            
            writeIteration(_fic _fic_cur, iter);
            iter++;
	  }

          if (found) trFound(iterB);
	  else if (!infl) trFound(iterD); //disable transformation if not influential
        }
        else if (tr_inline==1 && tr==iid_tr_inline)
	{
          //************************************* INLINE *************************************
          found=false;

          printf(sep2 "\n");
          printf("Current sub-transformation: invert inline (iter=%06u)\n", iter);

          if (iter>=iterX)
          {
            trPrep(iter, trx);

            param=getStatus(trx, _fff);
            if (param==0) param=1; else param=0;

            sprintf(str1, "%u", param);
            recordLineTR(id_status, str1, 2);

            printf("Status: %u\n", param);

            if (trInline(trx, _fff, param, mode_tr)<0) trFail(iter);
            else
            {
              if (trDisable(iter, trx, _fff)>=0)
	      {
                trSuccess();
                sprintf(db_w, _fic ".%06u" _fic_db, iter);
                if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                  trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
	      }
            }
          }
          else trCheck(iter, &iterB, &ttB, &found, &infl);
            
          writeIteration(_fic _fic_cur, iter);
          iter++;
          if (found) trFound(iterB);
	  else if (!infl && param==1) trFound(iterB); //if not influential and was disabled
	                                              //then let's enable it to allow
						      //more transformations potentially
        }
        else if (tr_ff==1 && tr==iid_tr_ff)
	{
          //************************************* FIZ_FUSE *************************************
          found=false;

          printf(sep2 "\n");
          printf("Current sub-transformation: invert fiz_fuse (iter=%06u)\n", iter);

          if (iter>=iterX)
          {
            trPrep(iter, trx);

            param=getStatus(trx, _fff);
            if (param==0) param=1; else param=0;

            sprintf(str1, "%u", param);
            recordLineTR(id_status, str1, 2);

            printf("Status: %u\n", param);

            if (trFF(trx, _fff, param, mode_tr)<0) trFail(iter);
            else
            {
              if (trDisable(iter, trx, _fff)>=0)
	      {
                trSuccess();
                sprintf(db_w, _fic ".%06u" _fic_db, iter);
                if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                  trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
	      }
            }
          }
          else trCheck(iter, &iterB, &ttB, &found, &infl);
            
          writeIteration(_fic _fic_cur, iter);
          iter++;
          if (found) trFound(iterB);
	  else if (!infl && param==0) trFound(iterB); //if not influential and was enabled
	                                              //let's keep it like that
        }
/*
        else if (tr_simd==1 && tr==iid_tr_simd)
	{
          //************************************* SIMD *************************************
          found=false;

          printf(sep2 "\n");
          printf("Current sub-transformation: invert simd vectorization (iter=%06u)\n", iter);

          if (iter>=iterX)
          {
            trPrep(iter, trx);

            param=getStatus(trx, _fff);
            if (param==0) param=1; else param=0;

            sprintf(str1, "%u", param);
            recordLineTR(id_status, str1, 2);
	    
            printf("Status: %u\n", param);

            if (trSIMD(trx, _fff, param, mode_tr)<0) trFail(iter);
            else
            {
              if (trDisable(iter, trx, _fff)>=0)
	      {
                trSuccess();
                sprintf(db_w, _fic ".%06u" _fic_db, iter);
                if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                  trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
	      }
            }
          }
          else trCheck(iter, &iterB, &ttB, &found, &infl);
            
          writeIteration(_fic _fic_cur, iter);
          iter++;
          if (found) trFound(iterB);
        }
        else if (tr_pf==1 && tr==iid_tr_pf)
        {
          //************************************* PREFETCH *************************************
          found=false;

#ifdef mode_exh
	  for (param=tr_pf_min; param<=tr_pf_max; param+=tr_pf_step)
          {
#else
          for (paramr=1; paramr<=tr_rnd; paramr++)
          {
            param=tr_pf_min+(rand()%tr_pf_max-tr_pf_min);
#endif
            printf(sep2 "\n");
            printf("Current sub-transformation: prefetch with offset %u (iter=%06u)\n", param, iter);

            if (iter>=iterX)
	    {
              trPrep(iter, trx);

              sprintf(str1, "%u", param);
              recordLineTR(id_pf_offset, str1, 2);

              if (trPrefetch(trx, _fff, param, mode_tr)<0) trFail(iter);
  	      else
	      {
                if (trDisable(iter, trx, _fff)>=0)
	        {
                  trSuccess();
                  sprintf(db_w, _fic ".%06u" _fic_db, iter);
                  if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                    trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
	        }
              }
            }
            else trCheck(iter, &iterB, &ttB, &found, &infl);
            
            writeIteration(_fic _fic_cur, iter);
            iter++;
	  }
          if (found) trFound(iterB);
        }
        else if (tr_pg==1 && tr==iid_tr_pad_global)
        {
          //************************************* PAD GLOBAL *************************************
          found=false;

#ifdef mode_exh
	  for (param=tr_pg_min; param<=tr_pg_max; param+=tr_pg_step)
	  {
#else
          for (paramr=1; paramr<=tr_rnd; paramr++)
          {
            param=tr_pg_min+(rand()%tr_pg_max-tr_pg_min);
#endif
            printf(sep2 "\n");
            printf("Current sub-transformation: pad global with factor %u (iter=%06u)\n", param, iter);

            if (iter>=iterX)
	    {
              trPrep(iter, trx);

              sprintf(str1, "%u", param);
              recordLineTR(id_array_pad, str1, 2);

              if (trPadGlobal(trx, _fff, param, mode_tr)<0) trFail(iter);
  	      else
	      {
                if (trDisable(iter, trx, _fff)>=0)
  	        {
                  trSuccess();
                  sprintf(db_w, _fic ".%06u" _fic_db, iter);
                  if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                    trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
  	        }
              }
            }
            else trCheck(iter, &iterB, &ttB, &found, &infl);
            
            writeIteration(_fic _fic_cur, iter);
            iter++;
	  }
          if (found) trFound(iterB);
        }
        else if (tr_snl==1 && tr==iid_tr_snl)
	{
          //************************************* SNL *************************************
          found=false;

          //save original database
          strcpy(db_rs, db_r);
          iter0s=iter0;
          ttB0s=ttB;

          //disable lnt
          param=getStatus(trx, _fff);
          if (param==1)
	  {
            printf(sep2 "\n");
            printf("Current sub-transformation: disable snl (iter=%06u)\n", iter);

            if (iter>=iterX)
            {
              trPrep(iter, trx);

              param=0;

              sprintf(str1, "%u", param);
              recordLineTR(id_status, str1, 2);
	    
              if (trSNL(trx, _fff, param, mode_tr)<0) trFail(iter);
              else
              {
                if (trDisable(iter, trx, _fff)>=0)
  	        {
                  trSuccess();
                  sprintf(db_w, _fic ".%06u" _fic_db, iter);
                  if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                    trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
	        }
              }
            }
            else trCheck(iter, &iterB, &ttB, &found, &infl);
            
            writeIteration(_fic _fic_cur, iter);
            iter++;
          }
          else
	  {
            //enable lnt to original + base on this transformation
            printf(sep2 "\n");
            printf("Current sub-transformation: enable snl (iter=%06u)\n", iter);

            if (iter>=iterX)
            {
              trPrep(iter, trx);

              param=1;

              sprintf(str1, "%u", param);
              recordLineTR(id_status, str1, 2);
	    
              if (trSNL(trx, _fff, param, mode_tr)<0) trFail(iter);
              else
              {
                if (trDisable(iter, trx, _fff)>=0)
  	        {
                  trSuccess();
                  sprintf(db_w, _fic ".%06u" _fic_db, iter);
                  if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                    trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
	        }
              }
            }
            else trCheck(iter, &iterB, &ttB, &found, &infl);
            
            //base the rest of LNT on this transformation
            printf("\nFollowing LNT sub-transformations will be temporaly based on the iter %u!\n", iter);
            sprintf(db_r, _fic ".%06u" _fic_db, iter);
            iter0=iter;
            setDBIO(db_r, db_w);
            ttB=t1+t2;

            writeIteration(_fic _fic_cur, iter);
            iter++;
	  }

          int n=getSNL_LoopNests(trx);
          int bs=getSNL_TilingStatus(trx);
          int b=0;
          if (bs!=0) b=getSNL_NumberOfTiles(trx);
	  
          printf(sep2 "\n");
          printf("Number of loop nests: %u\n", n);
          printf("Tiling status:        %u\n", bs);
          printf("Number of tiles:      %u\n", b);

          if (n>1)
	  {
            //init
            int i=0;
            int j=0;
            int k=0;
	    int r=0;
	    int s=0;
	    int temp=0;

            //****************************************************
            //try unoptimized version and base on it
	    for (i=1; i<=n; i++)
	    {
              snl_i[i]=i;
	      snl_r[i]=1;

              snl_bi[i]=snl_i[i];
	      snl_br[i]=snl_r[i];
	    }
	    
            printf(sep2 "\n");
            printf("Current sub-transformation: enable basic snl (iter=%06u)\n", iter);

            if (iter>=iterX)
            {
              trPrep(iter, trx);

              param=1;

              sprintf(str1, "%u", param);
              recordLineTR(id_status, str1, 2);
	    
              if (trSNL_All(trx, _fff, n, snl_i, snl_r, 0, NULL, NULL, NULL, mode_tr)<0) trFail(iter);
              else
              {
                if (trDisable(iter, trx, _fff)>=0)
  	        {
                  trSuccess();
                  sprintf(db_w, _fic ".%06u" _fic_db, iter);
                  if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                    trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
	        }
              }
            }
            else trCheck(iter, &iterB, &ttB, &found, &infl);
            
            //base the rest of LNT on this transformation
            printf("\nFollowing LNT sub-transformations will be temporaly based on the iter %u!\n", iter);
            sprintf(db_r, _fic ".%06u" _fic_db, iter);
            iter0=iter;
            setDBIO(db_r, db_w);
            ttB=t1+t2;

            writeIteration(_fic _fic_cur, iter);
            iter++;

            //****************************************************

            //use original ones
            getTransformation(trx, _fff); //to init

            findLineFromCurrentTransformation(id_lnt_outer, str1);
            int lo=atoi(str1);
	    for (i=1; i<=n; i++)
	    {
              findLineFromCurrentTransformationX(id_lnt_new_loop_order, str1, i-1);
              snl_i[i]=atoi(str1)-lo+1;

              findLineFromCurrentTransformationX(id_lnt_new_reg_tiling, str1, i-1);
	      snl_r[i]=atoi(str1);

              snl_bi[i]=snl_i[i];
	      snl_br[i]=snl_r[i];
	    }

            if (b>0)
	    {
              //disable only tiling
	      
	      
	      
	      
	    }
	    
            //disable only reg. tiling
	    
	    
	    
	    //disable only reg. tiling & tiling



            //change some parameters but do not change the rest











            if (tr_interchange==1)
	    {
  	      for (i=1; i<=n; i++)
	      {
                snl_i[i]=i;
   	        snl_r[i]=1;
	      }

              i=1;
#ifdef mode_exh
              while (i)
#else
              paramr=1;
              while (paramr<=tr_rnd)
#endif
              {
                printf(sep2 "\n");
                printf("Current sub-transformation: loop interchange permutations:", n);
  
                for (k=1; k<=n; k++) printf(" %2u", snl_i[k]);

                printf(" (iter=%06u)\n", iter);

                found1=found;
                found=false;
                if (iter>=iterX)
                {
                  trPrep(iter, trx);
  
                  trPrepSNL(n, snl_i, snl_r, 0, NULL, NULL, NULL);
  
                  if (trSNL_All(trx, _fff, n, snl_i, snl_r, 0, NULL, NULL, NULL, mode_tr)<0) trFail(iter);
                  else
                  {
                    if (trDisable(iter, trx, _fff)>=0)
       	            {
                      trSuccess();
                      sprintf(db_w, _fic ".%06u" _fic_db, iter);
                      if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                        trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
	            }
                  }
                }
                else trCheck(iter, &iterB, &ttB, &found, &infl);
                if (found) for (k=1; k<=n; k++) snl_bi[k]=snl_i[k];
                else found=found1;
    
                writeIteration(_fic _fic_cur, iter);
                iter++;

                //continue interchange permutations
#ifdef mode_exh
                //normail interchange
                i=n-1;
                while (snl_i[i]>snl_i[i+1]) i--;

                j=n;
                while (snl_i[i]>snl_i[j]) j--;
  
                temp=snl_i[i];
                snl_i[i]=snl_i[j];
                snl_i[j]=temp;

                r=n;
                s=i+1;

                while (r>s)
                {
                  temp=snl_i[r];
                  snl_i[r]=snl_i[s];
                  snl_i[s]=temp;
                  r--;
	          s++;
                }
#else
                //random interchange
                int fact=1;
	        for (i=1; i<=n; i++)
	        {
                  snl_i[i]=i;
                  fact*=i;
  	        }
                i=1;

                paramr++;
            
                param=rand()%fact;
            
                for (int a=1; a<=param; a++)
	        {
                  //normail interchange
                  i=n-1;
                  while (snl_i[i]>snl_i[i+1]) i--;
    
                  j=n;
                  while (snl_i[i]>snl_i[j]) j--;
  
                  temp=snl_i[i];
                  snl_i[i]=snl_i[j];
                  snl_i[j]=temp;
  
                  r=n;
                  s=i+1;

                  while (r>s)
                  {
                    temp=snl_i[r];
                    snl_i[r]=snl_i[s];
                    snl_i[s]=temp;
                    r--;
      	            s++;
                  }
  	        }
#endif	 
              }

#ifdef mode_acc
              //select the best
              for (k=1; k<=n; k++) snl_i[k]=snl_bi[k];
#else
              //select the best
              for (k=1; k<=n; k++) snl_i[k]=k;
#endif
            }

            //register tiling
            if (tr_regt==1)
	    {
              for (j=1; j<=n; j++) 
	      {
	        snl_r[j]=1;
              }

	      for (i=1; i<=n; i++)
	      {
#ifdef mode_exh
                for (param=tr_regt_min; param<=tr_regt_max; param+=tr_regt_step)
	        {
#else
 	        for (paramr=1; paramr<=tr_rnd; paramr++)
	        {
                  param=tr_regt_min+(rand()%tr_regt_max-tr_regt_min);
#endif
                  snl_r[i]=param;
              
                  printf(sep2 "\n");
                  printf("Current sub-transformation: reg tile with factor %u (iter=%06u)\n", param, iter);

                  found1=found;
                  found=false;
                  if (iter>=iterX)
  	          {
                    trPrep(iter, trx);
  
                    trPrepSNL(n, snl_i, snl_r, 0, NULL, NULL, NULL);
  
                    if (trSNL_All(trx, _fff, n, snl_i, snl_r, 0, NULL, NULL, NULL, mode_tr)<0) trFail(iter);
                    else
                    {
                      if (trDisable(iter, trx, _fff)>=0)
      	              {
                        trSuccess();
                        sprintf(db_w, _fic ".%06u" _fic_db, iter);
                        if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                          trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
  	              }
                    }
                  }
                  else trCheck(iter, &iterB, &ttB, &found, &infl);
                  if (found) for (k=1; k<=n; k++) snl_br[k]=snl_r[k];
                  else found=found1;
            
                  writeIteration(_fic _fic_cur, iter);
                  iter++;
                }

                //select the best
                snl_r[i]=snl_br[i];		
	      }
            }

            if (tr_t==1)
	    {
              //tiling
              int bm=1;
              bool found2=true;
              if (b>=0)
	      {
 	        for (i=1; (i<=b) && found2; i++) //tiling level
	        {
                  found2=false;
	          for (j=1; j<=n; j++) //loop
	          {
#ifdef mode_exh
                    for (param=tr_t_min; param<=tr_t_max; param+=tr_t_step)
	            {
#else
     	            for (paramr=1; paramr<=tr_rnd; paramr++)
	            {
                      param=tr_t_min+(rand()%tr_t_max-tr_t_min);
#endif
                      snl_t1[bm]=j-1;
                      snl_t2[bm]=param;
	      	      snl_t3[bm]=1; //cache level (I think this parameter doesn't matter -
  		                    //             just informative?)
  
                      printf(sep2 "\n");
                      printf("Current sub-transformation: tile loop %u with factor %u (iter=%06u)\n", j-1, param, iter);

                      found1=found;
                      found=false;
                      if (iter>=iterX)
                      {
                        trPrep(iter, trx);

                        trPrepSNL(n, snl_i, snl_r, bm, snl_t1, snl_t2, snl_t3);
  
                        if (trSNL_All(trx, _fff, n, snl_i, snl_r, bm, snl_t1, snl_t2, snl_t3, mode_tr)<0) trFail(iter);
                        else
                        {
                          if (trDisable(iter, trx, _fff)>=0)
    	                  {
                            trSuccess();
                            sprintf(db_w, _fic ".%06u" _fic_db, iter);
                            if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                              trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found, &infl);
  	                  }
                        }
                      }
                      else trCheck(iter, &iterB, &ttB, &found, &infl);
                      if (found) 
	  	      {  
                        found2=true;
		        snl_bt1[bm]=snl_t1[bm];
  		        snl_bt2[bm]=snl_t2[bm];
  		        snl_bt3[bm]=snl_t3[bm];
		      }
                      else found=found1;
              
                      writeIteration(_fic _fic_cur, iter);
                      iter++;
                    }
                  }

                  if (found2)
	          {
#ifdef mode_acc
                    //select the best
                    snl_t1[bm]=snl_bt1[bm];
                    snl_t2[bm]=snl_bt2[bm];
 	    	    snl_t3[bm]=snl_bt3[bm];
                    bm++;
#endif
	          }
                }
              }
            }
          }

          //restore original database
          strcpy(db_r, db_rs);
          iter0=iter0s;
          setDBIO(db_r, db_w);
 
          //now check if the temporal time is better then the original
	  if (ttB<ttB0s)
	  {
            if (found) trFound(iterB);
	    else ttB=ttB0s;
          }
	  else ttB=ttB0s;
	}
*/
        else
	{
          printf("Warning: unused transformation detected!\n");
	}
      }
      
      trx++;
      tr_max=findNumberOfTransformations(db_r);

      printf("\n");
    }

    printf(sep1 "\n");
    printf(sep1 "\n");
    printf("FINAL RESULTS:\n");

    sprintf(str2, _fic ".%06u" _fic_tim, 0);
    t1=getTime1(str2);
    t2=getTime2(str2);
    tt=t1+t2;

    printf("\n");

    if (iterB==0)
    {
      printf("Time original = %6.1f\n", tt);
      printf("\n");
      printf("Better transformations not found!\n");
    }
    else
    {
      printf("Time original = %6.1f s.\n", tt);
      printf("Time best     = %6.1f s.\n", ttB);
      
      printf("\n");
      printf("Iter best     = %06u\n", iterB);

      double impr=((tt-ttB)/tt)*100;
      sprintf(str1, "Performance improvement = %3.1f%%\n", impr);

      printf("\n");
      printf(str1);

      printf(sep1 "\n");
      printf("\n");
    }
  }
  
  return 0;
}

void trFail(long iter)
{
  recordLineTR(id1_performed, "0", 2);
  sprintf(str2, "transformation failed (%s)!\n", getLastTransformationMessage());
  recordLineTR(id1_warn, str2, 2);

  printf("\n");
  printf("Warning: %s\n", str2);
  printf("\n");

  sprintf(str2, _fic ".%06u" _fic_inf, iter);
  writeIterStatus(str2, 0, 0, 0);
}

void trPrep(long iter, long t)
{
  int tr=getTransformation(t, _fff); //to initialize current transformation

//  sprintf(db_r, _fic ".%06u" _fic_db, 0);
  setDBIO(db_r, _ftmp_dbw);

  sprintf(str1, _fic ".%06u" _fic_tri1, iter);   //info about transformations
  sprintf(str2, _fic ".%06u" _fic_tri2, iter);   //info about transformations
  startTRInfo(str1, str2);
 
  sprintf(str1, "%u", iter0);
  recordLineTR(id1_in, str1, 1);

  sprintf(str1, _fic ".%06u" _fic_tri1, iter0); 
  sprintf(str2, "%u", iter);                
  appendLineTR(str1, id1_out, str2);

  startNewTR(2);
  recordLineTR(id1_tr, getLastTransformationID(),2);
  sprintf(str1, "%lu", getLastTransformationPOS());
  recordLineTR(id1_pos, str1, 2);
  getCurTransformationFunc(str1);
  recordLineTR(id_func, str1, 2);
}

void trPrepSNL(int n, int* ai, int* ar, int bn, int* b1, int* b2, int* b3)
{
  int i=0;
  
  recordLineTR(id_status, "1", 2);

  for (i=1; i<=n; i++)
  {
    sprintf(str1, "%u", i-1); //internal numbering of loops starts from 0
    recordLineTR(id_lnt_loop_number, str1, 2);

    sprintf(str1, "%u", ai[i]-1);
    recordLineTR(id_lnt_new_loop_order, str1, 2);

    sprintf(str1, "%u", ar[i]);
    recordLineTR(id_lnt_new_reg_tiling, str1, 2);
  }

  if (bn==0) recordLineTR(id_lnt_blocking_status, "0", 2);
  else
  {
    sprintf(str1, "%u", bn);
    recordLineTR(id_lnt_nbl, str1, 2);

    for (i=1; i<=bn; i++)
    {
      sprintf(str1, "%u", b1[i]);
      recordLineTR(id_lnt_iln, str1, 2);

      sprintf(str1, "%u", b2[i]);
      recordLineTR(id_lnt_loop_strip, str1, 2);

      sprintf(str1, "%u", b3[i]);
      recordLineTR(id_lnt_cache_level, str1, 2);
    }
  }
}

void trSuccess(void)
{
  recordLineTR(id1_performed, "1", 2);
}

int trDisable(long iter, long tr, char* func)
{
  int ret=0;

#ifdef mode_dis
  printf("        --- disabling all transformations after ---\n");
  long iterX=0;

  strcpy(str1, getDBR());
  strcpy(str2, getDBW());

  setDBIO(_ftmp_dbw, _ftmp_dbw1);

  int dis=1;
  disableAllAfterTr(tr, func, _ftmp_dbr1);

  while ((ret==0) && (dis!=0))
  {
    printf("        sub-iter: %u\n", iterX);
    tr++;
    iterX++;

    printf("                  compiling\n");
    setFComp(_fcomp1, _fcomp_mode_rw, _ftmp_dbw1, _ftmp_dbw);
    system(_fcomp);

    double t1=getTime1(_ftimec);
    double t2=getTime2(_ftimec);
    double tt=t1+t2;
    printf("                  compile time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    setDBIO(_ftmp_dbw, _ftmp_dbw1);

    if (fileExist(_fout)!=1)
    {
      printf("                  warning: a.out is not created!\n");
      ret=-1;
      sprintf(str2, _fic ".%06u" _fic_inf, iter);
      writeIterStatus(str2, 0, 0, 0);
    }

    dis=disableAllAfterTr(tr, func, _ftmp_dbr1);
  }

  setDBIO(str1, str2);

  printf("        -------------------------------------------\n");
#endif

  return ret;
}

int trCompile(long iter, double* t1, double* t2, char* dbr, char* dbw)
{
  int ret=0;
  
  printf("Set fcompilation to Read/Write\n");
  setFComp(_fcomp1, _fcomp_mode_rw, dbr, dbw);

  printf("Compile program ...\n");
  system(_fcomp);

  *t1=getTime1(_ftimec);
  *t2=getTime2(_ftimec);
  double tt=(*t1)+(*t2);
  printf("Compile Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", *t1, *t2, tt);

  sprintf(str2, _fic ".%06u" _fic_timc, iter);
  writeTime(str2, *t1, *t2);
    
  if (fileExist(_fout)!=1)
  {
    printf("Warning: a.out is not created!\n");
    ret=-1;
    sprintf(str2, _fic ".%06u" _fic_inf, iter);
    writeIterStatus(str2, 0, 0, 0);
  }

  return ret;
}

void trRun(long iter, double* t1, double* t2, int* inf1, int* inf2, 
           long* iterB, double* ttB, int mode, bool* found, bool* infl)
{
  printf("Run program ...\n");
  system(_frun);

  printf("\n");
      
  *t1=getTime1(_ftime);
  *t2=getTime2(_ftime);
  double tt=(*t1)+(*t2);
  printf("Run Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", *t1, *t2, tt);
  printf("                                        best=(%6.1f), iter=(%06u)\n", *ttB, *iterB);

  sprintf(str2, _fic ".%06u" _fic_tim, iter);
  writeTime(str2, *t1, *t2);

  *inf1=1;
  *inf2=1;
	
  printf("\n");
  if (tt<_ftime_threshold)
  {
    *inf1=0;
    printf("Warning: Execution time too low!\n");
  }
  if (fileDiffCorrect(_fdiff, _ftmp_diff)!=1)
  {
    *inf2=0;
    printf("Warning: Output is different from the original!\n");
  }

  if (((*inf2==0) && (mode==0)) || (*inf2==1))
  {
    //compare time
    if (tt<((*ttB)-_ftime_compare))
    {
      printf("\n");
      printf("BETTER TIME (%6.1f [iter=%06u]   <   %6.1f [iter=%06u]\n", tt, iter, *ttB, *iterB);

      *ttB=tt;
      *iterB=iter;

      *found=true;

      recordLineTR(id1_better, "1", 2);
    }
    else if (tt>((*ttB)+_ftime_compare))
    {
      printf("\n");
      printf("INFLUENTIAL (%6.1f [iter=%06u]   >   %6.1f [iter=%06u]\n", tt, iter, *ttB, *iterB);

      *infl=true;

      recordLineTR(id1_infl, "1", 2);
    }

  }

  sprintf(str2, _fic ".%06u" _fic_inf, iter);
  writeIterStatus(str2, 1, *inf1, *inf2);

  //saving executable file
  sprintf(str1, _fic ".%06u." _fout, iter);
  rename(_fout, str1);
}

void trCheck(long iter, long* iterB, double* ttB, bool* found, bool* infl)
{
  double t1,t2;
  
  sprintf(str1, _fic ".%06u" _fic_tri1, iter);   //info about transformations
  sprintf(str2, _fic ".%06u" _fic_tri2, iter);   //info about transformations
  startTRInfo1(str1, str2);

  if (findLineFromCurrentTransformationTR(id1_better, str1, 2)==1)
  {
    if (atoi(str1)==1)
    {
      sprintf(str2, _fic ".%06u" _fic_tim, iter);
      t1=getTime1(str2);
      t2=getTime2(str2);
      *ttB=t1+t2;

      *iterB=iter;

      *found=true;

      printf("\n");
      printf("BETTER TIME (%6.1f)   [read from file]\n", *ttB);
    }
  }
  else if (findLineFromCurrentTransformationTR(id1_infl, str1, 2)==1)
  {
    if (atoi(str1)==1)
    {
      *infl=true;

      printf("\n");
      printf("INFLUENTIAL           [read from file]\n", *ttB);
    }
  }
}

void trFound(long iterB)
{
#ifdef mode_acc
  iter0=iterB;

  printf("-------------------------------------------------------------------------------\n");
  printf("Following transformations will be based on iter=%06u\n", iter0);
  sprintf(db_r, _fic ".%06u" _fic_db, iter0);

  setDBIO(db_r, db_w);
#endif
}
