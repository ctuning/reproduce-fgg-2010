/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "ftransformations.h"
#include "futils.h"
#include "fids.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fcomp     "_fbcomp"          //compile batch file
#define _frun      "_fbrun"           //run batch file
#define _fcopy     "_fbcopy"          //copy1 batch file
#define _fdiff     "_fbdiff"          //diff1 batch file
#define _fclean1   "_fbclean1"        //clean std files
#define _fff       "_finfo_funcs"     //file with the list of functions to transform
#define _fic       "_finfo_iter"      //current iteration
#define _fic_cur   ".cur"             //extension for current iteration
#define _fic_db    ".fdb"             //extension for transformation database
#define _fic_tim   ".time"            //extension for time (run)
#define _fic_timc  ".timec"           //extension for time (compilation)
#define _fic_inf   ".info"            //extension for info
#define _fic_tri1  ".tr_i1"           //extension for transformation info1
#define _fic_tri2  ".tr_i2"           //extension for transformation info2
#define _fcomp1    "fcompilation"     //file for FCompilation
#define _fout      "a.out"            //exe file
#define _ftime     "ftmp_time"        //file with time
#define _ftmp_diff "ftmp_diff"        //file with diff
#define _ftmp_dbr  "ftmp_dbr.tmp"     //tmp db file (read)
#define _ftmp_dbw  "ftmp_dbw.tmp"     //tmp db file (write)
#define _ftmp_dbw1 "ftmp_dbw1.tmp"    //tmp1 db file (write)

#define _ftime_threshold 0.5       //Problems with execution

#define _fcomp_mode_0  0         
#define _fcomp_mode_w  2
#define _fcomp_mode_r  3
#define _fcomp_mode_rw 4

char str1[1024]; //Not very clean, should change when have time
char str2[1024];

int main(int argc, char* argv[])
{
  double tt=0;
  double t1=0;
  double t2=0;

  long iter=1;

  printf("FCO Strategy 1\n");

  printf("\n");
  printf("Reading last iteration number ...\n");
  
  iter=readLastIteration(_fic _fic_cur);
  iter++;

  if (iter==0)
  {
    printf("Mode: first run\n");
    printf("\n");
    printf("Please, run fco first!\n");
  }
  else
  {
    printf("Mode: continuous optimizations (last iteration=%u) ...\n", iter-1);

    //check number of all transformations
    sprintf(str1, _fic ".%06u" _fic_db, 0);

    long tr_max=findNumberOfTransformations(str1);

    printf("\n");
    printf("Number of original transformations: %u\n", tr_max);

    if (iter>tr_max)
    {
      printf("Warning: optimization is finished!\n");
      exit(1);
    }

    while(iter<=tr_max)
    {
      printf("===============================================================================\n");
      printf("Current iteration: %u\n", iter);

      sprintf(str1, _fic ".%06u" _fic_db, 0);    //orig input
      setDBIO(str1, _ftmp_dbw);                  //tmp output

      sprintf(str1, _fic ".%06u" _fic_tri1, iter);   //info about transformations
      sprintf(str2, _fic ".%06u" _fic_tri2, iter);   //info about transformations
      startTRInfo(str1, str2);

      recordLineTR(id1_in, "0", 1);

      sprintf(str1, _fic ".%06u" _fic_tri1, 0); 
      sprintf(str2, "%u", iter);                
      appendLineTR(str1, id1_out, str2);

      //to transform all functions, put "" instead of _fff
      if (disableTransformation(iter, _fff)<0)
      {
        startNewTR(2);
        recordLineTR(id1_tr, getLastTransformationID(),2);
        sprintf(str1, "%lu", getLastTransformationPOS());
        recordLineTR(id1_pos, str1, 2);
        getCurTransformationFunc(str1);
        recordLineTR(id_func, str1, 2);
        recordLineTR(id1_op, id1_enable, 2);
        recordLineTR(id1_performed, "0", 2);
        sprintf(str2, "transformation failed (%s)!\n", getLastTransformationMessage());
        recordLineTR(id1_warn, str2, 2);

	printf("\n");
        printf("Warning: %s\n", str2);
	printf("\n");

        sprintf(str2, _fic ".%06u" _fic_inf, iter);
        writeIterStatus(str2, 0, 0, 0);
      }
      else
      {
        //compile
        startNewTR(2);
        recordLineTR(id1_tr, getLastTransformationID(),2);
        sprintf(str1, "%lu", getLastTransformationPOS());
        recordLineTR(id1_pos, str1,2);
        getCurTransformationFunc(str1);
        recordLineTR(id_func, str1, 2);
        recordLineTR(id1_op, id1_disable,2);
        recordLineTR(id1_performed, "1", 2);

        sprintf(str2, "disable transformation: %s\n", getLastTransformationID());

	printf("\n");
        printf(str2);
	printf("\n");

        printf("Set fcompilation to Read/Write\n");

//        sprintf(str2, _fic ".%06u" _fic_db, iter);
//        we do not create db each iteration anymore
//        because we can recreate it

        setFComp(_fcomp1, _fcomp_mode_rw, _ftmp_dbw, _ftmp_dbw1);
    
        printf("Compile program ...\n");
        system(_fcomp);

        t1=getTime1(_ftime);
        t2=getTime2(_ftime);
        tt=t1+t2;
        printf("Compile Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

        sprintf(str2, _fic ".%06u" _fic_timc, iter);
        writeTime(str2, t1, t2);
    
        if (fileExist(_fout)!=1)
        {
          sprintf(str2, _fic ".%06u" _fic_inf, iter);
          writeIterStatus(str2, 0, 0, 0);
        }
        else
        {
          printf("Run program ...\n");
          system(_frun);

          printf("\n");
      
          t1=getTime1(_ftime);
          t2=getTime2(_ftime);
          tt=t1+t2;
          printf("Run Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

          sprintf(str2, _fic ".%06u" _fic_tim, iter);
          writeTime(str2, t1, t2);

          int inf1=1;
  	  int inf2=1;
	
          printf("\n");
          if (tt<_ftime_threshold)
          {
            inf1=0;
            printf("Warning: Execution time too low!\n");
          }
          if (fileDiffCorrect(_fdiff, _ftmp_diff)!=1)
          {
            int inf2=0;
            printf("Warning: Output is different from the original!\n");
          }

          sprintf(str2, _fic ".%06u" _fic_inf, iter);
          writeIterStatus(str2, 1, inf1, inf2);
        }      
      }
      
      printf("\n");

      writeIteration(_fic _fic_cur, iter);
      iter++;
    }
  }
  
  return 0;
}
