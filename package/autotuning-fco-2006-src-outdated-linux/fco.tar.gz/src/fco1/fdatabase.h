/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#ifndef fdatabase_INCLUDED
#define fdatabase_INCLUDED

int FCheckCompState(void);
int FuncCheck(char* str);

void fparse(char* str);
void fparse1(char* str);

void startNewRecord();
void recordLine(char* id, char* str);
void recordLineTR(char* id, char* str, int i);
void recordLineTMP(char* id, char* str);
void recordFromFile(char* id, char* ftmpname);
void setPositionToStart(void);
void setPositionToStartW(void);
int findTransformation(char* id);
int findTransformationByNumber(long pos);
int findLineFromCurrentTransformationTR(char* id, char* str, int m);
int findLineFromCurrentTransformation(char* id, char* str);
int findLineFromCurrentTransformationX(char* id, char* str, int i);
int findLineFromCurrentTransformationW(char* id, char* str);
int findLineFromCurrentTransformationY(char* id, char* str, char* fl);
int findTransformationW(char* id);
void writeDBtoTMPbeforeCurTrW(void);
void writeDBtoTMPbeforeCurTr(void);
void writeDBtoTMPafterCurTrAndRenameBackW(void);
void writeDBtoTMPafterCurTrAndRenameBack(char* id);
int appendDBtoTMPbeforeID(char* id, char* str);
long long getCurrentPosition(void);

void setDBIO(char* str1, char* str2);
void startTRInfo(char* str1, char* str2);
void startTRInfo1(char* str1, char* str2);
void startNewTR(int i);
long findNumberOfTransformations(char* db);
int getCurTransformationID(char* str);
int getCurTransformationFunc(char* str);
int checkCurFuncToTransform(char* fname);
int matchTransformationWithID(char* str);
void matchIDWithTransformation(char* str, int id);
long long getLastTransformationPOS(void);
void appendLineTR(char* str1, char* str2, char* str3);

void initReadTR(char* str);
int findNextTR(void);
int findLineFromCurrentTR(char* id, char* str);

int findLineFromFile(char* id, char* str, char* fl);    

char* getDBR(void);
char* getDBW(void);

#endif // fdatabase_INCLUDED
