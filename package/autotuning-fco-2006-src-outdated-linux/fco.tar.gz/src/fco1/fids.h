/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#ifndef fids_INCLUDED
#define fids_INCLUDED

//ids
#define id_tr                   "transformation="

#define id_tr_pf                "prefetch"
#define iid_tr_pf               0
#define id_tr_snl               "loop_nest_transformations"
#define iid_tr_snl              1
#define id_tr_simd              "simd_vectorization"
#define iid_tr_simd             2
#define id_tr_unroll            "unrolling"
#define iid_tr_unroll           3
#define id_tr_ff                "fiz_fuse"
#define iid_tr_ff               4
#define id_tr_inline            "inline"
#define iid_tr_inline           5
#define id_tr_pad_local         "pad_local"
#define iid_tr_pad_local        6
#define id_tr_pad_global        "pad_global"
#define iid_tr_pad_global       7

#define id_tr_manual            "manual"
#define iid_tr_manual            8

#define iid_tr_max              8

#define id_ignore_the_rest      "ignore_the_rest="

#define id_func                 "function="
#define id_status               "status="
#define id_rem                  "rem="
#define id_line                 "line="
#define id_array                "array="

#define id_pf_id                "prefetch_id="
#define id_pf_offset            "prefetch_offset="

#define id_lnt_id               "lnt_loop_id="
#define id_lnt_nd               "lnt_nest_depth="
#define id_lnt_outer            "lnt_first_loop_to_transform="
#define id_lnt_loop_number      "lnt_loop_number="
#define id_lnt_new_loop_order   "lnt_new_loop_order="
#define id_lnt_new_reg_tiling   "lnt_new_reg_tiling="
#define id_lnt_blocking_status  "lnt_blocking_status="
#define id_lnt_nbl              "lnt_number_of_blocking_levels="
#define id_lnt_iln              "lnt_internal_loop_number="
#define id_lnt_loop_strip       "lnt_loop_strip="
#define id_lnt_cache_level      "lnt_cache_level="

#define id_simd_loop_id         "simd_loop_id="
#define id_simd_symbol          "simd_symbol="
#define id_simd_vectors         "simd_vectors="
#define id_simd_ut              "simd_unroll_times="
#define id_simd_atb             "simd_add_to_base="

#define id_unroll_loop_id       "unroll_loop_id="
#define id_unroll_fully         "unroll_fully="
#define id_unroll_factor        "unroll_factor="

#define id_ff_id                "ff_id="
#define id_ff_loop1_name        "ff_loop1_name="
#define id_ff_loop1_line        "ff_loop1_line="
#define id_ff_loop2_name        "ff_loop2_name="
#define id_ff_loop2_line        "ff_loop2_line="
#define id_ff_type              "ff_type="
#define id_ff_prolog            "ff_prolog="
#define id_ff_epilog            "ff_epilog="
#define id_ff_threshold         "ff_threshold="
#define id_ff_fission_level     "ff_fission_level="

#define id_inline_caller        "inline_caller="
#define id_inline_callee        "inline_callee="
#define id_inline_edge          "inline_edge="
#define id_inline_reason        "inline_reason="

#define id_array_dims           "array_dimensions="
#define id_array_dim            "array_dim="
#define id_array_lbo            "array_lower_bound_original="
#define id_array_ubo            "array_upper_bound_original="
#define id_array_lbn            "array_lower_bound_new="
#define id_array_ubn            "array_upper_bound_new="

#define id_array_common         "array_common="
#define id_array_pad            "array_pad="

//information about transformations
#define id1_tr                  "transformation="
#define id1_pos                 "position="
#define id1_op                  "operation="
#define id1_disable             "disable"
#define id1_enable              "enable"
#define id1_performed           "performed="
#define id1_warn                "warning="
#define id1_better              "better="

#define id1_in                  "in="
#define id1_out                 "out="

#endif // fids_INCLUDED

