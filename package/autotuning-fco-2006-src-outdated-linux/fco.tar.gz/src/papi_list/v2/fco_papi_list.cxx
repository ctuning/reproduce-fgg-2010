/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include <papi.h>
#include <stdio.h>
#include <stdlib.h>

#define _fp       "_finfo_papi"

char str1[1024];  //Not very clean, should change when have time
char str2[1024];

int main(int argc, char* argv[])
{
  FILE* ff;

  int retval, i;
  int EventSet=PAPI_NULL, count = 0;
  long_long values;
  PAPI_event_info_t info;

  printf("FCO PAPI List\n");
 
  if ((ff=fopen(_fp, "w"))==NULL)
  {
    printf("ERROR: Can't open file to save PAPI events...\n");
    exit(1);
  }

  retval = PAPI_library_init(PAPI_VER_CURRENT);
  if (retval != PAPI_VER_CURRENT)
  {
    printf("Error: PAPI_library_init\n");
    exit(1);
  }

  retval = PAPI_create_eventset(&EventSet);
  if (retval != PAPI_OK)
  {
    printf("Error: PAPI_create_eventset\n");
    exit(1);
  } 

  for (i = 0; i < PAPI_MAX_PRESET_EVENTS; i++) 
  {
    if (PAPI_get_event_info(PAPI_PRESET_MASK|i, &info) != PAPI_OK) continue;
    if (!(info.count)) continue;

    retval = PAPI_add_event(EventSet, info.event_code);
    if (retval == PAPI_OK) 
    {
      printf("Added %s successful\n", info.symbol);
      fprintf(ff, "%d\n", info.event_code);
      fprintf(ff, "%s\n", info.symbol);

      count++;
    }
    retval = PAPI_remove_event(EventSet, info.event_code);
  }

  printf("\n");
  printf("Number of events recorded = %u\n", count);

  fclose(ff);
}
