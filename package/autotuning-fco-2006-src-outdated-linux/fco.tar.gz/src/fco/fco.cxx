/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "ftransformations.h"
#include "futils.h"
#include "fids.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fcomp     "_fbcomp"          //compile batch file
#define _frun      "_fbrun"           //run batch file
#define _fcopy     "_fbcopy"          //copy1 batch file
#define _fdiff     "_fbdiff"          //diff1 batch file
#define _fclean1   "_fbclean1"        //clean std files
#define _fff       "_finfo_funcs"     //file with the list of functions to transform
#define _fic       "_finfo_iter"      //current iteration
#define _fic_cur   ".cur"             //extension for current iteration
#define _fic_db    ".fdb"             //extension for transformation database
#define _fic_tim   ".time"            //extension for time (run)
#define _fic_timc  ".timec"           //extension for time (compilation)
#define _fic_inf   ".info"            //extension for info
#define _fic_tri   ".tr_info"         //extension for transformation info
#define _fcomp1    "fcompilation"     //file for FCompilation
#define _fout      "a.out"            //exe file
#define _ftime     "ftmp_time"        //file with time (run)
#define _ftimec    "ftmp_timec"       //file with time (compilation)
#define _ftmp_diff "ftmp_diff"        //file with diff
#define _ftmp_dbr  "ftmp_dbr.tmp"     //tmp db file (read)
#define _ftmp_dbw  "ftmp_dbw.tmp"     //tmp db file (write)

#define _ftime_threshold 0.5       //Problems with execution

#define _fcomp_mode_0  0         
#define _fcomp_mode_w  2
#define _fcomp_mode_r  3
#define _fcomp_mode_rw 4

char str1[1024]; //Not very clean, should change when have time
char str2[1024];

int main(int argc, char* argv[])
{
  double tt=0;
  double t1=0;
  double t2=0;

  int iter=1;

  printf("FCO Start\n");

  iter=0;

  printf("\n");
  if (iter==0)
  {
    printf("Mode: first run ...\n");

    printf("\n");

    printf("Clean std files ...\n");
    system(_fclean1);

    printf("Clean fcompilation ...\n");
    setFComp(_fcomp1, _fcomp_mode_0, _ftmp_dbr, _ftmp_dbw);

    printf("Compile program ...\n");
    system(_fcomp);

    t1=getTime1(_ftimec);
    t2=getTime2(_ftimec);
    tt=t1+t2;
    printf("Compile Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    sprintf(str2, _fic ".%06u" _fic_timc, 0);
    writeTime(str2, t1, t2);

    if (fileExist(_fout)!=1)
    {
      printf("Error: Executable is not created!\n");
      exit(1);
    }

    printf("Run program ...\n");
    system(_frun);

    t1=getTime1(_ftime);
    t2=getTime2(_ftime);
    tt=t1+t2;
    printf("Run Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    sprintf(str2, _fic ".%06u" _fic_tim, iter);
    writeTime(str2, t1, t2);

    printf("Copy std files ...\n");
    system(_fcopy);

    printf("\n");
    
    t1=getTime1(_ftime);
    t2=getTime2(_ftime);
    tt=t1+t2;
    printf("Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    printf("\n");
    
    printf("Set fcompilation to Write\n");
    sprintf(str1, _fic ".%06u" _fic_db, 0);
    setFComp(_fcomp1, _fcomp_mode_w, _ftmp_dbr, str1);
    
    printf("Compile program ...\n");
    system(_fcomp);

    t1=getTime1(_ftimec);
    t2=getTime2(_ftimec);
    tt=t1+t2;
    printf("Compile Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    if (fileExist(_fout)!=1)
    {
      printf("Error: Executable is not created!\n");
      exit(1);
    }

    printf("Set fcompilation to Read\n");
    setFComp(_fcomp1, _fcomp_mode_r, str1, _ftmp_dbw);
    
    t1=getTime1(_ftimec);
    t2=getTime2(_ftimec);
    tt=t1+t2;
    printf("Compile Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    printf("Compile program ...\n");
    system(_fcomp);

    if (fileExist(_fout)!=1)
    {
      printf("Error: Executable is not created!\n");
      exit(1);
    }

    printf("Run program ...\n");
    system(_frun);

    printf("\n");
    
    t1=getTime1(_ftime);
    t2=getTime2(_ftime);
    tt=t1+t2;
    printf("Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    int inf1=1;
    int inf2=1;
 
    printf("\n");
    if (tt<_ftime_threshold)
    {
      inf1=0;
      printf("Warning: Execution time too low!\n");
    }
    if (fileDiffCorrect(_fdiff, _ftmp_diff)!=1)
    {
      int inf2=0;
      printf("Warning: Output is different from the original!\n");
    }

    sprintf(str2, _fic ".%06u" _fic_inf, 0);
    writeIterStatus(str2, 1, inf1, inf2);

    writeIteration(_fic _fic_cur, 0);
  }
  
  return 0;
}
