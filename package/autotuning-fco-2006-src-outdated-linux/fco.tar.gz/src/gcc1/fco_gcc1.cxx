/*
 * Copyright (C) 2004-2006 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "futils.h"

#define _fcomp     "_fbcomp"                   //compile batch file
#define _frun      "_fbrun"                    //run batch file

#define _fout1      "a.out"                    //exe file
#define _fout      "gcc_brain_params.out.txt"  //file with gcc params (out)
#define _fin       "gcc_brain_params.in.txt"   //file with gcc params (in)
#define _fext      ".gbp"                      //extension for file with gcc params

#define _finfo     "_finfo"
#define _fic       "_finfo_iter"               //current iteration
#define _fic_cur   ".cur"                      //extension for current iteration
#define _fic_tim   ".time"                     //extension for time (run)
#define _ftime     "ftmp_time"                 //file with time (run)

#define _fic_reps  ".report_short.txt"         //file with report (short)

char str1[1024];

void writeRep(char* name, double tt, long iter);

#define sep1 "==============================================================================="
#define sep2 "-------------------------------------------------------------------------------"
#define sep_tr "================================================================================"

#define rand_max  32000
#define rand_sel1     2
#define rand_sel2     6

int main(int argc, char* argv[])
{
  FILE* f;
  FILE* f1;
  
  long iter, iterM;
  double t1, t2, tt;
  int i;

  int iv, iv_min, iv_max;

  int param;

  /********************************************************************/
  printf("FCO GCC Strategy 1\n");

  iterM=32767;
  if (argc>=2)
  {
    iterM=atoi(argv[1]);
  }    
  printf("\n");
  printf("Number of iterations: %u\n", iterM);

  iter=readLastIteration(_fic _fic_cur);
  iter++;

  if (iter==0)
  {
    printf(sep1 "\n");
    printf("Mode: first run ...\n");

    //compile/run
    sprintf(str1, _fic ".%06u" _fext, iter);
    copyFile(_fout, str1);

    copyFile(_fout, _fin);
    system(_fcomp);

    sprintf(str1, "cp " _fout1 " " _fic ".%06u." _fout1, iter);
    system(str1);
    
    system(_frun);

    t1=getTime1(_ftime);
    t2=getTime2(_ftime);
    tt=t1+t2;
    printf("Run Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    sprintf(str1, _fic ".%06u" _fic_tim, iter);
    writeTime(str1, t1, t2);

    writeIteration(_fic _fic_cur, iter);
    iter++;
  }
  else
  {
    printf("Mode: continuous optimizations\n");
    printf("      last iteration=%u\n", iter-1);
  }

  while (iter<=iterM)
  {
    printf(sep1 "\n");
    printf("Iteration: %u ...\n", iter);
  
    //prepare GCC param in file
    i=0;
    sprintf(str1, _fic ".%06u" _fext, 0);
    f = fopen (str1, "r");
    if (f!=NULL)
    {
      f1 = fopen (_fin, "w");
      if (f1!=NULL)
      {
        i=0;
        while ((fgets(str1, 1023, f)!=NULL) && (feof(f)==0))
        {
          fputs(str1, f1);
          fparse1(str1);
        
          if (strcmp(str1, sep_tr)==0)
          {
            fgets(str1, 1023, f);
            iv=atoi(str1);

            fgets(str1, 1023, f);
            iv_min=atoi(str1);

            fgets(str1, 1023, f);
            iv_max=atoi(str1);

            param=rand() % rand_sel1;
            if (param==1)
	    {
              if (iv_min==0 && iv_max==0 && iv!=0)
	      {
                if (iv * rand_sel2 < rand_max) iv=(rand() % (iv * rand_sel2));
		else iv=(rand() % (rand_max)) * (iv * rand_sel2) / rand_max;
	      }
	      else if (iv_min<iv_max)
	      {
                if ((iv_max-iv_min+1) < rand_max) iv=iv_min + (rand()%(iv_max-iv_min+1));
		else iv=iv_min + (rand() % (rand_max)) * (iv_max-iv_min+1) / rand_max;
	      }  
	    }

            sprintf(str1, "%d\n", iv);
            fputs(str1, f1);
	    
            sprintf(str1, "%d\n", iv_min);
            fputs(str1, f1);

            sprintf(str1, "%d\n", iv_max);
            fputs(str1, f1);

            i++;
          }
        }

        fclose (f1);
      }
      else
      {
        printf("Error: Can't write file with GCC parameters (FBRAIN)\n");
      }

      fclose (f);
    }
    else
    {
      printf("Error: Can't find file with GCC parameters (FBRAIN)\n");
    }
  
    sprintf(str1, _fic ".%06u" _fext, iter);
    copyFile(_fin, str1);

    //compile/run
    system(_fcomp);

    sprintf(str1, "cp " _fout1 " "_fic ".%06u." _fout1, iter);
    system(str1);
    
    system(_frun);

    t1=getTime1(_ftime);
    t2=getTime2(_ftime);
    tt=t1+t2;
    printf("Run Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    sprintf(str1, _fic ".%06u" _fic_tim, iter);
    writeTime(str1, t1, t2);

    writeIteration(_fic _fic_cur, iter);
    iter++;
  }
}

void writeRep(char* name, double tt, long iter)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "at"))!=NULL)
  {
    fprintf(fil, "%20f %6u", tt, iter);
    fclose(fil);
  }
}
