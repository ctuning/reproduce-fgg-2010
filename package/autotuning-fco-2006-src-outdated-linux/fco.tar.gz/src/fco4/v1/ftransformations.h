/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#ifndef ftransformations_INCLUDED
#define ftransformations_INCLUDED

int getTransformation(long t, char* fname_funcs);

int disableTransformation(long t, char* fname_funcs);
int disableTransformationX(long iter, char* fname_funcs);
int disableAllAfterTr(long t, char* fname_funcs, char* ftmp);
int enableTransformation(long t, char* fname_funcs);

int trUnroll(long t, char* fname_funcs, int param, int mode);
int trUnrollFully(long t, char* fname_funcs, int mode);
int trInline(long t, char* fname_funcs, int param, int mode);
int trFF(long t, char* fname_funcs, int param, int mode);
int trSIMD(long t, char* fname_funcs, int param, int mode);
int trSNL(long t, char* fname_funcs, int param, int mode);
int trSNL_All(long t, char* fname_funcs, int n, int* ai, int* ar, 
              int bn, int* b1, int* b2, int* b3, int mode);
int trPrefetch(long t, char* fname_funcs, int param, int mode);
int trPadGlobal(long t, char* fname_funcs, int param, int mode);

int getStatus(long t, char* fname_funcs);
int getSNL_LoopNests(long t);
int getSNL_TilingStatus(long t);
int getSNL_NumberOfTiles(long t);

char* getLastTransformationMessage(void);
char* getLastTransformationID(void);

int getMaxNumFunc(char* name);
int getFunc(char* name, int n, char* str);

#endif // ftransformations_INCLUDED
