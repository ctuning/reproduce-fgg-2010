/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "ftransformations.h"
#include "fids.h"
#include "futils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static char last_message[1024];
static char tr_id[1024];

char stry1[1024];
char stry2[1024];
char stry3[1024];

char strz1[1024];
char strz2[1024];

int getTransformation(long t, char* fname_funcs)
{
  int ret=0;
  
  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  ret=tr;

  return ret;
}  

int getStatus(long t, char* fname_funcs)
{
  int ret=-1;
  
  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  if (findLineFromCurrentTransformation(id_status, stry1)==1) ret=atoi(stry1);

  return ret;
}  

int disableTransformation(long t, char* fname_funcs)
{
  int ret=0;
  
  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_pf || tr==iid_tr_simd || tr==iid_tr_ff 
      || tr==iid_tr_inline || tr==iid_tr_snl || tr==iid_tr_pad_local) 
  {
    appendDBtoTMPbeforeID(id_status, stry2);

    if (atoi(stry2)==0)
    {
      sprintf(last_message, "The transformation #%ld is already disabled", t);
      return -1;
    }

    //write position of the transformation
//xxx    writeCurPosToFile

    sprintf(stry1, "%d", 0);
    recordLineTMP(id_status, stry1);

    recordLineTMP(id_ignore_the_rest, "1");
 
    writeDBtoTMPafterCurTrAndRenameBack(id_status); 
  }
  else if (tr==iid_tr_unroll)
  {
    appendDBtoTMPbeforeID(id_unroll_fully, stry2);
    findLineFromCurrentTransformation(id_unroll_factor, stry3);

    if (atoi(stry2)==0 && atoi(stry3)==1)
    {
      sprintf(last_message, "The transformation #%ld is already disabled", t);
      return -1;
    }

    sprintf(stry1, "%d", 0);
    recordLineTMP(id_unroll_fully, stry1);
 
    sprintf(stry1, "%d", 1);
    recordLineTMP(id_unroll_factor, stry1);

    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_unroll_factor); 
  }
  else if (tr==iid_tr_pad_global)
  {
    appendDBtoTMPbeforeID(id_array_pad, stry2);

    if (atoi(stry2)==0)
    {
      sprintf(last_message, "The transformation #%ld is already disabled", t);
      return -1;
    }

    sprintf(stry1, "%d", 0);
    recordLineTMP(id_array_pad, stry1);

    recordLineTMP(id_ignore_the_rest, "1");
 
    writeDBtoTMPafterCurTrAndRenameBack(id_array_pad); 
  }
  
  return ret;
}

int disableAllAfterTr(long t, char* fname_funcs, char* ftmp)
{
  int ret=0;
  
  strcpy(strz1, getDBR());
  strcpy(strz2, getDBW());

  long tr_max=findNumberOfTransformations(getDBR());
  t++;

  while(t<=tr_max)
  {
    strcpy(last_message, "");

    if (findTransformationByNumber(t)!=1)
    {
      sprintf(last_message, "Can't find transformation #%ld", t);
      return -1;
    }

    int tr=getCurTransformationID(tr_id);

    bool transform=true;

    if (strcmp(fname_funcs, "")!=0 && (checkCurFuncToTransform(fname_funcs)!=1))
    {
      //transformation is not in the list - skip it
      transform=false;
    }
    else
    {
      //rewrite transformation
      writeDBtoTMPbeforeCurTr();

      if (tr==iid_tr_pf || tr==iid_tr_simd || tr==iid_tr_ff 
          || tr==iid_tr_inline || tr==iid_tr_snl || tr==iid_tr_pad_local) 
      {
        appendDBtoTMPbeforeID(id_status, stry2);
 
        if (atoi(stry2)==0) {}
        else ret=1;

        sprintf(stry1, "%d", 0);
        recordLineTMP(id_status, stry1);
 
        writeDBtoTMPafterCurTrAndRenameBack(id_status); 
      }
      else if (tr==iid_tr_unroll)
      {
        appendDBtoTMPbeforeID(id_unroll_fully, stry2);
        findLineFromCurrentTransformation(id_unroll_factor, stry3);

        if (atoi(stry2)==0 && atoi(stry3)==1)
        {}
        else ret=1;

        sprintf(stry1, "%d", 0);
        recordLineTMP(id_unroll_fully, stry1);
 
        sprintf(stry1, "%d", 1);
        recordLineTMP(id_unroll_factor, stry1);

        writeDBtoTMPafterCurTrAndRenameBack(id_unroll_factor); 
      }
      else if (tr==iid_tr_pad_global)
      {
        appendDBtoTMPbeforeID(id_array_pad, stry2);
 
        if (atoi(stry2)==0)
        {}
        else ret=1;

        sprintf(stry1, "%d", 0);
        recordLineTMP(id_array_pad, stry1);

        writeDBtoTMPafterCurTrAndRenameBack(id_array_pad); 
      }
    }
    
    t++;

    if (transform)
    {
      tr_max=findNumberOfTransformations(getDBW());

      remove(ftmp);
      rename(getDBW(), ftmp);

      setDBIO(ftmp, strz2);
    }
  }

  if (ret==0)
  {
    //no transformations occured - copy DBR to DBW
    copyFile(strz1, strz2);    
  }
  else
  {
    rename(ftmp, getDBW());
  }

  setDBIO(strz1, strz2);

  return ret;
}

//here not all transformations are disabled
//(transformations that change program layout are excluded)
int disableTransformationX(long iter, char* fname_funcs)
{
  int ret=0;
  
  strcpy(last_message, "");

  if (findTransformationByNumber(iter)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", iter);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", iter);
      return -1;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

//if (tr==iid_tr_pf || tr==iid_tr_simd || tr==iid_tr_ff 
//    || tr==iid_tr_inline || tr==iid_tr_snl || tr==iid_tr_pad_local) 
  if (tr==iid_tr_pf || tr==iid_tr_simd || tr==iid_tr_snl || tr==iid_tr_pad_local) 
  {
    appendDBtoTMPbeforeID(id_status, stry2);

    if (atoi(stry2)==0)
    {
      sprintf(last_message, "The transformation #%ld is already disabled", iter);
      return -1;
    }

    sprintf(stry1, "%d", 0);
    recordLineTMP(id_status, stry1);

    recordLineTMP(id_ignore_the_rest, "1");
 
    writeDBtoTMPafterCurTrAndRenameBack(id_status); 
  }
  else if (tr==iid_tr_unroll)
  {
    appendDBtoTMPbeforeID(id_unroll_fully, stry2);
    findLineFromCurrentTransformation(id_unroll_factor, stry3);

    if (atoi(stry2)==0 && atoi(stry3)==1)
    {
      sprintf(last_message, "The transformation #%ld is already disabled", iter);
      return -1;
    }

    sprintf(stry1, "%d", 0);
    recordLineTMP(id_unroll_fully, stry1);
 
    sprintf(stry1, "%d", 1);
    recordLineTMP(id_unroll_factor, stry1);

    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_unroll_factor); 
  }
  else if (tr==iid_tr_pad_global)
  {
    appendDBtoTMPbeforeID(id_array_pad, stry2);

    if (atoi(stry2)==0)
    {
      sprintf(last_message, "The transformation #%ld is already disabled", iter);
      return -1;
    }

    sprintf(stry1, "%d", 0);
    recordLineTMP(id_array_pad, stry1);

    recordLineTMP(id_ignore_the_rest, "1");
 
    writeDBtoTMPafterCurTrAndRenameBack(id_array_pad); 
  }
  
  return ret;
}

int enableTransformation(long t, char* fname_funcs)
{
  int ret=0;
  
  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_pf || tr==iid_tr_simd || tr==iid_tr_ff 
      || tr==iid_tr_inline || tr==iid_tr_snl || tr==iid_tr_pad_local) 
  {
    appendDBtoTMPbeforeID(id_status, stry2);

    if (atoi(stry2)==1)
    {
      sprintf(last_message, "The transformation #%ld is already enabled", t);
      return -1;
    }

    //write position of the transformation
//xxx    writeCurPosToFile

    sprintf(stry1, "%d", 1);
    recordLineTMP(id_status, stry1);

    recordLineTMP(id_ignore_the_rest, "1");
 
    writeDBtoTMPafterCurTrAndRenameBack(id_status); 
  }
  else if (tr==iid_tr_unroll)
  {
    appendDBtoTMPbeforeID(id_unroll_fully, stry2);
    findLineFromCurrentTransformation(id_unroll_factor, stry3);

    if (atoi(stry2)!=0 || atoi(stry3)!=1)
    {
      sprintf(last_message, "The transformation #%ld is already enabled", t);
      return -1;
    }

    sprintf(stry1, "%d", 0);
    recordLineTMP(id_unroll_fully, stry1);
 
    sprintf(stry1, "%d", 1);
    recordLineTMP(id_unroll_factor, stry1);

    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_unroll_factor); 
  }
  else if (tr==iid_tr_pad_global)
  {
    appendDBtoTMPbeforeID(id_array_pad, stry2);

    if (atoi(stry2)==0)
    {
      sprintf(last_message, "The transformation #%ld is already enabled", t);
      return -1;
    }

    sprintf(stry1, "%d", 1);
    recordLineTMP(id_array_pad, stry1);

    recordLineTMP(id_ignore_the_rest, "1");
 
    writeDBtoTMPafterCurTrAndRenameBack(id_array_pad); 
  }
  
  return ret;
}

//mode=0 - perform transformaton in any case (even if the same)
//     1 - produce error if transformation is the same
int trUnroll(long t, char* fname_funcs, int param, int mode)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_unroll)
  {
    appendDBtoTMPbeforeID(id_unroll_fully, stry2);
    findLineFromCurrentTransformation(id_unroll_factor, stry3);

    if (atoi(stry2)==0 && atoi(stry3)==param)
    {
      if (mode==1)
      {
        sprintf(last_message, "The transformation #%ld didn't change", t);
        return -1;
      }
    }

    sprintf(stry1, "%d", 0);
    recordLineTMP(id_unroll_fully, stry1);
 
    sprintf(stry1, "%d", param);
    recordLineTMP(id_unroll_factor, stry1);

    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_unroll_factor); 
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

//mode=0 - perform transformaton in any case (even if the same)
//     1 - produce error if transformation is the same
int trPrefetch(long t, char* fname_funcs, int param, int mode)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_pf)
  {
    appendDBtoTMPbeforeID(id_pf_offset, stry2);

    if (atoi(stry2)==param)
    {
      if (mode==1)
      {
        sprintf(last_message, "The transformation #%ld didn't change", t);
        return -1;
      }
    }

    sprintf(stry1, "%d", param);
    recordLineTMP(id_pf_offset, stry1);

    sprintf(stry1, "%d", 1);
    recordLineTMP(id_status, stry1);

    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_unroll_factor); 
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

//mode=0 - perform transformaton in any case (even if the same)
//     1 - produce error if transformation is the same
int trPadGlobal(long t, char* fname_funcs, int param, int mode)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_pad_global)
  {
    appendDBtoTMPbeforeID(id_array_pad, stry2);

    if (atoi(stry2)==param)
    {
      if (mode==1)
      {
        sprintf(last_message, "The transformation #%ld didn't change", t);
        return -1;
      }
    }

    sprintf(stry1, "%d", param);
    recordLineTMP(id_array_pad, stry1);

    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_unroll_factor); 
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

//mode=0 - perform transformaton in any case (even if the same)
//     1 - produce error if transformation is the same
int trUnrollFully(long t, char* fname_funcs, int mode)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_unroll)
  {
    appendDBtoTMPbeforeID(id_unroll_fully, stry2);
    findLineFromCurrentTransformation(id_unroll_factor, stry3);

    if (atoi(stry2)==1 && atoi(stry3)==1)
    {
      if (mode==1)
      {
        sprintf(last_message, "The transformation #%ld didn't change", t);
        return -1;
      }
    }

    sprintf(stry1, "%d", 1);
    recordLineTMP(id_unroll_fully, stry1);
 
    sprintf(stry1, "%d", 1);
    recordLineTMP(id_unroll_factor, stry1);

    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_unroll_factor); 
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

//mode=0 - perform transformaton in any case (even if the same)
//     1 - produce error if transformation is the same
int trInline(long t, char* fname_funcs, int param, int mode)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_inline)
  {
    appendDBtoTMPbeforeID(id_status, stry2);

    if (atoi(stry2)==param)
    {
      if (mode==1)
      {
        sprintf(last_message, "The transformation #%ld didn't change", t);
        return -1;
      }
    }

    sprintf(stry1, "%d", param);
    recordLineTMP(id_status, stry1);
 
// next line is remarked because it causes problem with this transformation
    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_status); 
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

//mode=0 - perform transformaton in any case (even if the same)
//     1 - produce error if transformation is the same
int trFF(long t, char* fname_funcs, int param, int mode)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_ff)
  {
    appendDBtoTMPbeforeID(id_status, stry2);

    if (atoi(stry2)==param)
    {
      if (mode==1)
      {
        sprintf(last_message, "The transformation #%ld didn't change", t);
        return -1;
      }
    }

    sprintf(stry1, "%d", param);
    recordLineTMP(id_status, stry1);
 
    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_status); 
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

//mode=0 - perform transformaton in any case (even if the same)
//     1 - produce error if transformation is the same
int trSNL(long t, char* fname_funcs, int param, int mode)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_snl)
  {
    appendDBtoTMPbeforeID(id_status, stry2);

    if (atoi(stry2)==param)
    {
      if (mode==1)
      {
        sprintf(last_message, "The transformation #%ld didn't change", t);
        return -1;
      }
    }

    sprintf(stry1, "%d", param);
    recordLineTMP(id_status, stry1);
 
    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_status); 
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

//mode=0 - perform transformaton in any case (even if the same)
//     1 - produce error if transformation is the same
int trSNL_All(long t, char* fname_funcs, int n, int* ai, int* ar, 
              int bn, int* b1, int* b2, int* b3, int mode)
{
  int ret=0;
  int i=0;
  int lo=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_snl)
  {
    appendDBtoTMPbeforeID(id_lnt_outer, stry2);
    lo=atoi(stry2);
    recordLineTMP(id_lnt_outer, stry2);
    
    strcpy(stry2, "new_order:   ");
    strcpy(stry3, "new_reg_tile:");
    for (i=1; i<=n; i++)
    {
      sprintf(stry1, "%u", i-1); //internal numbering of loops starts from 0
      recordLineTMP(id_lnt_loop_number, stry1);

      sprintf(stry1, "%u", ai[i]-1+lo); //recent change +lo
      recordLineTMP(id_lnt_new_loop_order, stry1);
      strcat(stry2, stry1);
      strcat(stry2, "  ");

      sprintf(stry1, "%u", ar[i]);
      recordLineTMP(id_lnt_new_reg_tiling, stry1);
      strcat(stry3, stry1);
      strcat(stry3, "  ");
    }
    recordLineTMP(id_rem, stry2);
    recordLineTMP(id_rem, stry3);

    if (bn==0) recordLineTMP(id_lnt_blocking_status, "0");
    else
    {
      recordLineTMP(id_lnt_blocking_status, "1");
      sprintf(stry1, "%u", bn);
      recordLineTMP(id_lnt_nbl, stry1);

      for (i=1; i<=bn; i++)
      {
        sprintf(stry1, "%u", b1[i]+lo); //recent change +lo
        recordLineTMP(id_lnt_iln, stry1);

        sprintf(stry1, "%u", b2[i]);
        recordLineTMP(id_lnt_loop_strip, stry1);

        sprintf(stry1, "%u", b3[i]);
        recordLineTMP(id_lnt_cache_level, stry1);
      }
    }
    
    recordLineTMP(id_status, "1");

//    gives problems
    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_status); 
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

int getSNL_TilingStatus(long t)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (tr==iid_tr_snl)
  {
    findLineFromCurrentTransformation(id_lnt_blocking_status, stry3);
    ret=atoi(stry3);
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

int getSNL_NumberOfTiles(long t)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (tr==iid_tr_snl)
  {
    findLineFromCurrentTransformation(id_lnt_nbl, stry3);
    ret=atoi(stry3);
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

int getSNL_LoopNests(long t)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (tr==iid_tr_snl)
  {
    findLineFromCurrentTransformation(id_lnt_nd, stry3);
    ret=atoi(stry3);
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}

//mode=0 - perform transformaton in any case (even if the same)
//     1 - produce error if transformation is the same
int trSIMD(long t, char* fname_funcs, int param, int mode)
{
  int ret=0;

  strcpy(last_message, "");

  if (findTransformationByNumber(t)!=1)
  {
    sprintf(last_message, "Can't find transformation #%ld", t);
    return -1;
  }

  int tr=getCurTransformationID(tr_id);

  if (strcmp(fname_funcs, "")!=0)
  {
    if (checkCurFuncToTransform(fname_funcs)!=1)
    {
      sprintf(last_message, "Function for transformation #%ld is not in the list", t);
      return -2;
    }
  }

  //rewrite transformation
  writeDBtoTMPbeforeCurTr();

  if (tr==iid_tr_simd)
  {
    appendDBtoTMPbeforeID(id_status, stry2);

    if (atoi(stry2)==param)
    {
      if (mode==1)
      {
        sprintf(last_message, "The transformation #%ld didn't change", t);
        return -1;
      }
    }

    sprintf(stry1, "%d", param);
    recordLineTMP(id_status, stry1);
 
    recordLineTMP(id_ignore_the_rest, "1");

    writeDBtoTMPafterCurTrAndRenameBack(id_status); 
  }
  else
  {
    sprintf(last_message, "Transformation #%ld mismatch", t);
    return -3;
  }
  
  return ret;
}


char* getLastTransformationMessage(void)
{
  return last_message;
}

char* getLastTransformationID(void)
{
  return tr_id;
}

int getMaxNumFunc(char* name)
{
  FILE* f;
  int num=0;

  if ((f=fopen(name, "r"))!=NULL)
  {
    while ((fgets(stry1, 1024, f)!=NULL) && (feof(f)==0)) num++;
    fclose(f);
  }

  return num;
}

int getFunc(char* name, int n, char* str)
{
  FILE* f;
  int r=-1;
  int num=0;

  if ((f=fopen(name, "r"))!=NULL)
  {
    while ((fgets(stry1, 1024, f)!=NULL) && (feof(f)==0))
    {
      fparse1(stry1);
      num++;

      if (num==n)
      {
        strcpy(str, stry1);
        r=1;
      }
    }
    fclose(f);
  }

  return r;
}
