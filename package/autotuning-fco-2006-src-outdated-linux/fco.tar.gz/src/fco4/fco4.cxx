/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "ftransformations.h"
#include "futils.h"
#include "fids.h"
#include "param.h"
#include "clparse.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fp        "fco4"             //program name
#define _fm         "_finfo_mode"     //program switches

#define _fcomp     "_fbcomp"          //compile batch file
#define _frun      "_fbrun"           //run batch file
#define _fcopy     "_fbcopy"          //copy1 batch file
#define _fdiff     "_fbdiff"          //diff1 batch file
#define _fclean1   "_fbclean1"        //clean std files
#define _fff       "_finfo_funcs"     //file with the list of functions to transform 
                                      //(used both by this program and PathScale)
#define _fff1      "_finfo_funcs1"    //file with the list of functions to transform
                                      //(used only by this program)
#define _ftr       "_finfo_tr"        //file with the list of transformations used
#define _fic       "_finfo_iter"      //current iteration
#define _fic_cur   ".cur"             //extension for current iteration
#define _fic_db    ".fdb"             //extension for transformation database
#define _fic_tim   ".time"            //extension for time (run)
#define _fic_timc  ".timec"           //extension for time (compilation)
#define _fic_inf   ".info"            //extension for info
#define _fic_tri1  ".tr_i1"           //extension for transformation info1
#define _fic_tri2  ".tr_i2"           //extension for transformation info2
#define _fcomp1    "fcompilation"     //file for FCompilation
#define _fout      "a.out"            //exe file
#define _ftime     "ftmp_time"        //file with time (run)
#define _ftimec    "ftmp_timec"       //file with time (compilation)
#define _ftmp_diff "ftmp_diff"        //file with diff
#define _ftmp_dbr  "ftmp_dbr.tmp"     //tmp db file (read)
#define _ftmp_dbr1 "ftmp_dbr1.tmp"    //tmp db file (read)
#define _ftmp_dbw  "ftmp_dbw.tmp"     //tmp db file (write)
#define _ftmp_dbw1 "ftmp_dbw1.tmp"    //tmp1 db file (write)

#define _fcomp_mode_0  0         
#define _fcomp_mode_w  2
#define _fcomp_mode_r  3
#define _fcomp_mode_rw 4

int mode_ign;                 //1 - don't compare time if output is different

//#define mode_acc 0          //1 - accumulate best result
//#define mode_exh 0          //1 - exhaustive mode otherwise random mode
//#define mode_dis 0          //1 - disable all transformations after the current

int tr_rnd=2;                 //number of random tries if mode is random 

double _ftime_threshold;      //Problems with execution
double _ftime_compare;        //threshold to compare best time

int tr_inline=        1;
int tr_ff=            1;

int tr_pl=            1;
int tr_pl_min=        0;
int tr_pl_max=       32;
int tr_pl_step=       1;

int tr_regt=          1;
int tr_regt_min=      0;
int tr_regt_max=     12;
int tr_regt_step=     1;

int tr_t=             1;
int tr_t_min=         0;
int tr_t_max=       512;
int tr_t_step=       16;

int tr_simd=          1;
int tr_v_min=         0;
int tr_v_max=        16;
int tr_v_step=        1;

int tr_pf=            1;
int tr_pf_min=     -512;
int tr_pf_max=      512;
int tr_pf_step=      16;

int tr_unroll=        1;
int tr_unroll_min=    1;
int tr_unroll_max=   16;
int tr_unroll_step=   1;

#define sep1 "==============================================================================="
#define sep2 "-------------------------------------------------------------------------------"

void trPrep(long iter, long t);
void trPrep1(long iter, char* strf, 
             int param_i,   int param_lp,  int param_ff,
             int param_rt1, int param_rt2, int param_rt3, int param_rt4,
	     int param_b1,  int param_b2,  int param_b3,  int param_b4,
	     int param_p,   
	     int param_v,
	     int param_u);
void trPrepSNL(int n, int* ai, int* ar, int bn, int* b1, int* b2, int* b3);
void trFail(long iter);
void trDidNotChange(long iter);
void trSuccess(void);
int trCompile(long iter, double* t1, double* t2, char* dbr, char* dbw);
void trRun(long iter, double* t1, double* t2, int* inf1, int* inf2, 
           long* iterB, double* ttB, int mode, bool* found, bool* infl);
void trCheck(long iter, long* iterB, double* ttB, bool* found, bool* infl);
void trFound(long iterB);
int trDisable(long iter, long tr, char* func);

int trAllFunc(char* strf, char* fname_funcs,  
              int param_i,   int param_lp,  int param_ff,
	      int param_rt1, int param_rt2, int param_rt3, int param_rt4,
	      int param_b1,  int param_b2,  int param_b3,  int param_b4,
	      int param_p,   
	      int param_v, 
	      int param_u, 
	      char* ftmp);

int diffFiles(char* fn1, char* fn2);
int findLoop(int* array, int max, int p);
void removeTile(int* array1, int* array2, int* array3, int place, int max);

char str1[1024];  //Not very clean, should change when have time
char str2[1024];
char str3[1024];

char stri1[1024];  //Not very clean, should change when have time
char stri2[1024];
char stri3[1024];

char strj1[1024];  //Not very clean, should change when have time
char strj2[1024];
char strj3[1024];

char strf[1024];

char db_r[1024];
char db_w[1024];
char db_rs[1024]; //save original db_r during LNT

long iter0=0;     //transformation for current iteration is based on this one
long iter0s=0;    //save original iter0
long iterB=0;     //iteration with best execution time
long iterD=0;     //iteration with execution time when transformation is disabled
double ttB0s=0;

int snl_i[32];    //interchange position
int snl_r[32];    //register tiling

int snl_bi[32];   //interchange position
int snl_br[32];   //register tiling

int snl_t1[32];   //lnt_internal_loop_number
int snl_t2[32];   //lnt_loop_strip
int snl_t3[32];   //lnt_cache_level

int snl_bt1[32];  //lnt_internal_loop_number
int snl_bt2[32];  //lnt_loop_strip
int snl_bt3[32];  //lnt_cache_level

int main(int argc, char* argv[])
{
  FILE* f;

  double tt=0;
  double t1=0;
  double t2=0;

  long   iter=1;
  long   iterX=1;
  double ttB=0; //best time
  bool   found=false; //found best time for the set of parameters 
  bool   infl=false;  //if didn't find best time but the change in time
                      //was dramatic - means that influence performance

  int tr_rnd1=0;

  int param=0;
  int paramr=0;

  int inf1=0;
  int inf2=0;

  bool start=false;
  bool found1=false;

  int ret=0;

  char FileOpt[]=_fp ".cl";

  printf("FCO Strategy 4\n");

  //*********************************************************  
  //writing program switches
  if ((f=fopen(_fm, "w"))!=NULL)
  {
    strcpy(str1,_fp);

#ifdef mode_exh
    strcat(str1, "e");
#else
    strcat(str1, "r");
#endif

#ifdef mode_dis
    strcat(str1, "d");
#else
    strcat(str1, "i");
#endif

#ifdef mode_acc
    strcat(str1, "a");
#endif

    fprintf(f, "%s\n", str1);
    fclose(f);
  }
  else
  {
    printf("\nError: Can't write program switches to file\n");
    exit(1);
  }

  //*********************************************************  
  //Declaration of class for command-line parsing
  CCLParse*	 clp = new CCLParse();
         
  if (clp->Init(10, 32, 256, 1, FileOpt)!=0)
  //             |   |    |  |  | 
  //             |   |    |  |  |------ Name of File with Options
  //             |   |    |  |
  //             |   |    |  |--------- Case Sensitive (0) or not (1)
  //             |   |    |
  //             |   |    |------------ Max Length of Parameter
  //             |   |
  //             |   |----------------- Max Length of Option
  //             |
  //             |--------------------- Max Number of Options
  {
    printf("\nError: Can't initialize object CCLParse!\n");
    return 1;
  }

  int misc=0;
  
  misc =clp->Add("--help", "-h", "-?", "", 0);               //Param 0
  misc+=clp->Add("--version", "-v", "", "", 0);              //Param 1
  misc+=clp->Add("--verbose", "-vb", "", "", 0);             //Param 2
  misc+=clp->Add("--mode_ign", "-mig", "", "1", 1);          //Param 3
  misc+=clp->Add("--time_threshold", "-tt", "", "0.5", 1);   //Param 4
  misc+=clp->Add("--time_compare", "-tc", "", "0.2", 1);     //Param 5
  misc+=clp->Add("--tr_rnd", "-tr", "", "2", 1);             //Param 6

  if (misc!=0)
  {
    printf("\nError: Internal, while initializing CCLParse!\n");
    return 1;
  }

  misc=clp->Parse(argc, argv);
  if (misc==1)
  {
    printf("\nError: Unknown option in command line!\n");
    return 1;
  }
  else if (misc==2)
  {
    printf("\nError: Option can't be used without parameter in command line!\n");
    return 1;
  }
  else if (misc==3)
  {
    printf("\nError: Option can't be used without parameter in file with options!\n");
    return 1;
  }
  else if (misc==4)
  {
    printf("\nError: Unknown option in file with options!\n");
    return 1;
  }
  else if (misc>0)
  {
    printf("\nError: Internal, while parsing command line!\n");
    return 1;
  }

  mode_ign=clp->GetParamInt(paramMIG);
  _ftime_threshold=atof(clp->GetParamStr(paramTT));
  _ftime_compare=atof(clp->GetParamStr(paramTC));
  tr_rnd=clp->GetParamInt(paramTR);

  //*********************************************************  
  printf("\n");
  printf("Reading transformation configuration\n");

  if (findLineFromFile(ido_mig, str1, _ftr)==1) mode_ign=atoi(str1);
  if (findLineFromFile(ido_tt, str1, _ftr)==1) _ftime_threshold=atof(str1);
  if (findLineFromFile(ido_tc, str1, _ftr)==1) _ftime_compare=atof(str1);
  if (findLineFromFile(ido_tr, str1, _ftr)==1) tr_rnd=atoi(str1);

  if (findLineFromFile(ido_tr_simd, str1, _ftr)==1) tr_simd=atoi(str1);
  if (findLineFromFile(ido_tr_ff, str1, _ftr)==1) tr_ff=atoi(str1);
  if (findLineFromFile(ido_tr_inline, str1, _ftr)==1) tr_inline=atoi(str1);

  if (findLineFromFile(ido_tr_unroll, str1, _ftr)==1) tr_unroll=atoi(str1);
  if (findLineFromFile(ido_tr_unroll_min, str1, _ftr)==1) tr_unroll_min=atoi(str1);
  if (findLineFromFile(ido_tr_unroll_max, str1, _ftr)==1) tr_unroll_max=atoi(str1);
  if (findLineFromFile(ido_tr_unroll_step, str1, _ftr)==1) tr_unroll_step=atoi(str1);

  if (findLineFromFile(ido_tr_regt, str1, _ftr)==1) tr_regt=atoi(str1);
  if (findLineFromFile(ido_tr_regt_min, str1, _ftr)==1) tr_regt_min=atoi(str1);
  if (findLineFromFile(ido_tr_regt_max, str1, _ftr)==1) tr_regt_max=atoi(str1);
  if (findLineFromFile(ido_tr_regt_step, str1, _ftr)==1) tr_regt_step=atoi(str1);

  if (findLineFromFile(ido_tr_t, str1, _ftr)==1) tr_t=atoi(str1);
  if (findLineFromFile(ido_tr_t_min, str1, _ftr)==1) tr_t_min=atoi(str1);
  if (findLineFromFile(ido_tr_t_max, str1, _ftr)==1) tr_t_max=atoi(str1);
  if (findLineFromFile(ido_tr_t_step, str1, _ftr)==1) tr_t_step=atoi(str1);

  if (findLineFromFile(ido_tr_v_min, str1, _ftr)==1) tr_v_min=atoi(str1);
  if (findLineFromFile(ido_tr_v_max, str1, _ftr)==1) tr_v_max=atoi(str1);
  if (findLineFromFile(ido_tr_v_step, str1, _ftr)==1) tr_v_step=atoi(str1);

  if (findLineFromFile(ido_tr_pf, str1, _ftr)==1) tr_pf=atoi(str1);
  if (findLineFromFile(ido_tr_pf_min, str1, _ftr)==1) tr_pf_min=atoi(str1);
  if (findLineFromFile(ido_tr_pf_max, str1, _ftr)==1) tr_pf_max=atoi(str1);
  if (findLineFromFile(ido_tr_pf_step, str1, _ftr)==1) tr_pf_step=atoi(str1);

  if (findLineFromFile(ido_tr_pl, str1, _ftr)==1) tr_pl=atoi(str1);
  if (findLineFromFile(ido_tr_pl_min, str1, _ftr)==1) tr_pl_min=atoi(str1);
  if (findLineFromFile(ido_tr_pl_max, str1, _ftr)==1) tr_pl_max=atoi(str1);
  if (findLineFromFile(ido_tr_pl_step, str1, _ftr)==1) tr_pl_step=atoi(str1);

  if (clp->GetParamLong(paramVersion)==1)
  {
    printf("\n");
    printf("Version information:\n");
    printf("  Version 1.0, released on 2006.February.01\n");

    return 0;
  }

  if (clp->GetParamLong(paramHelp)==1)
  {
    //Help
    printf("\n");
    printf("Brief information:\n");
    printf("  \"Fresh Continuous Optimizations\" Search Strategy 4\n");
    printf("\n");
    printf("  Copyright (C) 2004-2006 by Grigori G.Fursin\n");
    printf("  Partially based on EOS Software (Copyright (C) 2000-2004)\n");
    printf("\n");
    printf("  http://homepages.inf.ed.ac.uk/gfursin\n");
    printf("\n");
    printf("  INRIA Futurs, France\n");
    printf("  and ICSA, University of Edinburgh, UK\n");
    printf("\n");
    printf("Options (you can also add options into file %s):\n", FileOpt);
    printf("  --help, -h, -?                Help;\n");
    printf("  --version, -v                 Print version;\n");
    printf("  --verbose, -vb                Print additional diagnostic messages;\n");
    printf("\n");
    printf("  --mode_ign, -mig <param>       1 - ignore incorrect output;\n");
    printf("  --time_threshold, -tt <param> Time threshold for the execution to ignore;\n");
    printf("  --time_compare, -tc <param>   Time delta when selecting best transformation;\n");
    printf("  --tr_rnd, -tr <param>         Number of random tries;\n");

    return 0;
  }

  if (clp->GetParamLong(paramVerbose)==1)
  {
    //Help
    printf("\n");
    printf("Options:\n");
    printf("  Mode ignore output      = %5d\n",    mode_ign);
    printf("\n");
    printf("  Time threshold          = %5.1f\n", _ftime_threshold);
    printf("  Time compare            = %5.1f\n", _ftime_compare);
    printf("\n");
    printf("  Random transformations  = %5d\n",   tr_rnd);
    printf("\n");
    printf("  SIMD         in use     = %5d\n", tr_simd);
    printf("  SIMD         parameters = %5d, %5d, %5d\n", tr_v_min,      tr_v_max,      tr_v_step);
    printf("  FF           in use     = %5d\n", tr_ff);
    printf("  Inline       in use     = %5d\n", tr_inline);
    printf("  Unroll       in use     = %5d\n", tr_unroll);
    printf("  Unroll       parameters = %5d, %5d, %5d\n", tr_unroll_min, tr_unroll_max, tr_unroll_step);
    printf("  Reg. tiling  in use     = %5d\n", tr_regt);
    printf("  Reg. tiling  parameters = %5d, %5d, %5d\n", tr_regt_min,   tr_regt_max,   tr_regt_step);
    printf("  Tiling       in use     = %5d\n", tr_t);
    printf("  Tiling       parameters = %5d, %5d, %5d\n", tr_t_min,      tr_t_max,      tr_t_step);
    printf("  Prefetch     in use     = %5d\n", tr_pf);
    printf("  Prefetch     parameters = %5d, %5d, %5d\n", tr_pf_min,     tr_pf_max,     tr_pf_step);
    printf("  Pad. local   in use     = %5d\n", tr_pl);
    printf("  Pad. local   parameters = %5d, %5d, %5d\n", tr_pl_min,     tr_pl_max,     tr_pl_step);
    printf("\n");
  }

  //*********************************************************  
  printf("Reading original execution time: ");

  sprintf(str2, _fic ".%06u" _fic_tim, 0);
  t1=getTime1(str2);
  t2=getTime2(str2);
  ttB=t1+t2;
  printf("user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, ttB);

  printf("\n");
  printf("Reading last iteration number ...\n");
  
  iterX=readLastIteration(_fic _fic_cur);
  iterX++;

  if (iterX==0)
  {
    printf("Mode: first run\n");
    printf("\n");
    printf("Please, run fco first!\n");
  }
  else
  {
    printf("Mode: continuous optimizations\n");
    printf("      last iteration=%u\n", iterX-1);

    //prepare db_r
    iter0=0;
    sprintf(db_r, _fic ".%06u" _fic_db, iter0);
    int func_max=getMaxNumFunc(_fff1);

    printf("\n");
    printf("Number of functions: %u\n", func_max);

    int func=1;
    while (func<=func_max)
    {
      found=false;
      getFunc(_fff1, func, strf);

      printf(sep1 "\n");
      printf("Current function: %s\n", strf);

      int param1=0;
      int param2=0;
      int param3=0;

      int sel_i=0;
      int sel_lp=1;
      int sel_ff=2;
      int sel_rt1=3;
      int sel_rt2=4;
      int sel_rt3=5;
      int sel_rt4=6;
      int sel_b1=7;
      int sel_b2=8;
      int sel_b3=9;
      int sel_b4=10;
      int sel_v=11;
      int sel_p=12;
      int sel_u=13;

        //changing all transformations for this function
#ifdef mode_dis
      int param_i=0;   //inline
      int param_lp=0;  //local padding
      int param_ff=0;  //fiz/fuse
      int param_rt1=0; //register tiling loop1
      int param_rt2=0; //register tiling loop2
      int param_rt3=0; //register tiling loop3
      int param_rt4=0; //register tiling loop4
      int param_b1=0;  //blocking loop1
      int param_b2=0;  //blocking loop2
      int param_b3=0;  //blocking loop3
      int param_b4=0;  //blocking loop4
      int param_v=0;   //simd
      int param_p=0;   //prefetch
      int param_u=0;   //unroll
#else
      int param_i=-1;   //inline
      int param_lp=-1;  //local padding
      int param_ff=-1;  //fiz/fuse
      int param_rt1=-1; //register tiling loop1
      int param_rt2=-1; //register tiling loop2
      int param_rt3=-1; //register tiling loop3
      int param_rt4=-1; //register tiling loop4
      int param_b1=-1;  //blocking loop1
      int param_b2=-1;  //blocking loop2
      int param_b3=-1;  //blocking loop3
      int param_b4=-1;  //blocking loop4
      int param_v=-1;   //simd
      int param_p=-1;   //prefetch
      int param_u=-1;   //unroll
#endif
      
      for (int sel=0; sel<=sel_u; sel++)
      {
#ifdef mode_dis
      int paramf=0;
#else
      int paramf=-1;
#endif

        found1=false;
	if (sel==sel_i) {param1=0; param2=1; param3=1;}
	else if (sel==sel_lp) {param1=tr_pl_min; param2=tr_pl_max; param3=tr_pl_step;}
	else if (sel==sel_ff) {param1=0; param2=1; param3=1;}
	else if (sel==sel_rt1) {param1=tr_regt_min; param2=tr_regt_max; param3=tr_regt_step;}
	else if (sel==sel_rt2) {param1=tr_regt_min; param2=tr_regt_max; param3=tr_regt_step;}
	else if (sel==sel_rt3) {param1=tr_regt_min; param2=tr_regt_max; param3=tr_regt_step;}
	else if (sel==sel_rt4) {param1=tr_regt_min; param2=tr_regt_max; param3=tr_regt_step;}
	else if (sel==sel_b1) {param1=tr_t_min; param2=tr_t_max; param3=tr_t_step;}
	else if (sel==sel_b2) {param1=tr_t_min; param2=tr_t_max; param3=tr_t_step;}
	else if (sel==sel_b3) {param1=tr_t_min; param2=tr_t_max; param3=tr_t_step;}
	else if (sel==sel_b4) {param1=tr_t_min; param2=tr_t_max; param3=tr_t_step;}
	else if (sel==sel_v) {param1=tr_v_min; param2=tr_v_max; param3=tr_v_step;}
	else if (sel==sel_p) {param1=tr_pf_min; param2=tr_pf_max; param3=tr_pf_step;}
	else if (sel==sel_u) {param1=tr_unroll_min; param2=tr_unroll_max; param3=tr_unroll_step;}

#ifdef mode_exh
	for (param=param1; param<=param2; param+=param3)
	{
#else
        tr_rnd1=tr_rnd;
        if (sel==sel_i || sel==sel_ff) tr_rnd1=2;
	for (paramr=0; paramr<tr_rnd1; paramr++)
	{
          param=param1+(rand()%(param2-param1));
          if (sel==sel_i || sel==sel_ff) param=paramr;
#endif	 

	  if (sel==sel_i)        {param_i=param;   }
	  else if (sel==sel_lp)  {param_lp=param;  } 
	  else if (sel==sel_ff)  {param_ff=param;  }
	  else if (sel==sel_rt1) {param_rt1=param; } 
	  else if (sel==sel_rt2) {param_rt2=param; }
	  else if (sel==sel_rt3) {param_rt3=param; }
	  else if (sel==sel_rt4) {param_rt4=param; }
	  else if (sel==sel_b1)  {param_b1=param;  }
	  else if (sel==sel_b2)  {param_b2=param;  }
	  else if (sel==sel_b3)  {param_b3=param;  }
	  else if (sel==sel_b4)  {param_b4=param;  }
	  else if (sel==sel_v)   {param_v=param;   }
	  else if (sel==sel_p)   {param_p=param;   }
  	  else if (sel==sel_u)   {param_u=param;   }

          bool ignore=true;
	  
	  if (sel==sel_i)        {if (tr_inline==1) ignore=false;}
	  else if (sel==sel_lp)  {if (tr_pl==1) ignore=false;}
	  else if (sel==sel_ff)  {if (tr_ff==1) ignore=false;}
	  else if (sel==sel_rt1) {if (tr_regt==1) ignore=false;}
	  else if (sel==sel_rt2) {if (tr_regt==1) ignore=false;}
	  else if (sel==sel_rt3) {if (tr_regt==1) ignore=false;}
	  else if (sel==sel_rt4) {if (tr_regt==1) ignore=false;}
	  else if (sel==sel_b1)  {if (tr_t==1) ignore=false;}
	  else if (sel==sel_b2)  {if (tr_t==1) ignore=false;}
	  else if (sel==sel_b3)  {if (tr_t==1) ignore=false;}
	  else if (sel==sel_b4)  {if (tr_t==1) ignore=false;}
	  else if (sel==sel_v)   {if (tr_simd==1) ignore=false;}
	  else if (sel==sel_p)   {if (tr_pf==1) ignore=false;}
  	  else if (sel==sel_u)   {if (tr_unroll==1) ignore=false;}
	  
          if (!ignore)
          {
            printf(sep2"\n");
            printf("Iteration %lu:\n", iter);

            if (iter>=iterX)
  	    {
              trPrep1(iter, strf, param_i, param_lp, param_ff,
	                          param_rt1, param_rt2, param_rt3, param_rt4,
	  		  	  param_b1,  param_b2,  param_b3,  param_b4,
				  param_p,   
			  	  param_v, 
				  param_u);

              ret=trAllFunc(strf, _fff, 
                                  param_i, param_lp, param_ff,
	                          param_rt1, param_rt2, param_rt3, param_rt4,
		  		  param_b1,  param_b2,  param_b3,  param_b4,
		 		  param_p,   
				  param_v, 
				  param_u, 
  	  		         _ftmp_dbr1);

              if (ret<0) trFail(iter);
              else if (ret>0) trFail(iter);
  	      else
	      {
                trSuccess();
                sprintf(db_w, _fic ".%06u" _fic_db, iter);
                if (trCompile(iter, &t1, &t2, _ftmp_dbw, db_w)>=0)
                    trRun(iter, &t1, &t2, &inf1, &inf2, &iterB, &ttB, mode_ign, &found1, &infl);
              }
            }
            else trCheck(iter, &iterB, &ttB, &found1, &infl);
            
#ifdef mode_acc
            if (found1)
	    {
	      paramf=param;
              found=true;
              found1=false;
	    }
#endif

            writeIteration(_fic _fic_cur, iter);
            iter++;
	  }
        }

        if      (sel==sel_i)    {param_i=paramf;}
        else if (sel==sel_lp)   {param_lp=paramf;}
	else if (sel==sel_ff)   {param_ff=paramf;}
	else if (sel==sel_rt1)  {param_rt1=paramf;} 
	else if (sel==sel_rt2)  {param_rt2=paramf;}
	else if (sel==sel_rt3)  {param_rt3=paramf;}
	else if (sel==sel_rt4)  {param_rt4=paramf;}
	else if (sel==sel_b1)   {param_b1=paramf;}
	else if (sel==sel_b2)   {param_b2=paramf;}
	else if (sel==sel_b3)   {param_b3=paramf;}
	else if (sel==sel_b4)   {param_b4=paramf;}
	else if (sel==sel_v)    {param_v=paramf;}
	else if (sel==sel_p)    {param_p=paramf;}
  	else if (sel==sel_u)    {param_u=paramf;}
      }

      if (found) trFound(iterB);

      func++;
    }

    printf(sep1 "\n");
    printf(sep1 "\n");
    printf("FINAL RESULTS:\n");

    sprintf(str2, _fic ".%06u" _fic_tim, 0);
    t1=getTime1(str2);
    t2=getTime2(str2);
    tt=t1+t2;

    printf("\n");

    if (iterB==0)
    {
      printf("Time original = %6.1f\n", tt);
      printf("\n");
      printf("Better transformations not found!\n");
    }
    else
    {
      printf("Time original = %6.1f s.\n", tt);
      printf("Time best     = %6.1f s.\n", ttB);
      
      printf("\n");
      printf("Iter best     = %06u\n", iterB);

      double impr=((tt-ttB)/tt)*100;
      sprintf(str1, "Performance improvement = %3.1f%%\n", impr);

      printf("\n");
      printf(str1);

      printf(sep1 "\n");
      printf("\n");
    }
  }
  
  return 0;
}

void trFail(long iter)
{
  recordLineTR(id1_performed, "0", 2);
  sprintf(str2, "transformation failed (%s)!\n", getLastTransformationMessage());
  recordLineTR(id1_warn, str2, 2);

  printf("\n");
  printf("Warning: %s\n", str2);
  printf("\n");

  sprintf(str2, _fic ".%06u" _fic_inf, iter);
  writeIterStatus(str2, 0, 0, 0);
}

void trDidNotChange(long iter)
{
  recordLineTR(id1_performed, "0", 2);
  sprintf(str2, "transformation was not applied!\n");
  recordLineTR(id1_warn, str2, 2);

  printf("\n");
  printf("Warning: %s\n", str2);
  printf("\n");

  sprintf(str2, _fic ".%06u" _fic_inf, iter);
  writeIterStatus(str2, 0, 0, 0);
}

void trPrep(long iter, long t)
{
  int tr=getTransformation(t, _fff); //to initialize current transformation

  setDBIO(db_r, _ftmp_dbw);

  sprintf(str1, _fic ".%06u" _fic_tri1, iter);   //info about transformations
  sprintf(str2, _fic ".%06u" _fic_tri2, iter);   //info about transformations
  startTRInfo(str1, str2);
 
  sprintf(str1, "%u", iter0);
  recordLineTR(id1_in, str1, 1);

  sprintf(str1, _fic ".%06u" _fic_tri1, iter0); 
  sprintf(str2, "%u", iter);                
  appendLineTR(str1, id1_out, str2);

  startNewTR(2);
  recordLineTR(id1_tr, getLastTransformationID(),2);
  sprintf(str1, "%lu", getLastTransformationPOS());
  recordLineTR(id1_pos, str1, 2);
  getCurTransformationFunc(str1);
  recordLineTR(id_func, str1, 2);
}

void trPrep1(long iter, char* strf, 
             int param_i,   int param_lp,  int param_ff,
             int param_rt1, int param_rt2, int param_rt3, int param_rt4,
	     int param_b1,  int param_b2,  int param_b3,  int param_b4,
	     int param_p,   
	     int param_v,
	     int param_u)
{
  setDBIO(db_r, _ftmp_dbw);

  sprintf(str1, _fic ".%06u" _fic_tri1, iter);   //info about transformations
  sprintf(str2, _fic ".%06u" _fic_tri2, iter);   //info about transformations
  startTRInfo(str1, str2);
 
  sprintf(str1, "%u", iter0);
  recordLineTR(id1_in, str1, 1);

  sprintf(str1, _fic ".%06u" _fic_tri1, iter0); 
  sprintf(str2, "%u", iter);                
  appendLineTR(str1, id1_out, str2);

  startNewTR(2);
  recordLineTR(id_func, strf, 2);

  printf("Transformation sequence:\n");

  sprintf(str1, "%d", param_i);
  recordLineTR(id2_i, str1, 2);
  printf(id2_i "%s\n", str1);

  sprintf(str1, "%d", param_lp);
  recordLineTR(id2_lp, str1, 2);
  printf(id2_lp "%s\n", str1);

  sprintf(str1, "%d", param_ff);
  recordLineTR(id2_ff, str1, 2);
  printf(id2_ff "%s\n", str1);

  sprintf(str1, "%d", param_rt1);
  recordLineTR(id2_rt1, str1, 2);
  printf(id2_rt1 "%s\n", str1);

  sprintf(str1, "%d", param_rt2);
  recordLineTR(id2_rt2, str1, 2);
  printf(id2_rt2 "%s\n", str1);

  sprintf(str1, "%d", param_rt3);
  recordLineTR(id2_rt3, str1, 2);
  printf(id2_rt3 "%s\n", str1);

  sprintf(str1, "%d", param_rt4);
  recordLineTR(id2_rt4, str1, 2);
  printf(id2_rt4 "%s\n", str1);

  sprintf(str1, "%d", param_b1);
  recordLineTR(id2_b1, str1, 2);
  printf(id2_b1 "%s\n", str1);

  sprintf(str1, "%d", param_b2);
  recordLineTR(id2_b2, str1, 2);
  printf(id2_b2 "%s\n", str1);

  sprintf(str1, "%d", param_b3);
  recordLineTR(id2_b3, str1, 2);
  printf(id2_b3 "%s\n", str1);

  sprintf(str1, "%d", param_b4);
  recordLineTR(id2_b4, str1, 2);
  printf(id2_b4 "%s\n", str1);

  sprintf(str1, "%d", param_p);
  recordLineTR(id2_p, str1, 2);
  printf(id2_p "%s\n", str1);

  sprintf(str1, "%d", param_v);
  recordLineTR(id2_v, str1, 2);
  printf(id2_v "%s\n", str1);

  sprintf(str1, "%d", param_u);
  recordLineTR(id2_u, str1, 2);
  printf(id2_u "%s\n", str1);
}

void trPrepSNL(int n, int* ai, int* ar, int bn, int* b1, int* b2, int* b3)
{
  int i=0;
  
  recordLineTR(id_status, "1", 2);

  for (i=1; i<=n; i++)
  {
    sprintf(str1, "%u", i-1); //internal numbering of loops starts from 0
    recordLineTR(id_lnt_loop_number, str1, 2);

    sprintf(str1, "%u", ai[i]-1);
    recordLineTR(id_lnt_new_loop_order, str1, 2);

    sprintf(str1, "%u", ar[i]);
    recordLineTR(id_lnt_new_reg_tiling, str1, 2);
  }

  if (bn==0) recordLineTR(id_lnt_blocking_status, "0", 2);
  else
  {
    sprintf(str1, "%u", bn);
    recordLineTR(id_lnt_nbl, str1, 2);

    for (i=1; i<=bn; i++)
    {
      sprintf(str1, "%u", b1[i]);
      recordLineTR(id_lnt_iln, str1, 2);

      sprintf(str1, "%u", b2[i]);
      recordLineTR(id_lnt_loop_strip, str1, 2);

      sprintf(str1, "%u", b3[i]);
      recordLineTR(id_lnt_cache_level, str1, 2);
    }
  }
}

void trSuccess(void)
{
  recordLineTR(id1_performed, "1", 2);
}

int trDisable(long iter, long tr, char* func)
{
  int ret=0;

#ifdef mode_dis
  printf("        --- disabling all transformations after ---\n");
  long iterX=0;

  strcpy(str1, getDBR());
  strcpy(str2, getDBW());

  setDBIO(_ftmp_dbw, _ftmp_dbw1);

  int dis=1;
  disableAllAfterTr(tr, func, _ftmp_dbr1);

  while ((ret==0) && (dis!=0))
  {
    printf("        sub-iter: %u\n", iterX);
    tr++;
    iterX++;

    printf("                  compiling\n");
    setFComp(_fcomp1, _fcomp_mode_rw, _ftmp_dbw1, _ftmp_dbw);
    system(_fcomp);

    double t1=getTime1(_ftimec);
    double t2=getTime2(_ftimec);
    double tt=t1+t2;
    printf("                  compile time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    setDBIO(_ftmp_dbw, _ftmp_dbw1);

    if (fileExist(_fout)!=1)
    {
      printf("                  warning: a.out is not created!\n");
      ret=-1;
      sprintf(str2, _fic ".%06u" _fic_inf, iter);
      writeIterStatus(str2, 0, 0, 0);
    }

    dis=disableAllAfterTr(tr, func, _ftmp_dbr1);
  }

  setDBIO(str1, str2);

  printf("        -------------------------------------------\n");
#endif

  return ret;
}

int trCompile(long iter, double* t1, double* t2, char* dbr, char* dbw)
{
  int ret=0;
  
  printf("Set fcompilation to Read/Write\n");
  setFComp(_fcomp1, _fcomp_mode_rw, dbr, dbw);

  printf("Compile program ...\n");
  system(_fcomp);

  *t1=getTime1(_ftimec);
  *t2=getTime2(_ftimec);
  double tt=(*t1)+(*t2);
  printf("Compile Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", *t1, *t2, tt);

  sprintf(str2, _fic ".%06u" _fic_timc, iter);
  writeTime(str2, *t1, *t2);
    
  if (fileExist(_fout)!=1)
  {
    printf("Warning: a.out is not created!\n");
    ret=-1;
    sprintf(str2, _fic ".%06u" _fic_inf, iter);
    writeIterStatus(str2, 0, 0, 0);
  }

  return ret;
}

void trRun(long iter, double* t1, double* t2, int* inf1, int* inf2, 
           long* iterB, double* ttB, int mode, bool* found, bool* infl)
{
  printf("Run program ...\n");
  system(_frun);

  printf("\n");
      
  *t1=getTime1(_ftime);
  *t2=getTime2(_ftime);
  double tt=(*t1)+(*t2);
  printf("Run Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", *t1, *t2, tt);
  printf("                                        best=(%6.1f), iter=(%06u)\n", *ttB, *iterB);

  sprintf(str2, _fic ".%06u" _fic_tim, iter);
  writeTime(str2, *t1, *t2);

  *inf1=1;
  *inf2=1;
	
  printf("\n");
  if (tt<_ftime_threshold)
  {
    *inf1=0;
    printf("Warning: Execution time too low!\n");
  }
  if (fileDiffCorrect(_fdiff, _ftmp_diff)!=1)
  {
    *inf2=0;
    printf("Warning: Output is different from the original!\n");
  }

  if (((*inf2==0) && (mode==0)) || (*inf2==1))
  {
    //compare time
    if (tt<((*ttB)-_ftime_compare))
    {
      printf("\n");
      printf("BETTER TIME (%6.1f [iter=%06u]   <   %6.1f [iter=%06u]\n", tt, iter, *ttB, *iterB);

      *ttB=tt;
      *iterB=iter;

      *found=true;

      recordLineTR(id1_better, "1", 2);
    }
    else if (tt>((*ttB)+_ftime_compare))
    {
      printf("\n");
      printf("INFLUENTIAL (%6.1f [iter=%06u]   >   %6.1f [iter=%06u]\n", tt, iter, *ttB, *iterB);

      *infl=true;

      recordLineTR(id1_infl, "1", 2);
    }

  }

  sprintf(str2, _fic ".%06u" _fic_inf, iter);
  writeIterStatus(str2, 1, *inf1, *inf2);

  //saving executable file
  sprintf(str1, _fic ".%06u." _fout, iter);
  rename(_fout, str1);
}

void trCheck(long iter, long* iterB, double* ttB, bool* found, bool* infl)
{
  double t1,t2;
  
  printf("Transformation sequence (read from file)\n");

  sprintf(str1, _fic ".%06u" _fic_tri1, iter);   //info about transformations
  sprintf(str2, _fic ".%06u" _fic_tri2, iter);   //info about transformations
  startTRInfo1(str1, str2);

  if (findLineFromCurrentTransformationTR(id1_better, str1, 2)==1)
  {
    if (atoi(str1)==1)
    {
      sprintf(str2, _fic ".%06u" _fic_tim, iter);
      t1=getTime1(str2);
      t2=getTime2(str2);
      *ttB=t1+t2;

      *iterB=iter;

      *found=true;

      printf("\n");
      printf("BETTER TIME (%6.1f)\n", *ttB);
    }
  }
  else if (findLineFromCurrentTransformationTR(id1_infl, str1, 2)==1)
  {
    if (atoi(str1)==1)
    {
      *infl=true;

      printf("\n");
      printf("INFLUENTIAL\n", *ttB);
    }
  }
}

void trFound(long iterB)
{
#ifdef mode_acc
  iter0=iterB;

  printf("-------------------------------------------------------------------------------\n");
  printf("Following transformations will be based on iter=%06u\n", iter0);
  sprintf(db_r, _fic ".%06u" _fic_db, iter0);

  setDBIO(db_r, db_w);
#endif
}

//param_u - unroll parameter (if 0 then unroll fully)
int trAllFunc(char* strf, char* fname_funcs,  
              int param_i,   int param_lp,  int param_ff,
	      int param_rt1, int param_rt2, int param_rt3, int param_rt4,
	      int param_b1,  int param_b2,  int param_b3,  int param_b4,
	      int param_p,   
	      int param_v, 
	      int param_u, 
	      char* ftmp)
{
  int snl_i[16];
  int snl_r[16];
  int snl_bi[16];
  int snl_br[16];
  int snl_t1[16];
  int snl_t2[16];
  int snl_t3[16];
  int ret=0;
  long t=1;
  bool finish=false;
  bool change=false;
  bool change1=false;
  int ij=0;
  
  strcpy(strj1, getDBR());
  strcpy(strj2, getDBW());

  setDBIO(strj1, strj2);

  long tr_max=findNumberOfTransformations(getDBR());

  //start DB
  startTMP();

  int attempts=0;
  int attempts_max=5;
  while (!finish && attempts<attempts_max)
  {
    printf(".");
    fflush(stdout);

    t=1;
    while(t<=tr_max)
    {
      if (findTransformationByNumber(t)!=1)  return -1;

      int tr=getCurTransformationID(stri1);
      getCurTransformationFunc(stri1);

      startNewRecordTMP();

      if (strcmp(stri1, strf)==0)
      {
        if (tr==iid_tr_pad_local && param_lp!=-1)
        {
          findLineFromCurrentTransformation(id_status, stri2);
          int i2=atoi(stri2);

          if (param_lp==0)
	  {
            if (i2!=0)
            {
              appendDBtoTMPbeforeID(id_status, stri2);

              sprintf(stri1, "%d", 0);
              recordLineTMP(id_status, stri1);
              change=true;
            }
   	    else appendDBtoTMPonlyCurTr();
          }
	  else
	  {
            if (i2==0)
            {
              appendDBtoTMPbeforeID(id_status, stri2);

              sprintf(stri1, "%d", 1);
              recordLineTMP(id_status, stri1);
              change=true;
            }
   	    else
	    {
              appendDBtoTMPbeforeID(id_status, stri2);
              sprintf(stri1, "%d", 1);
              recordLineTMP(id_status, stri1);

              findLineFromCurrentTransformation(id_array_dims, stri2);
              recordLineTMP(id_array_dims, stri2);
              int dims1=atoi(stri2);

              for (int i=0; i<dims1-1; i++)
   	      {
                sprintf(stri2, "%d", i);
                recordLineTMP(id_array_dim, stri2);

                findLineFromCurrentTransformationX(id_array_lbn, stri2, i);
                recordLineTMP(id_array_lbn, stri2);

                findLineFromCurrentTransformationX(id_array_ubo, stri2, i);
                findLineFromCurrentTransformationX(id_array_ubn, stri3, i);
                int l=atoi(stri2)+param_lp;
                int l1=atoi(stri3);
		if (l!=l1) change=true;
                sprintf(stri2, "%d", l);
                recordLineTMP(id_array_ubn, stri2);
	      }
            }
	  }
        }
        else if (tr==iid_tr_unroll && param_u!=-1)
        {
          findLineFromCurrentTransformation(id_unroll_fully, stri2);
          findLineFromCurrentTransformation(id_unroll_factor, stri3);
          int i2=atoi(stri2);
	  int i3=atoi(stri3);
	  
	  if ((i2!=0) || (param_u==0 && i3!=1) || (i3!=param_u))
          {
            appendDBtoTMPbeforeID(id_unroll_fully, stri2);

            sprintf(stri1, "%d", 0);
            recordLineTMP(id_unroll_fully, stri1);

            if (param_u==0) sprintf(stri1, "%d", 1);
            else            sprintf(stri1, "%d", param_u);
            recordLineTMP(id_unroll_factor, stri1);
            change=true;
	  }
	  else appendDBtoTMPonlyCurTr();
        }
        else if (tr==iid_tr_inline && param_i!=-1)
        {
          findLineFromCurrentTransformation(id_status, stri2);
          int i2=atoi(stri2);

          if (i2!=param_i)
	  {
            appendDBtoTMPbeforeID(id_status, stri2);

            sprintf(stri1, "%d", param_i);
            recordLineTMP(id_status, stri1);
            change=true;
          }
	  else appendDBtoTMPonlyCurTr();
        }
        else if (tr==iid_tr_ff && param_ff!=-1)
        {
          findLineFromCurrentTransformation(id_status, stri2);
          int i2=atoi(stri2);
          if (i2!=param_ff)
	  {
            appendDBtoTMPbeforeID(id_status, stri2);

            sprintf(stri1, "%d", param_ff);
            recordLineTMP(id_status, stri1);
            change=true;
          }
	  else appendDBtoTMPonlyCurTr();
        }
        else if (tr==iid_tr_pf && param_p!=-1)
        {
          findLineFromCurrentTransformation(id_pf_offset, stri2);
          findLineFromCurrentTransformation(id_status, stri3);
          int i2=atoi(stri2);
          int i3=atoi(stri3);

          if ((i2!=param_p) || ((param_p==0) && (i3!=0)) || (i3!=1))
	  {
            appendDBtoTMPbeforeID(id_pf_offset, stri2);

            sprintf(stri1, "%d", param_p);
            recordLineTMP(id_pf_offset, stri1);

            if (param_p==0) sprintf(stri1, "%d", 0);
  	    else sprintf(stri1, "%d", 1);
            recordLineTMP(id_status, stri1);
            change=true;
          }
	  else appendDBtoTMPonlyCurTr();
        }
        else if (tr==iid_tr_simd && param_v!=-1)
        {
          findLineFromCurrentTransformation(id_simd_vectors, stri2);
          findLineFromCurrentTransformation(id_status, stri3);
          int i2=atoi(stri2);
          int i3=atoi(stri3);

          if (((param_v==0) && (i3!=0)) || (i3!=1) || (i2!=param_v))
	  {
            appendDBtoTMPbeforeID(id_status, stri2);

            if (param_v==0) sprintf(stri1, "%d", 0);
  	    else sprintf(stri1, "%d", 1);
            recordLineTMP(id_status, stri1);

            sprintf(stri1, "%d", param_v);
            recordLineTMP(id_simd_vectors, stri1);

            sprintf(stri1, "%d", 0);
            recordLineTMP(id_simd_ut, stri1);

            sprintf(stri1, "%d", 0);
            recordLineTMP(id_simd_atb, stri1);
            change=true;
          }
	  else appendDBtoTMPonlyCurTr();
        }
        else if (tr==iid_tr_snl && (param_rt1!=-1 || param_rt2!=-1 
	                         || param_rt3!=-1 || param_rt4!=-1
	                         || param_b1!=-1  || param_b2!=-1
	                         || param_b3!=-1  || param_b4!=-1))
        {
          findLineFromCurrentTransformation(id_status, stri3);
          int i3=atoi(stri3);
          if (i3==0)
	  {
            appendDBtoTMPbeforeID(id_status, stri2);
            recordLineTMP(id_status, "1");
            change=true;
	  }
	  else
	  {
            int n=getSNL_LoopNests(t);
            int bs=getSNL_TilingStatus(t);
            int b=0;
            if (bs!=0) b=getSNL_NumberOfTiles(t);

            change1=false;

            if (n>0)
	    {
              int i=0;
  	      for (i=1; i<=n; i++)
	      {
                snl_i[i]=i;
	        snl_r[i]=1;

                snl_bi[i]=snl_i[i];
	        snl_br[i]=snl_r[i];
	      }

              getTransformation(t, _fff); //to init

              findLineFromCurrentTransformation(id_lnt_outer, str1);
              int lo=atoi(str1);
  	      for (i=1; i<=n; i++)
	      {
                findLineFromCurrentTransformationX(id_lnt_new_loop_order, str1, i-1);
                snl_i[i]=atoi(str1)-lo+1;

                findLineFromCurrentTransformationX(id_lnt_new_reg_tiling, str1, i-1);
	        snl_r[i]=atoi(str1);

                snl_bi[i]=snl_i[i];
	        snl_br[i]=snl_r[i];
	      }

  	      for (i=1; i<=b; i++)
	      {
                findLineFromCurrentTransformationX(id_lnt_iln, str1, i-1);
                snl_t1[i]=atoi(str1)-lo;

                findLineFromCurrentTransformationX(id_lnt_loop_strip, str1, i-1);
	        snl_t2[i]=atoi(str1);

                findLineFromCurrentTransformationX(id_lnt_cache_level, str1, i-1);
	        snl_t3[i]=atoi(str1);
	      }

              //register tiling
              if      (param_rt1==0 && n>0)
	      {
	        if (snl_br[1]!=1) {snl_br[1]=1; change1=true;}
	      }
	      else if (param_rt1 >0 && n>0) 
	      {
	        if (snl_br[1]!=param_rt1) {snl_br[1]=param_rt1; change1=true;}
	      }

              if      (param_rt2==0 && n>1) 
	      {
	        if (snl_br[2]!=1) {snl_br[2]=1; change1=true;}
	      }
	      else if (param_rt2 >0 && n>1) 
	      {
	        if (snl_br[2]!=param_rt2) {snl_br[2]=param_rt2; change1=true;}
	      }

              if      (param_rt3==0 && n>2) 
	      {
	        if (snl_br[3]!=1) {snl_br[3]=1; change1=true;}
	      }
	      else if (param_rt3 >0 && n>2) 
	      {
	        if (snl_br[3]!=param_rt3) {snl_br[3]=param_rt3; change1=true;}
	      }

              if      (param_rt4==0 && n>3) 
	      {
	        if (snl_br[4]!=1) {snl_br[4]=1; change1=true;}
	      }
	      else if (param_rt4 >0 && n>3) 
	      {
	        if (snl_br[4]!=param_rt4) {snl_br[4]=param_rt4; change1=true;}
	      }

              //blocking
              if (param_b1!=-1 && n>0)
	      {
                ij=findLoop(snl_t1, b, 0);
                if (param_b1==0) 
		{
		  if (ij!=0) {removeTile(snl_t1, snl_t2, snl_t3, ij, b); b--; change1=true;}
		}
		else
		{
                  if (ij!=0)
		  {
                    if (snl_t2[ij]!=param_b1) {snl_t2[ij]=param_b1; change1=true;}
		  }
		  else {b++; snl_t1[b]=0; snl_t2[b]=param_b1; snl_t3[b]=0; change1=true;}
		}
	      }

              if (param_b2!=-1 && n>1)
	      {
                ij=findLoop(snl_t1, b, 1);
                if (param_b2==0) 
		{
		  if (ij!=0) {removeTile(snl_t1, snl_t2, snl_t3, ij, b); b--; change1=true;}
		}
		else
		{
                  if (ij!=0)
		  {
                    if (snl_t2[ij]!=param_b2) {snl_t2[ij]=param_b2; change1=true;}
		  }
		  else {b++; snl_t1[b]=1; snl_t2[b]=param_b2; snl_t3[b]=0; change1=true;}
		}
	      }

              if (param_b3!=-1 && n>2)
	      {
                ij=findLoop(snl_t1, b, 2);
                if (param_b3==0) 
		{
		  if (ij!=0) {removeTile(snl_t1, snl_t2, snl_t3, ij, b); b--; change1=true;}
		}
		else
		{
                  if (ij!=0)
		  {
                    if (snl_t2[ij]!=param_b3) {snl_t2[ij]=param_b3; change1=true;}
		  }
		  else {b++; snl_t1[b]=2; snl_t2[b]=param_b3; snl_t3[b]=0; change1=true;}
		}
	      }
              if (param_b4!=-1 && n>3)
	      {
                ij=findLoop(snl_t1, b, 3);
                if (param_b4==0) 
		{
		  if (ij!=0) {removeTile(snl_t1, snl_t2, snl_t3, ij, b); b--; change1=true;}
		}
		else
		{
                  if (ij!=0)
		  {
                    if (snl_t2[ij]!=param_b4) {snl_t2[ij]=param_b4; change1=true;}
		  }
		  else {b++; snl_t1[b]=3; snl_t2[b]=param_b4; snl_t3[b]=0; change1=true;}
		}
	      }

              if (change1)
              {
                appendDBtoTMPbeforeID(id_lnt_outer, stri2);
                lo=atoi(stri2);
                recordLineTMP(id_lnt_outer, stri2);
    
                strcpy(stri2, "new_order:   ");
                strcpy(stri3, "new_reg_tile:");
                for (i=1; i<=n; i++)
                {
                  sprintf(stri1, "%u", i-1); //internal numbering of loops starts from 0
                  recordLineTMP(id_lnt_loop_number, stri1);
          
                  sprintf(stri1, "%u", snl_bi[i]-1+lo); //recent change +lo
                  recordLineTMP(id_lnt_new_loop_order, stri1);
                  strcat(stri2, stri1);
                  strcat(stri2, "  ");

                  sprintf(stri1, "%u", snl_br[i]);
                  recordLineTMP(id_lnt_new_reg_tiling, stri1);
                  strcat(stri3, stri1);
                  strcat(stri3, "  ");
                }
                recordLineTMP(id_rem, stri2);
                recordLineTMP(id_rem, stri3);

                if (b==0) recordLineTMP(id_lnt_blocking_status, "0");
                else
                {
                  recordLineTMP(id_lnt_blocking_status, "1");
                  sprintf(stri1, "%u", b);
                  recordLineTMP(id_lnt_nbl, stri1);

                  for (i=1; i<=b; i++)
                  {
                    sprintf(stri1, "%u", snl_t1[i]+lo); //recent change +lo
                    recordLineTMP(id_lnt_iln, stri1);

                    sprintf(stri1, "%u", snl_t2[i]);
                    recordLineTMP(id_lnt_loop_strip, stri1);

                    sprintf(stri1, "%u", snl_t3[i]);
                    recordLineTMP(id_lnt_cache_level, stri1);
                  }
                }
    
                recordLineTMP(id_status, "1");

                change=true;
  	      }
	      else appendDBtoTMPonlyCurTr();
	    }
	    else appendDBtoTMPonlyCurTr();
	  }
        }
        else appendDBtoTMPonlyCurTr();
        //add local padding
      }
      else appendDBtoTMPonlyCurTr();
    
      t++;
    }

    renameBack();
    if (!change) 
    {
      ret=1;
      finish=true;
    }
    else
    {
      remove(ftmp);
      rename(getDBW(), ftmp);

      setFComp(_fcomp1, _fcomp_mode_rw, ftmp, getDBW());
      system(_fcomp);
      if (fileExist(_fout)!=1) return 2;

      if (diffFiles(ftmp, getDBW())!=0)
      {
        remove(ftmp);
        rename(getDBW(), ftmp);
        setDBIO(ftmp, strj2);
      }
      else finish=true;
      tr_max=findNumberOfTransformations(getDBR());
    }

    attempts++;
  }

  if (!finish && change)
  {
    remove(getDBW());
    rename(ftmp, getDBW());
  }

  printf("\n");

  remove(ftmp);

  setDBIO(strj1, strj2);

  return ret;
}

int diffFiles(char* fn1, char* fn2)
{
  int ret=2;
  
  FILE* f1=NULL;
  FILE* f2=NULL;

  if ((f1=fopen(fn1, "r"))!=NULL)
  {
    if ((f2=fopen(fn2, "r"))!=NULL)
    {
      while  ((fgets(stri1, 1023, f1)!=NULL) 
           && (fgets(stri2, 1023, f2)!=NULL) 
           && (feof(f1)==0)
           && (feof(f2)==0))
      {
        if (strcmp(stri1,stri2)!=0)
        {
          ret=1;
          break;
        }
      }
      if (ret==2) ret=0;

      fclose(f2);
    }      
    fclose(f1);
  }
  if (ret==2) ret=1;

  return ret;
}

int findLoop(int* array, int max, int p)
{
  for (int i=1; i<=max; i++)
  {
    if (array[i]==p) return i;
  }
  return 0;
}

void removeTile(int* array1, int* array2, int* array3, int place, int max)
{
  for (int i=place; i<=max-1; i++)
  {
    array1[i]=array1[i+1];
    array2[i]=array2[i+1];
    array3[i]=array3[i+1];
  }
}
