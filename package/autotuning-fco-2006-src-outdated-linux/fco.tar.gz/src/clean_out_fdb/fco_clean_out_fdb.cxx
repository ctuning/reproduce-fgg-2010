/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _fic          "_finfo_iter"        //current iteration
#define _fic_db       ".fdb"               //extension for transformation database
#define _fic_tim      ".time"              //extension for time (run)
#define _fic_timc     ".timec"             //extension for time (compilation)
#define _fic_inf      ".info"              //extension for info
#define _fic_tri1     ".tr_i1"             //extension for transformation info
#define _fic_tri2     ".tr_i2"             //extension for transformation info
#define _fic_out      ".a.out"

char str1[1024];

int main(int argc, char* argv[])
{
  FILE* fin=NULL;
  FILE* fin1=NULL;

  long iter=1;

  int finish=0;

  printf("FCO Clean Iterations\n\n");

  if (argc>1) iter=atoi(argv[1]);
  
  while (finish==0)
  {
    printf("Removing iteration %u ...\n", iter);

    sprintf(str1, _fic ".%06u" _fic_inf, iter);
    if ((fin=fopen(str1, "r"))==NULL) finish=1;
    else
    {
      fclose(fin);
      
      sprintf(str1, _fic ".%06u" _fic_db, iter);
      remove(str1);

      sprintf(str1, _fic ".%06u" _fic_out, iter);
      remove(str1);
    }
    iter++;
  }
  printf("\nProgram finished!\n");
  
  return 0;
}
