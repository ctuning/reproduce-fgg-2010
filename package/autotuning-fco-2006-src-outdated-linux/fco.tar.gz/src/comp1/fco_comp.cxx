/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "futils.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fcomp     "_fbcomp"          //compile batch file
#define _fcomp1    "fcompilation"     //file for FCompilation
#define _fout      "a.out"            //exe file

#define _fcomp_mode_0  0         
#define _fcomp_mode_w  2
#define _fcomp_mode_r  3
#define _fcomp_mode_rw 4

char str1[1024]; //Not very clean, should change when have time
char str2[1024];
char str3[1024];
char str4[1024];
char str5[1024];
char str6[1024];

int main(int argc, char* argv[])
{
  double tt=0;
  double t1=0;
  double t2=0;
  double tta=0;

  int iter=0;

  printf("FCO Compilation\n");

  printf("\n");
  
  if (argc!=3)
  {
    printf("Compile project using fdb1 and create new fdb2\n");
    printf("\n");
    printf("Usage:\n");
    printf(" fco_comp <fdb1> <fdb2>\n");
    printf("\n");

    exit(1);
  }

  printf("fdb1=%s\n", argv[1]);
  printf("fdb2=%s\n", argv[2]);
  
  printf("\n");
  printf("Set fcompilation to Read/Write mode ...\n");

  setFComp(_fcomp1, _fcomp_mode_rw, argv[1], argv[2]);
    
  printf("Compile program ...\n");
  system(_fcomp);

  printf("\n");
  if (fileExist(_fout)!=1)
  {
    printf("Error: Executable is not created!\n");
    exit(1);
  }

  printf("Program finished sucessfully!\n");
  exit(0);
}
