FCO Compilation

Compile project using fdb1 and create new fdb2

Usage:
 fco_compx <fdb1> <fdb2>
 