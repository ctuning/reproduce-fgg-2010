/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "ftransformations.h"
#include "futils.h"
#include "fids.h"
#include "param.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fff       "_finfo_funcs"     //file with the list of functions to transform
#define _fff1      "_finfo_funcs1"    //file with the list of functions to transform
#define _ftr       "_finfo_tr"        //file with the list of transformations used
#define _fic       "_finfo_iter"      //current iteration
#define _fic_cur   ".cur"             //extension for current iteration
#define _fic_db    ".fdb"             //extension for transformation database
#define _fic_inf   ".info"            //extension for info
#define _fic_stat  ".stat"            //extension for statistics
#define _fic_tri1  ".tr_i1"           //extension for transformation info1
#define _fic_tri2  ".tr_i2"           //extension for transformation info2

char str1[1024];  //Not very clean, should change when have time
char str2[1024];

char db_r[1024];
char db_w[1024];

long findInArray(long fc, long* buf, long lbuf);
void sortArray(long* buf, long* buf1, long lbuf);

int main(int argc, char* argv[])
{
  FILE* ff;

  char funcs[256][256];
  int ix=0;
  int ixm=256;
  int i=0;

  printf("FCO Statistics   V1.2   (C) by Grigori G.Fursin   January,2006\n");

  for (i=0; i<ixm; i++) funcs[i][0]=0;

  //prepare db_r
  sprintf(db_r, _fic ".%06u" _fic_db, 0);
  setDBIO(db_r, "");

  long tr_max=findNumberOfTransformations(db_r);

  printf("\n");
  printf("Number of original transformations: %u\n", tr_max);

  long trx=1;    

  printf("\n");
  while(trx<=tr_max)
  {
    long tr=getTransformation(trx, _fff);

    if (tr<0) 
    {
      printf("\n");
      printf("This transformation is skipped!\n");
    }

    getCurTransformationFunc(str1);

    bool found=false;
    for (i=0; i<ixm; i++)
    {
      if (strcmp(str1, funcs[i])==0) found=true;
    }
    
    if (!found)
    {
      if (ix<=ixm) 
      {
        strcpy(funcs[ix], str1);
        printf("Function detected: %s\n", str1);
        ix++;
      }
    }

    trx++;
  }

  if (ix>0)
  {
    printf("\n");
    printf("Writing file with functions...\n");
    
    if ((ff=fopen(_fff1, "w"))==NULL)
    {
      printf("ERROR: Can't open file to save functions...\n");
      exit(1);
    }

    for (i=0; i<ix; i++)
    {
      fprintf(ff, "%s\n", funcs[i]);
    }

    fclose(ff);
  }
}
