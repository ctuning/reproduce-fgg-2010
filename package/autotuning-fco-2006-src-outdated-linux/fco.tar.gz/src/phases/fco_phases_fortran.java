//
// "Fresh Optimizing Software" Program Phases Preparation
// for run-time optimizations
//
// Copyright (C) 2000-2005 by Grigori G.Fursin
//
// http://homepages.inf.ed.ac.uk/gfursin
//
// INRIA Futurs (France) / University of Edinburgh (UK)
//

import java.io.*;

public class fco_phases_fortran
{
  public static void main(String args[])
  {
    String fname="_finfo_phases";
    String ftmp=".tmp";
    String ftmp1="ftmp.tmp";
    String fbak=".bak";

    String fname1="fco_timers.c";

    long sn1=0;
    String[] sn2=new String [128];

    int timer_max=0;
    int proc_max=8; //default

    String fil="";

    String str="";
    String str1="";
    String func="";

    System.out.println("Program Phases Preparation");

    if (args.length>0)
    {
      str=args[0].trim();

      try
      {
        proc_max=Integer.valueOf(str).intValue();
      }
      catch (NumberFormatException nfe1)
      {}   
    }

    System.out.println("");
    System.out.println("Number of procedure multi-versions: "+
                       String.valueOf(proc_max));

    BufferedReader fin=null;

    try 
    {
      fin=new BufferedReader(new FileReader(fname));
    }
    catch (IOException e1) 
    {
      System.out.println("Error while opening file "+fname+" ...");
      System.exit(1);
    }

    try  
    {
      while ((fil=fin.readLine())!=null)  
      {
        System.out.println("");
        System.out.println("Processing file: "+fil);
        System.out.println("");

        str=fin.readLine();

        BufferedReader fin1=null;
        BufferedWriter fout1=null;

        try 
        {
          fin1=new BufferedReader(new FileReader(fil));
          fout1=new BufferedWriter(new FileWriter(fil+ftmp));
        }
        catch (IOException e1) 
        {
          System.out.println("Error while opening file "+fil+ftmp+" ...");
          System.exit(1);
        }

        long line=1;

        while (((str=fin.readLine())!=null) && (!str.equals("")))  
        {
          int timer=0;
          long line1=0;
          long line2=0;
          long line3=0;
          long line4=0;
          long line5=0;

          int i1=0;
          int i2=str.indexOf(" ");
          if (i2<0)
          {
            System.out.println("Error while parsing file "+fname+" ...");
            System.exit(1);
          }
          str1=str.substring(i1,i2);
          try
          {
            timer=Integer.valueOf(str1).intValue();
          }
          catch (NumberFormatException nfe1)
          {}   

          i1=i2+1;
          i2=str.indexOf(" ", i1);
          if (i2<0)
          {
            System.out.println("Error while parsing file "+fname+" ...");
            System.exit(1);
          }
          str1=str.substring(i1,i2);
          try
          {
            line1=Long.valueOf(str1).longValue();
          }
          catch (NumberFormatException nfe1)
          {}   

          i1=i2+1;
          i2=str.indexOf(" ", i1);
          if (i2<0)
          {
            System.out.println("Error while parsing file "+fname+" ...");
            System.exit(1);
          }
          str1=str.substring(i1,i2);
          try
          {
            line2=Long.valueOf(str1).longValue();
          }
          catch (NumberFormatException nfe1)
          {}   

          i1=i2+1;
          i2=str.indexOf(" ", i1);
          if (i2<0)
          {
            System.out.println("Error while parsing file "+fname+" ...");
            System.exit(1);
          }
          str1=str.substring(i1,i2);
          try
          {
            line3=Long.valueOf(str1).longValue();
          }
          catch (NumberFormatException nfe1)
          {}   

          i1=i2+1;
          i2=str.indexOf(" ", i1);
          if (i2<0)
          {
            System.out.println("Error while parsing file "+fname+" ...");
            System.exit(1);
          }
          str1=str.substring(i1,i2);
          try
          {
            line4=Long.valueOf(str1).longValue();
          }
          catch (NumberFormatException nfe1)
          {}   

          i1=i2+1;
          i2=str.indexOf(" ", i1);
          if (i2<0)
          {
            System.out.println("Error while parsing file "+fname+" ...");
            System.exit(1);
          }
          str1=str.substring(i1,i2);
          try
          {
            line5=Long.valueOf(str1).longValue();
          }
          catch (NumberFormatException nfe1)
          {}   

          String procx=str.substring(i2,str.length());

          i1=procx.indexOf("$#$", i1);
          if (i1<0)
          {
            System.out.println("Error while parsing file "+fname+" ...");
            System.exit(1);
          }

          String procx1=procx.substring(0,i1);
          String procx2=procx.substring(i1+3, procx.length());

          String procx3="";
          i1=procx1.trim().indexOf(" ");
          if (i1<0)
          {
            System.out.println("Error while parsing file "+fname+" ...");
            System.exit(1);
          }
          procx3=procx1.trim().substring(i1+1, procx1.trim().length()).trim();

          System.out.println("Processing procedure #"+timer+" ("+
                             String.valueOf(line1)+" - "+
                             String.valueOf(line2)+")");

          if (timer_max<timer) timer_max=timer;        

          //reading before procedure
          while (line<line1)
          {
            str=fin1.readLine();
            fout1.write(str);
            fout1.newLine();
            line++;
          }

          //writing proc to tmp
          BufferedWriter fout2=null;
          try 
          {
            fout2=new BufferedWriter(new FileWriter(ftmp1));
          }
          catch (IOException e1) 
          {
            System.out.println("Error while opening file "+ftmp1+" ...");
            System.exit(1);
          }

          sn1=line5-line4+1;

          //reading before procedure
          long liner=1;
          int  linerx=1;
          long liner3=1; //relative line where to add stuff
          long liner4=1; //relative line where to change func name
          while (line<=line2)
          {
            if (line==line3) liner3=liner;
            if (line==line4) liner4=liner;

            str=fin1.readLine();
            fout2.write(str);
            fout2.newLine();

            if ((line>line4) && (line<=line5)) 
            {
              sn2[linerx]=str;
              linerx++;
            }
            line++;
            liner++;
          }

          try  
          {
            fout2.close();
          }
          catch (Exception e5)  
          {
            System.out.println("Error while closing file "+ftmp1+" ...");
            System.exit(1);
          }

          //creating switching
          BufferedReader fin2=null;
  
          liner=1;
          try 
          {
            fin2=new BufferedReader(new FileReader(ftmp1));
          }
          catch (IOException e1) 
          {
            System.out.println("Error while opening file "+ftmp1+" ...");
            System.exit(1);
          }

          while ((str=fin2.readLine())!=null)  
          {
            if (liner==liner3)
            {
              fout1.newLine();

              int j=0;
              String num="";
              String tmr=String.valueOf(timer);
              String lbl=String.valueOf(timer+10);;

              fout1.write("      INTEGER FSELECT");
              fout1.newLine();
              fout1.write("");
              fout1.newLine();
              fout1.write("      CALL FCO_TIMER1("+tmr+", FSELECT)");
              fout1.newLine();

              str="      GOTO (";
              for (j=0; j<=proc_max; j++)
              {
                num=String.valueOf(j);
                if (num.length()<2) num="0"+num;
                str+=lbl+num;

                if (j!=proc_max) str+=", ";

                if ((str.length()>50) && j!=proc_max)
                {
                  fout1.write(str);
                  fout1.newLine();
                  str="     +";
                }
              }

              fout1.write(str+"), FSELECT+1");
              fout1.newLine();                

              fout1.write("");
              fout1.newLine();

              for (j=0; j<=proc_max; j++)
              {
                num=String.valueOf(j);
                if (num.length()<2) num="0"+num;
                str=lbl+num;

                fout1.write(str+"  CONTINUE");
                fout1.newLine();
                fout1.write("      CALL "+procx3+"_"+num+procx2);
                fout1.newLine();
                for (int k=1; k<sn1; k++)
                {
                  fout1.write(sn2[k]);
                  fout1.newLine();
                }
                num="99";
                if (num.length()<2) num="0"+num;
                str=lbl+num;
                fout1.write("      GOTO "+str);
                fout1.newLine();
                fout1.newLine();
              }

              num="99";
              if (num.length()<2) num="0"+num;
              str=lbl+num;

              fout1.write(str+"  CONTINUE");
              fout1.newLine();
              fout1.write("      CALL FCO_TIMER2("+tmr+")");
              fout1.newLine();
              fout1.write("      RETURN");
              fout1.newLine();
              fout1.write("      END");
              fout1.newLine();
              fout1.newLine();
 
              break;
            }

            fout1.write(str);
            fout1.newLine();

            liner++;
          }
          fout1.newLine();
          
          try  
          {
            fin2.close();
          }
          catch (Exception e5)  
          {
            System.out.println("Error while closing file "+ftmp1+" ...");
            System.exit(1);
          }

          //create multi-versions
          for (int p=0; p<=proc_max;p++)
          {
            fin2=null;

            liner=1;
            try 
            {
              fin2=new BufferedReader(new FileReader(ftmp1));
            }
            catch (IOException e1) 
            {
              System.out.println("Error while opening file "+ftmp1+" ...");
              System.exit(1);
            }

            while ((str=fin2.readLine())!=null)  
            {
              if (liner==liner4)
              {
                String strp=String.valueOf(p);
                if (p<10) strp="0"+strp;
                str=procx1+"_"+strp+procx2;
              }

              fout1.write(str);
              fout1.newLine();

              liner++;
            }
            fout1.newLine();
            
            try  
            {
              fin2.close();
            }
            catch (Exception e5)  
            {
              System.out.println("Error while closing file "+ftmp1+" ...");
              System.exit(1);
            }
          }
        }

        //finish writing file
        while ((str=fin1.readLine())!=null)  
        {
          fout1.write(str);
          fout1.newLine();
        }

        try  
        {
          fin1.close();
          fout1.close();
        }
        catch (Exception e5)  
        {
          System.out.println("Error while closing file "+fil+ftmp+" ...");
          System.exit(1);
        }

        //rename old file to new file
        File fr1 = new File(fil);
        File fr2 = new File(fil+fbak);
        File fr3 = new File(fil+ftmp);
   
        boolean success = fr1.renameTo(fr2);
        success = fr3.renameTo(fr1);
      }

      System.out.println("");
      System.out.println("Maximum number of timers: "+
                         String.valueOf(timer_max));
    }
    catch (Exception e3)  
    {
      try  
      {
        fin.close();
      }
      catch (Exception e4)  {}
      System.out.println("Error while reading file "+fname+" ...");
      System.exit(1);
    }

    try  
    {
      fin.close();
    }
    catch (Exception e5)  
    {
      System.out.println("Error while reading file "+fname+" ...");
      System.exit(1);
    }

    File fdel=null;
    try
    {
      fdel=new File(ftmp1);
      fdel.delete();
    }
    catch (NullPointerException e1)
    {}

    //Processing fco_timer
    System.out.println();
    System.out.println("Processing file "+fname1);

    BufferedReader fin1=null;
    BufferedWriter fout1=null;

    try 
    {
      fin1=new BufferedReader(new FileReader(fname1));
      fout1=new BufferedWriter(new FileWriter(fname1+ftmp));
    }
    catch (IOException e1) 
    {
      System.out.println("Error while opening file "+fname1+" ...");
      System.exit(1);
    }

    try
    {
      while ((str=fin1.readLine())!=null)  
      {
        int i1=str.indexOf("$#$1");
        if (i1>=0)
        {
          str=str.substring(0,i1)+String.valueOf(timer_max);
        }

        i1=str.indexOf("$#$2");
        if (i1>=0)
        {
          str=str.substring(0,i1)+String.valueOf(proc_max);
        }
        
        fout1.write(str);
        fout1.newLine();
      }
    }
    catch (Exception e3)  
    {
      try  
      {
        fin1.close();
        fout1.close();
      }
      catch (Exception e4)  {}
      System.out.println("Error while processing file "+fname1+" ...");
      System.exit(1);
    }

    try  
    {
      fin1.close();
      fout1.close();
    }
    catch (Exception e5)  
    {
      System.out.println("Error while closing file "+fname1+" ...");
      System.exit(1);
    }

    //rename old file to new file
    File fr1 = new File(fname1);
    File fr2 = new File(fname1+fbak);
    File fr3 = new File(fname1+ftmp);

    boolean success = fr1.renameTo(fr2);
    success = fr3.renameTo(fr1);

    System.out.println("");
    System.out.println("End of program");
    System.exit(0);
  }
}
