/*
 * "Fresh Continous Optimizations" Software 
 * Timers to obtain IPC
 *
 * Copyright (C) 2000-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs (France) / University of Edinburgh (UK)
 */

#include <stdio.h>
#include <malloc.h>
#include <assert.h>
#include <signal.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "papi.h"

#define debug        0 //save debug info in file (for each timer call)

#define timers_max   2
#define proc_max     8

#define PAPI_event   PAPI_TOT_INS
#define FREQUENCY    2400000000

#define queue_max           10     //max buffer size
#define threshold_time       0.02  //for period detection (not to check small procedures)
#define precision_ipc        0.03  //for period detection   
#define precision_time       0.03  //for perios detection
#define precision_time_best  0.003 //when compare with best time

#define stability_wait       3 //wait before transforming
#define stability_transform  2 //transform after No of predictions
#define stability_check      2 //check for correctness of No of predictions + stability_transform

int retval;
int EventSet=PAPI_NULL;

long_long         values;

static double     Timers1[timers_max+1];
static double     Timers2[timers_max+1];
static long       Calls[timers_max+1];
static long       Prediction[timers_max+1];

static int        first_run=0;

char str[1024];
char str1[1024];

static int        ftest=0;

static long   Queue[timers_max+1];
static long   Run[timers_max+1];
static double TIME[timers_max+1][queue_max+1];
static double IPC[timers_max+1][queue_max+1];
static long   Call1[timers_max+1][queue_max+1];
static long   Call2[timers_max+1][queue_max+1];
static long   Num[timers_max+1][queue_max+1];
static long   Period[timers_max+1][queue_max+1];
static long   Length1[timers_max+1][queue_max+1];
static long   Length2[timers_max+1][queue_max+1];
static long   State[timers_max+1][queue_max+1];
static int    Proc[timers_max+1][queue_max+1];
static double TIME1[timers_max+1][queue_max+1];
static double IPC1[timers_max+1][queue_max+1];
static double TIME2[timers_max+1][queue_max+1];
static double IPC2[timers_max+1][queue_max+1];
static int    Proc2[timers_max+1][queue_max+1];
static int    Test[timers_max+1][queue_max+1];
static int    Hit[timers_max+1][queue_max+1];
static int    Miss[timers_max+1][queue_max+1];
static int    HitSeq[timers_max+1][queue_max+1];
static int    HitSeqTr[timers_max+1][queue_max+1];

void fos_dump_state(int tmr, int q);

int indexOf(char* str, char x, int start)
{
  int found=0;

  int i=start;
  int j=strlen(str);
  
  while ((i<j) && (found==0))
  {
    if (str[i]==x) found=i;
    i++;
  }

  return found;
}

int substring(char* str1, char* str2, int start, int end)
{
 int i=start;
 int j=0;
 while (i<=end)
 {
   str2[j]=str1[i];
   j++;
   i++;
 }
 str2[j]=0;
}

void fos_timers_finish(void)
{
  FILE *f;
  int i=0;
  int tmr=0;
  int q=0;

  for (tmr=1; tmr<=timers_max; tmr++)
  {
    sprintf(str, "_fos_out.%u.database", tmr);
    if ((f=fopen(str,"wt"))==NULL)
    {
      printf("\nFatal Error (FATOM): Can't write file!\n");
      exit(1);
    }

    Run[tmr]++;
    fprintf(f, "run={%4u}\n", Run[tmr]);

    for (q=0; q<Queue[tmr]; q++)
    {
      fprintf(f, "buffer={%4u}, time={%5.3f}, ipc={%5.3f}, proc={%4u}, ",
                 q, TIME[tmr][q], IPC[tmr][q], Proc[tmr][q]);
      fprintf(f, "best_proc={%4u}, best_time={%5.3f}, best_ipc={%5.3f}, ",
                 Proc2[tmr][q], TIME2[tmr][q], IPC2[tmr][q]);
      fprintf(f, "hits={%6u}, misses={%6u}, ",
		 Hit[tmr][q], Miss[tmr][q]);
      fprintf(f, "hits_in_sequence={%6u}, potential_transformations={%6u}, ",
                 HitSeq[tmr][q], HitSeqTr[tmr][q]);
      fprintf(f, "call1={%4u}, call2={%4u}, period={%4u}, num={%4u}, ", 
                  Call1[tmr][q], Call2[tmr][q], Period[tmr][q], Num[tmr][q]);
      fprintf(f, "length1={%u}, length2={%u}\n", 
                 Length1[tmr][q], Length2[tmr][q]);
    }

    fclose(f);
  }

  return;
}

void fos_timers_init(void)
{
  long y;
  long q;
  FILE *f;

  atexit(fos_timers_finish);

  for (y=1; y<=timers_max; y++)
  {
    Timers1[y]=0;
    Timers2[y]=0;
    Calls[y]=0;  
    Prediction[y]=-1;
    Run[y]=0;

    sprintf(str, "_fos_out.%u.diag1", y);
    if ((f=fopen(str,"wt"))==NULL)
    {
      printf("\nFatal Error (FATOM): Can't write file!\n");
      exit(1);
    }
    fclose(f);

    sprintf(str, "_fos_out.%u.diag2", y);
    if ((f=fopen(str,"wt"))==NULL)
    {
      printf("\nFatal Error (FATOM): Can't write file!\n");
      exit(1);
    }
    fclose(f);
  }

  for (y=1; y<=timers_max; y++)
  {
    Queue[y]=0;
  }
  
  for (q=0; q<queue_max; q++)
  {
    for (y=1; y<=timers_max; y++)
    {
      TIME[y][q]=0;
      IPC[y][q]=0;
      Call1[y][q]=0;
      Call2[y][q]=0;
      Num[y][q]=0;
      Period[y][q]=0;
      Length1[y][q]=0;
      Length2[y][q]=0;
      State[y][q]=0;
      Proc[y][q]=1;
      TIME1[y][q]=0;
      IPC1[y][q]=0;
      TIME2[y][q]=0;
      IPC2[y][q]=0;
      Proc2[y][q]=0;
      Test[y][q]=0;
      Hit[y][q]=0;
      Miss[y][q]=0;
      HitSeq[y][q]=0;
      HitSeqTr[y][q]=0;
    }
  }

  //load the database if it's available
  int i1;
  int i2;
  for (y=1; y<=timers_max; y++)
  {
    sprintf(str, "_fos_out.%u.database", y);
    if ((f=fopen(str,"rt"))!=NULL)
    {
      q=-1;
      while ((fgets(str, 1023, f)!=NULL) && (feof(f)==0))
      {
        if (q==-1)
	{
          i1=indexOf(str, '{', 0);
  	  if (i1>0)
  	  {
            i2=indexOf(str, '}', i1);
	  }
          substring(str, str1, i1+1, i2-1);
          Run[y]=atoi(str1);
	}
        else
	{
          i1=indexOf(str, '{', 0);
  	  if (i1>0)
  	  {
            i2=indexOf(str, '}', i1);
	  }
          //dummy buffer

          i1=indexOf(str, '{', i2);
  	  if (i1>0)
	  {
            i2=indexOf(str, '}', i1);
  	  }
          substring(str, str1, i1+1, i2-1);
          TIME[y][q]=atof(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
  	  {
            i2=indexOf(str, '}', i1);
  	  }
          substring(str, str1, i1+1, i2-1);
          IPC[y][q]=atof(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0) 
	  {
            i2=indexOf(str, '}', i1);
   	  }
          substring(str, str1, i1+1, i2-1);
          Proc[y][q]=atol(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
	  {
            i2=indexOf(str, '}', i1);
	  }
          substring(str, str1, i1+1, i2-1);
          Proc2[y][q]=atol(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
	  {
            i2=indexOf(str, '}', i1);
	  }
          substring(str, str1, i1+1, i2-1);
          TIME1[y][q]=atof(str1);
          TIME2[y][q]=atof(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
  	  {
            i2=indexOf(str, '}', i1);
	  }
          substring(str, str1, i1+1, i2-1);
          IPC1[y][q]=atof(str1);
          IPC2[y][q]=atof(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
	  {
            i2=indexOf(str, '}', i1);
	  }
          substring(str, str1, i1+1, i2-1);
          Hit[y][q]=atol(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
	  {
            i2=indexOf(str, '}', i1);
	  } 
          substring(str, str1, i1+1, i2-1);
          Miss[y][q]=atol(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
	  {
            i2=indexOf(str, '}', i1);
	  }
          substring(str, str1, i1+1, i2-1);
          HitSeq[y][q]=atol(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
	  {
            i2=indexOf(str, '}', i1);
  	  }
          substring(str, str1, i1+1, i2-1);
          HitSeqTr[y][q]=atol(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
	  {
            i2=indexOf(str, '}', i1);
	  }
          substring(str, str1, i1+1, i2-1);
          Call1[y][q]=atol(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
	  {
            i2=indexOf(str, '}', i1);
 	  }
          substring(str, str1, i1+1, i2-1);
          Call2[y][q]=atol(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
 	  {
            i2=indexOf(str, '}', i1);
	  }
          substring(str, str1, i1+1, i2-1);
          Period[y][q]=atol(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
  	  {
            i2=indexOf(str, '}', i1);
	  }
          substring(str, str1, i1+1, i2-1);
          Length1[y][q]=atol(str1);

          i1=indexOf(str, '{', i2);
	  if (i1>0)
	  {
            i2=indexOf(str, '}', i1);
	  }
          substring(str, str1, i1+1, i2-1);
          Length2[y][q]=atol(str1);
        }
	q++;
      }
      Queue[y]=q;
      
      fclose(f);
    }
  }

  if ((retval = PAPI_library_init(PAPI_VER_CURRENT)) != PAPI_VER_CURRENT)
  {
    printf("\nError: PAPI_library_init");
    exit(1);
  }

  if ((retval = PAPI_create_eventset(&EventSet)) != PAPI_OK)
  {
    printf("\nError: PAPI get events");
    exit(1);
  }

  if (PAPI_add_event(EventSet, PAPI_event) != PAPI_OK) 
  {
     printf("\nError: can't add PAPI event");
     exit(1);
  }

  if ((retval = PAPI_start(EventSet)) != PAPI_OK)
  {
     printf("\nError: can't start PAPI");
     exit(1);
  }
}

void FOS_TIMER1(int* tmr1, int* select1)
{
  FILE* f;
  int tmr=0;
  int q=0;
  int select=0;

  if (first_run==0)
  {
    fos_timers_init();
    first_run=1;
  }
  
  tmr=*tmr1;

  //prediction
#ifdef debug
  sprintf(str, "_fos_out.%u.diag1", tmr);

  if ((f=fopen(str,"at"))==NULL)
  {
    printf("\nFatal Error (FATOM): Can't write file!\n");
    exit(1);
  }

  fprintf(f, "--------------------------------------------------------------------------------\n");
#endif

  int c1=Calls[tmr]+1;
  int found=0;
  Prediction[tmr]=-1;
  for (q=0; q<Queue[tmr]; q++)
  {
    int cmin1=Call1[tmr][q]+(Num[tmr][q]+1)*Period[tmr][q];
    int cmax1=cmin1+Length1[tmr][q];
    int cmin2=Call1[tmr][q]+(Num[tmr][q]+2)*Period[tmr][q];
    int cmax2=cmin2+Length1[tmr][q];
    int cmin3=Call1[tmr][q];
    int cmax3=cmin3+Length2[tmr][q]+1;

    if (((cmin1<=c1) && (c1<=cmax1)) ||
        ((cmin2<=c1) && (c1<=cmax2)) ||
        ((cmin3<=c1) && (c1<=cmax3)))
    {
      fprintf(f, "*** prediction for this call from queue %u ***\n", q);
      Prediction[tmr]=q;
      found=1;
      break;
    }
  }

  if (found==1)
  {
    if ((stability_wait<=HitSeq[tmr][q]) && 
        (HitSeq[tmr][q]<stability_wait+stability_transform))
    {
      select=Proc[tmr][q];
      if (Proc[tmr][q]>proc_max) select=Proc2[tmr][q]; //select the best procedure

      State[tmr][q]=1;
      if (HitSeq[tmr][q]==stability_wait+stability_transform-1)
      {
        State[tmr][q]=2;
        if (Proc[tmr][q]>proc_max) State[tmr][q]=4;
      }
      
      fprintf(f, "### New function (%u) ###\n", select);
    }
    else if ((stability_wait+stability_transform<=HitSeq[tmr][q]) && 
             (HitSeq[tmr][q]<stability_wait+stability_transform+stability_check))
    {
      State[tmr][q]=1;
      select=0;
      if (Proc[tmr][q]>proc_max) select=Proc2[tmr][q]; //select the best procedure

      fprintf(f, "### Stability for new function ###\n");
      if (HitSeq[tmr][q]==stability_wait+stability_transform+stability_check-1)
      {
        HitSeq[tmr][q]=stability_wait-1;    //as a pipeline if all hits
        HitSeqTr[tmr][q]++;
        State[tmr][q]=3;
        if (Proc[tmr][q]>proc_max) State[tmr][q]=4;
      }
    }
  }

#ifdef debug
  fclose(f);
#endif

  //get current time & instructions
  if ((retval = PAPI_read(EventSet,&values)) != PAPI_OK)
  {
     printf("\nError: can't read PAPI event");
     exit(1);
  }

  Timers1[tmr]=(double) PAPI_get_real_usec()/CLOCKS_PER_SEC;
  Timers2[tmr]=(double) values;

  Calls[tmr]++;

  *select1=select;
}

void FOS_TIMER2(int* tmr1)
{
  int q=0;
  FILE* f;
  FILE* f1;
  FILE* f2;
  int c1=0;

  double t=0;
  double i=0;
  double ipc=0;

  int tmr=*tmr1;

  if ((retval = PAPI_read(EventSet,&values)) != PAPI_OK)
  {
    printf("\nError: can't read PAPI event");
    exit(1);
  }

  t=(double) PAPI_get_real_usec()/CLOCKS_PER_SEC - Timers1[tmr];
  i=(double) values - Timers2[tmr];
  ipc=i/(t*FREQUENCY);

#ifdef debug
  sprintf(str, "_fos_out.%u.diag1", tmr);

  if ((f=fopen(str,"at"))==NULL)
  {
    printf("\nFatal Error (FATOM): Can't write file!\n");
    exit(1);
  }

  sprintf(str, "_fos_out.%u.diag2", tmr);

  if ((f1=fopen(str,"at"))==NULL)
  {
    printf("\nFatal Error (FATOM): Can't write file!\n");
    exit(1);
  }

  //write down current time
  fprintf(f, "timer={%8u}, call={%8u}, time={%5.3f}, instr={%5.3f}, ipc={%f}\n", 
              tmr, Calls[tmr], t, i, ipc);

  fprintf(f1, "timer={%8u}, call={%8u}, time={%5.3f}, instr={%5.3f}, ipc={%f}", 
              tmr, Calls[tmr], t, i, ipc);
#endif     

  //if prediction
  q=Prediction[tmr];
  if (q!=-1)
  {
#ifdef debug
    if (State[tmr][q]>0) fprintf(f1, " #################");
#endif     

    //if State!=0, i.e. during new function check
    if (State[tmr][q]==1)
    {
      //replace ipc and t with old one
      t=TIME[tmr][q];
      ipc=IPC[tmr][q];
    }
    else if (State[tmr][q]==2)
    {
      //write down time for later check
      TIME1[tmr][q]=t;
      IPC1[tmr][q]=ipc;
      //replace ipc and t with old one
      t=TIME[tmr][q];
      ipc=IPC[tmr][q];
    }
    else if (State[tmr][q]==4)
    {
      //when best transformation, check if still the same
      if (
         ((((IPC2[tmr][q]-precision_ipc)<=ipc) && (ipc<=(IPC2[tmr][q]+precision_ipc))) &&
          (((TIME2[tmr][q]-precision_time)<=t) && (t<=(TIME2[tmr][q]+precision_time))))
         )
      {      
        //replace ipc and t with old one
        t=TIME[tmr][q];
        ipc=IPC[tmr][q];
      }      
      else
      {
        //do not replace anything so that further code will detect phase change
      }
    }

    //check if prediction is correct
    if (
       ((((IPC[tmr][q]-precision_ipc)<=ipc) && (ipc<=(IPC[tmr][q]+precision_ipc))) &&
        (((TIME[tmr][q]-precision_time)<=t) && (t<=(TIME[tmr][q]+precision_time))))
       )
    {
      //predicted correctly
#ifdef debug
      fprintf(f,"*** HIT ***\n");
#endif
      Hit[tmr][q]++;        
      HitSeq[tmr][q]++;

      if (State[tmr][q]==3)
      {
        //still within phase after transformations
	//check the best time
#ifdef debug
        sprintf(str, "_fos_out.%u.diag3", tmr);

        if ((f2=fopen(str,"at"))==NULL)
        {
          printf("\nFatal Error (FATOM): Can't write file!\n");
          exit(1);
        }
						    
        fprintf(f2, "option={%8u}, time_transformed={%5.3f}, time_original={%5.3f}\n", 
        Proc[tmr][q], TIME1[tmr][q], TIME[tmr][q]);

        fclose(f2);
#endif 

        if (TIME1[tmr][q]+precision_time_best<TIME2[tmr][q])
        {
#ifdef debug
          fprintf(f,"*** TIME IS BETTER ***\n");
#endif 

          TIME2[tmr][q]=TIME1[tmr][q];
     	  IPC2[tmr][q]=IPC1[tmr][q];
	  Proc2[tmr][q]=Proc[tmr][q];
	}             

        Proc[tmr][q]++;
        State[tmr][q]=0;
      }
      else if (State[tmr][q]==4) State[tmr][q]=0;
    }
    else
    {
#ifdef debug
      fprintf(f,"*** MISS ***\n");
#endif
      Miss[tmr][q]++;
      HitSeq[tmr][q]=0;

      if ((State[tmr][q]==3) || (State[tmr][q]==4))
      {
        State[tmr][q]=0; //restart transformations when detect phase again
      }
    }
  }

#ifdef debug
  fprintf(f1, "\n");
#endif     
  
  //detect phases
  if (t>threshold_time)
  {
    //[TODO] if calls>calls_threshold clean the table (unused items (LRU?))
    //...

    int found=0;
    for (q=0; q<Queue[tmr]; q++)
    {
      if (((IPC[tmr][q]-precision_ipc)<=ipc) && (ipc<=(IPC[tmr][q]+precision_ipc)))
      {
        if (((TIME[tmr][q]-precision_time)<=t) && (t<=(TIME[tmr][q]+precision_time)))
        {
          found=1;
          break;
        }
      }
    }

    if (found==0)
    {
      int q=Queue[tmr];
      
      if (q>queue_max)
      {
//find where to put if full
        Queue[tmr]=queue_max;
        q=queue_max;
      }

      TIME[tmr][q]=t;
      IPC[tmr][q]=ipc;
      Call1[tmr][q]=Calls[tmr];
      Call2[tmr][q]=Calls[tmr];
      Num[tmr][q]=0;
      Period[tmr][q]=0;
      Length1[tmr][q]=0;
      Length2[tmr][q]=0;
      State[tmr][q]=0;
      Proc[tmr][q]=1;
      TIME1[tmr][q]=t;   //best time to check
      IPC1[tmr][q]=ipc;  //best ipc to check
      TIME2[tmr][q]=t;   //best time checked
      IPC2[tmr][q]=ipc;  //best ipc checked
      Proc2[tmr][q]=0; 
      Test[tmr][q]=0;
      Hit[tmr][q]=0;
      Miss[tmr][q]=0;
      HitSeq[tmr][q]=0;
      HitSeqTr[tmr][q]=0;
      
      Queue[tmr]++;
    }
    else
    {
      int period=Calls[tmr]-Call1[tmr][q];
      int period2=Calls[tmr]-Call2[tmr][q];
      
      if (Period[tmr][q]==0)
      {
        //no period yet
        if (period2==1)
        {
          Length1[tmr][q]++;
          Length2[tmr][q]++;
        }
        else
        {
          Period[tmr][q]=period;
          Length2[tmr][q]=0;
        }
      }
      else
      {
        if (period2==1)
        {
          Length2[tmr][q]++;
        }
        else
        {
          //check period & length
	  c1=Call1[tmr][q]+(Num[tmr][q]+1)*Period[tmr][q];
          if (Calls[tmr]==(c1+Period[tmr][q]))
  	  {
            //if length is not the same, set smaller length
            if (Length1[tmr][q]!=Length2[tmr][q])
            {
              int l=Length1[tmr][q];
              if ((l==0) || (l>Length2[tmr][q])) l=Length2[tmr][q];
              Length1[tmr][q]=l;
            }
            Num[tmr][q]++;        
            Length2[tmr][q]=0;
	  }
	  else
	  {
            //period changed
#ifdef debug
            fprintf(f, "*** period changed in timer2 routine ... ***\n");
#endif
            Period[tmr][q]=Calls[tmr]-c1;
            Length1[tmr][q]=0;

            Call1[tmr][q]=c1;

            Num[tmr][q]=0;
	    
	    HitSeq[tmr][q]=0;
	  }

          Length2[tmr][q]=0;
        }
      }

      Call2[tmr][q]=Calls[tmr];
    }

    //print period buffer debug info
#ifdef debug
    for (q=0; q<Queue[tmr]; q++)
    {
      fprintf(f, "****** buffer={%4u}, time={%5.3f}, ipc={%5.3f}, proc={%4u}, ",
                 q, TIME[tmr][q], IPC[tmr][q], Proc[tmr][q]);
      fprintf(f, "best_proc={%4u}, best_time={%5.3f}, best_ipc={%5.3f}, ",
                 Proc2[tmr][q], TIME2[tmr][q], IPC2[tmr][q]);
      fprintf(f, "hits={%6u}, misses={%6u}, ",
		 Hit[tmr][q], Miss[tmr][q]);
      fprintf(f, "hits_in_sequence={%6u}, potential_transformations={%6u}, ",
                 HitSeq[tmr][q], HitSeqTr[tmr][q]);
      fprintf(f, "call1={%4u}, call2={%4u}, period={%4u}, num={%4u}, ", 
                  Call1[tmr][q], Call2[tmr][q], Period[tmr][q], Num[tmr][q]);
      fprintf(f, "length1={%u}, length2={%u}\n", 
                 Length1[tmr][q], Length2[tmr][q]);
    }
#endif
  }

  fprintf(f, "--------------------------------------------------------------------------------\n");

#ifdef debug
  fclose(f);
  fclose(f1);
#endif
}

void fos_timer1(int tmr, int select)
{
  FOS_TIMER1(&tmr, &select);
}

void fos_timer2(int tmr)
{
  FOS_TIMER2(&tmr);
}

void fos_timer1_(int tmr, int select)
{
  FOS_TIMER1(&tmr, &select);
}

void fos_timer2_(int tmr)
{
  FOS_TIMER2(&tmr);
}

void fos_timer1__(int* tmr1, int* select1)
{
  FOS_TIMER1(tmr1, select1);
}

void fos_timer2__(int* tmr1)
{
  FOS_TIMER2(tmr1);
}

void _Z10fos_timer2i(int tmr, int select)
{
  FOS_TIMER1(&tmr, &select);
}

void _Z10fos_timer1i(int tmr)
{
  FOS_TIMER2(&tmr);
}
