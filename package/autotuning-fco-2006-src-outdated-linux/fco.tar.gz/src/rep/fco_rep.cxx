/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "futils.h"
#include "fids.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fic          "_finfo_iter"        //current iteration
#define _fic_rep      ".report.txt"        //file with report
#define _fic_reps     ".report_short.txt"  //file with report (short)
#define _fic_repc     ".report.c"          //compilation time
#define _fic_repe     ".report.e"          //execution time
#define _fic_repext   ".dat"               //data file extension
#define _fic_cur      ".cur"               //extension for current iteration
#define _fic_db       ".fdb"               //extension for transformation database
#define _fic_tim      ".time"              //extension for time (run)
#define _fic_timc     ".timec"             //extension for time (compilation)
#define _fic_inf      ".info"              //extension for info
#define _fic_tri1     ".tr_i1"             //extension for transformation info
#define _fic_tri2     ".tr_i2"             //extension for transformation info

#define _ftime_threshold 0.5       //Problems with execution

#define sep "********************************************************************************"

#define mode_ign 1                 //1 - don't compare time if output is different

char str1[1024];
char str2[1024];
char str3[1024];
char str4[1024];
char str5[1024];

int main(int argc, char* argv[])
{
  FILE* fin=NULL;
  FILE* fin1=NULL;

  printf("FCO Report\n");

  printf("\n");
  printf("Reading iteration 0 for further comparison ...\n");

  double t1r=0;
  double t2r=0;
  double ttr=0;
  double t1c=0;
  double t2c=0;
  double ttc=0;

  double t01r=0;
  double t02r=0;
  double t0tr=0;
  double t01c=0;
  double t02c=0;
  double t0tc=0;

  double tx1r=0;
  double tx2r=0;
  double txtr=0;
  double tx1c=0;
  double tx2c=0;
  double txtc=0;

  sprintf(str1, _fic ".%06u" _fic_tim, 0);
  t1r=getTime1(str1);
  t2r=getTime2(str1);
  ttr=t1r+t2r;

  sprintf(str1, _fic ".%06u" _fic_timc, 0);
  t1c=getTime1(str1);
  t2c=getTime2(str1);
  ttc=t1c+t2c;

  cleanFile(_fic _fic_rep);
  cleanFile(_fic _fic_reps);
  cleanFile(_fic _fic_repc _fic_repext);
  cleanFile(_fic _fic_repe _fic_repext);

  //clear files for each transformation
  cleanFile(_fic _fic_repc "." id_tr_pf _fic_repext);
  cleanFile(_fic _fic_repc "." id_tr_snl _fic_repext);
  cleanFile(_fic _fic_repc "." id_tr_simd _fic_repext);
  cleanFile(_fic _fic_repc "." id_tr_unroll _fic_repext);
  cleanFile(_fic _fic_repc "." id_tr_ff _fic_repext);
  cleanFile(_fic _fic_repc "." id_tr_inline _fic_repext);
  cleanFile(_fic _fic_repc "." id_tr_pad_local _fic_repext);
  cleanFile(_fic _fic_repc "." id_tr_pad_global _fic_repext);
  cleanFile(_fic _fic_repc "." id_tr_manual _fic_repext);

  cleanFile(_fic _fic_repe "." id_tr_pf _fic_repext);
  cleanFile(_fic _fic_repe "." id_tr_snl _fic_repext);
  cleanFile(_fic _fic_repe "." id_tr_simd _fic_repext);
  cleanFile(_fic _fic_repe "." id_tr_unroll _fic_repext);
  cleanFile(_fic _fic_repe "." id_tr_ff _fic_repext);
  cleanFile(_fic _fic_repe "." id_tr_inline _fic_repext);
  cleanFile(_fic _fic_repe "." id_tr_pad_local _fic_repext);
  cleanFile(_fic _fic_repe "." id_tr_pad_global _fic_repext);
  cleanFile(_fic _fic_repe "." id_tr_manual _fic_repext);

  appendOut(_fic _fic_rep, sep);
  appendOut(_fic _fic_rep, "FCO Report:");
  appendOut(_fic _fic_rep, "");
  sprintf(str1, "Iteration = {%06u}", 0);
  appendOut(_fic _fic_rep, str1);
  appendOut(_fic _fic_rep, "");
  sprintf(str1, "EXE: total={%6.1f}, user={%6.1f}, sys={%6.1f}; COMP: total={%6.1f}, user={%6.1f}, sys={%6.1f}; compilation:", ttr, t1r, t2r, ttc, t1c, t2c);
  appendOut(_fic _fic_rep, str1);
  
  sprintf(str1, "%.1f", ttr);
  appendOut(_fic _fic_repe _fic_repext, str1);
  appendOut(_fic _fic_repe "." id_tr_pf _fic_repext, str1);
  appendOut(_fic _fic_repe "." id_tr_snl _fic_repext, str1);
  appendOut(_fic _fic_repe "." id_tr_simd _fic_repext, str1);
  appendOut(_fic _fic_repe "." id_tr_unroll _fic_repext, str1);
  appendOut(_fic _fic_repe "." id_tr_ff _fic_repext, str1);
  appendOut(_fic _fic_repe "." id_tr_inline _fic_repext, str1);
  appendOut(_fic _fic_repe "." id_tr_pad_local _fic_repext, str1);
  appendOut(_fic _fic_repe "." id_tr_pad_global _fic_repext, str1);
  appendOut(_fic _fic_repe "." id_tr_manual _fic_repext, str1);

  sprintf(str1, "%.1f", ttc);
  appendOut(_fic _fic_repc _fic_repext, str1);
  appendOut(_fic _fic_repc "." id_tr_pf _fic_repext, str1);
  appendOut(_fic _fic_repc "." id_tr_snl _fic_repext, str1);
  appendOut(_fic _fic_repc "." id_tr_simd _fic_repext, str1);
  appendOut(_fic _fic_repc "." id_tr_unroll _fic_repext, str1);
  appendOut(_fic _fic_repc "." id_tr_ff _fic_repext, str1);
  appendOut(_fic _fic_repc "." id_tr_inline _fic_repext, str1);
  appendOut(_fic _fic_repc "." id_tr_pad_local _fic_repext, str1);
  appendOut(_fic _fic_repc "." id_tr_pad_global _fic_repext, str1);
  appendOut(_fic _fic_repc "." id_tr_manual _fic_repext, str1);

  double ttrmin=ttr;
  double ttrmax=ttr;
  double ttcmin=ttc;
  double ttcmax=ttc;

  long iter=1;
  int iter0=0;
  int finish=0;
  int found=0;
  int infl=0;

  long ibetter=0;
  double imprbetter=0;

  while (finish==0)
  {
    printf("Adding iteration %u ...\n", iter);

    sprintf(str1, _fic ".%06u" _fic_inf, iter);
    if ((fin=fopen(str1, "r"))==NULL) finish=1;
    else
    {
      //read transformation type
      sprintf(str1, _fic ".%06u" _fic_tri2, iter);
      initReadTR(str1);
      
      //maybe should do a loop if there are sequences
      //of transformations in one file (for the future versions)
      found=findNextTR();

      found=findLineFromCurrentTR(id1_better, str2);
      int better=atoi(str2);
      if (found==1 && better==1) ibetter=iter;

      found=findLineFromCurrentTR(id1_infl, str2);
      int infl=atoi(str2);

      found=findLineFromCurrentTR(id1_tr, str2);

      sprintf(str3, _fic ".%06u" _fic_tri1, iter);
      if (findLineFromCurrentTransformationY(id1_in, str4, str3)==0)
      {
        printf("Error: can't find string %s in file %s", id1_in, str3);
	exit(1);
      }

      iter0=atoi(str4);

      sprintf(str1, _fic ".%06u" _fic_tim, iter0);
      t01r=getTime1(str1);
      t02r=getTime2(str1);
      t0tr=t01r+t02r;

      sprintf(str1, _fic ".%06u" _fic_timc, iter0);
      t01c=getTime1(str1);
      t02c=getTime2(str1);
      t0tc=t01c+t02c;

      appendOut(_fic _fic_rep, sep);
      sprintf(str1, "Iteration = {%06u} based on {%06u}", iter, iter0);
      appendOut(_fic _fic_rep, str1);

      sprintf(str5, "%06u <- %06u) %26s", iter, iter0, str2);

      sprintf(str1, _fic ".%06u" _fic_tri2, iter);

      if ((fin1=fopen(str1, "r"))==NULL) finish=1;
      else
      {
        while ((fgets(str1, 1023, fin1)!=NULL) && (feof(fin1)==0))
        {
          fparse1(str1);

          appendOut(_fic _fic_rep, str1);
        }
        fclose(fin1);
        appendOut(_fic _fic_rep, "");
      }      

      int inf1=0;
      int inf2=0;
      int inf3=0;
      
      fgets(str1, 1023, fin);
      inf1=atoi(str1);
      fgets(str1, 1023, fin);
      inf2=atoi(str1);
      fgets(str1, 1023, fin);
      inf3=atoi(str1);
      
      fclose(fin);

      if ((inf1==0) || ((mode_ign==1) && (inf1==1) && (inf3==0)))
      {
        appendOut(_fic _fic_rep, "executable =          {0}, not created");

        sprintf(str1, "%.f", 0);
        appendOut(_fic _fic_repe _fic_repext, str1);
        sprintf(str1, "%.f", 0);
        appendOut(_fic _fic_repc _fic_repext, str1);

        appendOut(_fic _fic_repe "." id_tr_pf _fic_repext, "0");
        appendOut(_fic _fic_repc "." id_tr_pf _fic_repext, "0");
        appendOut(_fic _fic_repe "." id_tr_snl _fic_repext, "0");
        appendOut(_fic _fic_repc "." id_tr_snl _fic_repext, "0");
        appendOut(_fic _fic_repe "." id_tr_simd _fic_repext, "0");
        appendOut(_fic _fic_repc "." id_tr_simd _fic_repext, "0");
        appendOut(_fic _fic_repe "." id_tr_unroll _fic_repext, "0");
        appendOut(_fic _fic_repc "." id_tr_unroll _fic_repext, "0");
        appendOut(_fic _fic_repe "." id_tr_ff _fic_repext, "0");
        appendOut(_fic _fic_repc "." id_tr_ff _fic_repext, "0");
        appendOut(_fic _fic_repe "." id_tr_inline _fic_repext, "0");
        appendOut(_fic _fic_repc "." id_tr_inline _fic_repext, "0");
        appendOut(_fic _fic_repe "." id_tr_pad_local _fic_repext, "0");
        appendOut(_fic _fic_repc "." id_tr_pad_local _fic_repext, "0");
        appendOut(_fic _fic_repe "." id_tr_pad_global _fic_repext, "0");
        appendOut(_fic _fic_repc "." id_tr_pad_global _fic_repext, "0");
        appendOut(_fic _fic_repe "." id_tr_manual _fic_repext, "0");
        appendOut(_fic _fic_repc "." id_tr_manual _fic_repext, "0");

        sprintf(str3, _fic _fic_repe ".%s" _fic_repext, str2);
	sprintf(str1, "%.1f", 0);
        appendOut(str3, str1);
        sprintf(str3, _fic _fic_repc ".%s" _fic_repext, str2);
	sprintf(str1, "%.1f", 0);
        appendOut(str3, str1);
      }
      else
      {
        appendOut(_fic _fic_rep, "executable =          {1}, ok");

        if (inf2==0) appendOut(_fic _fic_rep, "time is not too low = {0}, too low");
	else appendOut(_fic _fic_rep, "time is not too low = {1}, ok");

        if (inf3==0) appendOut(_fic _fic_rep, "output is correct   = {0}, potential problem");
	else appendOut(_fic _fic_rep, "output is correct   = {1}, ok");
	
        sprintf(str1, _fic ".%06u" _fic_tim, iter);
        tx1r=getTime1(str1);
        tx2r=getTime2(str1);
        txtr=tx1r+tx2r;

        double impr=((t0tr-txtr)/t0tr)*100;
        double impr1=((ttr-txtr)/ttr)*100;

        if (better==1) imprbetter=impr1;

        sprintf(str1, " %6.1f s <- %6.1f s = %5.1f%% (%5.1f%%)", txtr, t0tr, impr, impr1);
	strcat(str5, str1);

        sprintf(str1, _fic ".%06u" _fic_timc, iter);
        tx1c=getTime1(str1);
        tx2c=getTime2(str1);
        txtc=tx1c+tx2c;

        appendOut(_fic _fic_rep, "");
        sprintf(str1, "EXE: total={%6.1f}, user={%6.1f}, sys={%6.1f}; COMP: total={%6.1f}, user={%6.1f}, sys={%6.1f}; compilation:", txtr, tx1r, tx2r, txtc, tx1c, tx2c);
        appendOut(_fic _fic_rep, str1);

        sprintf(str1, "%.1f", txtr);
        appendOut(_fic _fic_repe _fic_repext, str1);
        sprintf(str1, "%.1f", txtc);
        appendOut(_fic _fic_repc _fic_repext, str1);

        if (strcmp(str2, id_tr_pf)==0)
	{
          sprintf(str1, "%.1f", txtr);
          appendOut(_fic _fic_repe "." id_tr_pf _fic_repext, str1);
          sprintf(str1, "%.1f", txtc);
          appendOut(_fic _fic_repc "." id_tr_pf _fic_repext, str1);
	}
        else
	{
          appendOut(_fic _fic_repe "." id_tr_pf _fic_repext, "0");
          appendOut(_fic _fic_repc "." id_tr_pf _fic_repext, "0");
	}
        if (strcmp(str2, id_tr_snl)==0)
	{
          sprintf(str1, "%.1f", txtr);
          appendOut(_fic _fic_repe "." id_tr_snl _fic_repext, str1);
          sprintf(str1, "%.1f", txtc);
          appendOut(_fic _fic_repc "." id_tr_snl _fic_repext, str1);
	}
        else
	{
          appendOut(_fic _fic_repe "." id_tr_snl _fic_repext, "0");
          appendOut(_fic _fic_repc "." id_tr_snl _fic_repext, "0");
	}
        if (strcmp(str2, id_tr_simd)==0)
	{
          sprintf(str1, "%.1f", txtr);
          appendOut(_fic _fic_repe "." id_tr_simd _fic_repext, str1);
          sprintf(str1, "%.1f", txtc);
          appendOut(_fic _fic_repc "." id_tr_simd _fic_repext, str1);
	}
        else
	{
          appendOut(_fic _fic_repe "." id_tr_simd _fic_repext, "0");
          appendOut(_fic _fic_repc "." id_tr_simd _fic_repext, "0");
	}
        if (strcmp(str2, id_tr_unroll)==0)
	{
          sprintf(str1, "%.1f", txtr);
          appendOut(_fic _fic_repe "." id_tr_unroll _fic_repext, str1);
          sprintf(str1, "%.1f", txtc);
          appendOut(_fic _fic_repc "." id_tr_unroll _fic_repext, str1);
	}
        else
	{
          appendOut(_fic _fic_repe "." id_tr_unroll _fic_repext, "0");
          appendOut(_fic _fic_repc "." id_tr_unroll _fic_repext, "0");
	}
        if (strcmp(str2, id_tr_ff)==0)
	{
          sprintf(str1, "%.1f", txtr);
          appendOut(_fic _fic_repe "." id_tr_ff _fic_repext, str1);
          sprintf(str1, "%.1f", txtc);
          appendOut(_fic _fic_repc "." id_tr_ff _fic_repext, str1);
	}
        else
	{
          appendOut(_fic _fic_repe "." id_tr_ff _fic_repext, "0");
          appendOut(_fic _fic_repc "." id_tr_ff _fic_repext, "0");
	}
        if (strcmp(str2, id_tr_inline)==0)
	{
          sprintf(str1, "%.1f", txtr);
          appendOut(_fic _fic_repe "." id_tr_inline _fic_repext, str1);
          sprintf(str1, "%.1f", txtc);
          appendOut(_fic _fic_repc "." id_tr_inline _fic_repext, str1);
	}
        else
	{
          appendOut(_fic _fic_repe "." id_tr_inline _fic_repext, "0");
          appendOut(_fic _fic_repc "." id_tr_inline _fic_repext, "0");
	}
        if (strcmp(str2, id_tr_pad_local)==0)
	{
          sprintf(str1, "%.1f", txtr);
          appendOut(_fic _fic_repe "." id_tr_pad_local _fic_repext, str1);
          sprintf(str1, "%.1f", txtc);
          appendOut(_fic _fic_repc "." id_tr_pad_local _fic_repext, str1);
	}
        else
	{
          appendOut(_fic _fic_repe "." id_tr_pad_local _fic_repext, "0");
          appendOut(_fic _fic_repc "." id_tr_pad_local _fic_repext, "0");
	}
        if (strcmp(str2, id_tr_pad_global)==0)
	{
          sprintf(str1, "%.1f", txtr);
          appendOut(_fic _fic_repe "." id_tr_pad_global _fic_repext, str1);
          sprintf(str1, "%.1f", txtc);
          appendOut(_fic _fic_repc "." id_tr_pad_global _fic_repext, str1);
	}
        else
	{
          appendOut(_fic _fic_repe "." id_tr_pad_global _fic_repext, "0");
          appendOut(_fic _fic_repc "." id_tr_pad_global _fic_repext, "0");
	}
        if (strcmp(str2, id_tr_manual)==0)
	{
          sprintf(str1, "%.1f", txtr);
          appendOut(_fic _fic_repe "." id_tr_manual _fic_repext, str1);
          sprintf(str1, "%.1f", txtc);
          appendOut(_fic _fic_repc "." id_tr_manual _fic_repext, str1);
	}
        else
	{
          appendOut(_fic _fic_repe "." id_tr_manual _fic_repext, "0");
          appendOut(_fic _fic_repc "." id_tr_manual _fic_repext, "0");
	}

        appendOut(_fic _fic_rep, "");
        sprintf(str1, "performance change (relative) = %3.1f%%", impr);
        appendOut(_fic _fic_rep, str1);
        sprintf(str1, "performance change (overall)  = %3.1f%%", impr1);
        appendOut(_fic _fic_rep, str1);
      }

      if (better==1) strcat(str5, "  better!");
      else if (infl==1) strcat(str5, "  influential!");

      appendOut(_fic _fic_reps, str5);
    }
    iter++;
  }

  if (ibetter>0)
  {
    appendOut(_fic _fic_reps, "");
    sprintf(str5, "Last seen iteration with best performance = %u", ibetter);
    appendOut(_fic _fic_reps, str5);
    sprintf(str5, "Performance improvement                   = %3.1f%%", imprbetter);
    appendOut(_fic _fic_reps, str5);
  }
  
  printf("\nProgram finished!\n");
  
  return 0;
}
