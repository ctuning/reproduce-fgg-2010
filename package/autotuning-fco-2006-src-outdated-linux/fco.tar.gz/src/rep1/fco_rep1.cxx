/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "futils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fic          "_finfo_iter"        //current iteration
#define _fic_reps     ".report_short.txt"  //file with report (short)
#define _fic_repe     ".report.e"          //execution time
#define _fic_repext   ".dat"               //data file extension
#define _fic_cur      ".cur"               //extension for current iteration
#define _fic_db       ".fdb"               //extension for transformation database
#define _fic_tim      ".time"              //extension for time (run)
#define _fic_timc     ".timec"             //extension for time (compilation)
#define _fic_inf      ".info"              //extension for info
#define _fic_tri1     ".tr_i1"             //extension for transformation info
#define _fic_tri2     ".tr_i2"             //extension for transformation info
#define _fic_repc     ".report.c"          //compilation time
#define _fic_repe     ".report.e"          //execution time

#define _ftime_threshold 0.5       //Problems with execution

#define sep "********************************************************************************"

#define mode_ign 1                 //1 - don't compare time if output is different

char str1[1024];
char str2[1024];
char str3[1024];
char str4[1024];
char str5[1024];

int main(int argc, char* argv[])
{
  FILE* fin=NULL;
  FILE* fin1=NULL;

  printf("FCO GCC Report\n");

  printf("\n");
  printf("Reading iteration 0 for further comparison ...\n");

  double t1r=0;
  double t2r=0;
  double ttr=0;
  double t1c=0;
  double t2c=0;
  double ttc=0;

  double tx1r=0;
  double tx2r=0;
  double txtr=0;
  double tx1c=0;
  double tx2c=0;
  double txtc=0;

  sprintf(str1, _fic ".%06u" _fic_tim, 0);
  t1r=getTime1(str1);
  t2r=getTime2(str1);
  ttr=t1r+t2r;

  sprintf(str1, _fic ".%06u" _fic_timc, 0);
  t1c=getTime1(str1);
  t2c=getTime2(str1);
  ttc=t1c+t2c;

  cleanFile(_fic _fic_reps);
  cleanFile(_fic _fic_repe _fic_repext);
  cleanFile(_fic _fic_repc _fic_repext);

  sprintf(str1, "%.1f", ttr);
  appendOut(_fic _fic_repe _fic_repext, str1);

  sprintf(str1, "%.1f", ttc);
  appendOut(_fic _fic_repc _fic_repext, str1);

  long iter=1;
  long iterM=1;
  int finish=0;

  printf("\nDetecting number of iterations ...\n");
  while (finish==0)
  {
    sprintf(str1, _fic ".%06u" _fic_inf, iter);
    if ((fin=fopen(str1, "r"))==NULL) finish=1;
    iter++;
  }
  iterM=iter-1;

  double*  tr=(double*) malloc(sizeof(double)*iterM);
  double*  tc=(double*) malloc(sizeof(double)*iterM);
  long*    ti=(long*)   malloc(sizeof(long)  *iterM);

  tr[0]=ttr;
  tc[0]=ttc;
  ti[0]=0;

  printf("\n");
  finish=0;
  iter=1;
  while (finish==0)
  {
    printf("Reading iteration %u ...\n", iter);

    sprintf(str1, _fic ".%06u" _fic_inf, iter);
    if ((fin=fopen(str1, "r"))==NULL) finish=1;
    else
    {
      sprintf(str1, _fic ".%06u" _fic_tim, iter);
      tx1r=getTime1(str1);
      tx2r=getTime2(str1);
      txtr=tx1r+tx2r;

      sprintf(str1, "%.1f", txtr);
      appendOut(_fic _fic_repe _fic_repext, str1);

      sprintf(str1, _fic ".%06u" _fic_timc, iter);
      tx1c=getTime1(str1);
      tx2c=getTime2(str1);
      txtc=tx1c+tx2c;

      sprintf(str1, "%.1f", txtc);
      appendOut(_fic _fic_repc _fic_repext, str1);

      tr[iter]=txtr;
      tc[iter]=txtc;
      ti[iter]=iter;
    }
    iter++;
  }

  printf("\nSorting array ...\n");
  for (int i=0; i<iterM-1; i++)
  {
    for (int j=0; j<iterM-i-1; j++)
    {
      if (tr[j+1]<tr[j])
      {
        double tmp=tr[j];
	tr[j]=tr[j+1];
	tr[j+1]=tmp;

        tmp=tc[j];
	tc[j]=tc[j+1];
	tc[j+1]=tmp;

        long tmp1=ti[j];
	ti[j]=ti[j+1];
	ti[j+1]=tmp1;
      }
    }
  }
  
  printf("\nWriting array ...\n");
  for (int i=0; i<iterM; i++)
  {
    sprintf(str1, "%7.1f - %5u", tr[i], ti[i]);
    appendOut(_fic _fic_reps, str1);
  }

  printf("\nProgram finished!\n");
  
  return 0;
}
