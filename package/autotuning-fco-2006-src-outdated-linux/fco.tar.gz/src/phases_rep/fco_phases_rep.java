//
// "Fresh Optimizing Software"
//
// Copyright (C) 2000-2005 by Grigori G.Fursin
//
// http://homepages.inf.ed.ac.uk/gfursin
//
// INRIA Futurs (France) / University of Edinburgh (UK)
//

import java.io.*;

public class fco_phases_rep
{
  public static void main(String args[])
  {
    String fname="_finfo_phases.";
    String fdata=".a.dat";
    String fdatb=".b.dat";
    String feps=".eps";
    String fd2=".diag2";
    String fd3=".diag3";

    String str="";
    String str1="";

    int i1=0;
    int i2=0;

    boolean success=false;

    BufferedReader fin=null;
    BufferedWriter fouta=null;
    BufferedWriter foutb=null;

    for (int t=1; t<128; t++)
    {
      //trying to process diag2 file
      str=fname+String.valueOf(t)+fd2;

      System.out.print("Processing file "+str+": ");

      fin=null;

      success=true;
      try 
      {
        fin=new BufferedReader(new FileReader(str));
      }
      catch (IOException e1) 
      {
        success=false;
      }

      if (success)
      {
        try 
        {
          fouta=new BufferedWriter(new FileWriter(str+fdata));
          foutb=new BufferedWriter(new FileWriter(str+fdatb));
        }
        catch (IOException e1) 
        {
          System.out.println("");
          System.out.println("Error while opening file "+str+fdata+" ...");
          System.exit(1);
        }

        try
        {
          while ((str=fin.readLine())!=null)
          {
            i1=str.indexOf("time={");
            if (i1>=0)
            {
              i2=str.indexOf("}", i1+1);
              if (i2>=0)
              {
                str1=str.substring(i1+6,i2);

                double tim=0; try {tim=Double.valueOf(str1).doubleValue();}
                catch (NumberFormatException nfe1){}

                if (tim<0.03) str1="0.000";

                fouta.write(str1);
                fouta.newLine();

                i1=str.indexOf("ipc={");
                if (i1>=0)
                {
                  i2=str.indexOf("}", i1+1);
                  if (i2>=0)
                  {
                    str1=str.substring(i1+5,i2);

                    if (tim<0.03) str1="0.000000";

                    foutb.write(str1);
                    foutb.newLine();
                  }
                }
              }
            }
          }
        }
        catch (Exception e1)
        {
          try
          {
            fouta.close();
            foutb.close();
          }
          catch (Exception e2)
          {}
          System.out.println("");
          System.out.println("Error while processing file ...");
          System.exit(1);
        }

        try  
        {
          fouta.close();
          foutb.close();
        }
        catch (Exception e5)  
        {
          System.out.println("");
          System.out.println("Error while closing file ...");
          System.exit(1);
        }

        System.out.println("ok");
      }
      else
      {
        System.out.println("not found");
      }

      //trying to process diag3 file
      str=fname+String.valueOf(t)+fd3;

      System.out.print("Processing file "+str+": ");

      fin=null;

      success=true;
      try 
      {
        fin=new BufferedReader(new FileReader(str));
      }
      catch (IOException e1) 
      {
        success=false;
      }

      if (success)
      {
        try 
        {
          fouta=new BufferedWriter(new FileWriter(str+fdata));
          foutb=new BufferedWriter(new FileWriter(str+fdatb));
        }
        catch (IOException e1) 
        {
          System.out.println("");
          System.out.println("Error while opening file "+str+fdata+" ...");
          System.exit(1);
        }

        try
        {
          while ((str=fin.readLine())!=null)
          {
            i1=str.indexOf("time_transformed={");
            if (i1>=0)
            {
              i2=str.indexOf("}", i1+1);
              if (i2>=0)
              {
                str1=str.substring(i1+18,i2);
                fouta.write(str1);
                fouta.newLine();

                i1=str.indexOf("time_original={");
                if (i1>=0)
                {
                  i2=str.indexOf("}", i1+1);
                  if (i2>=0)
                  {
                    str1=str.substring(i1+15,i2);
                    foutb.write(str1);
                    foutb.newLine();
                  }
                }
              }
            }
          }
        }
        catch (Exception e1)
        {
          try
          {
            fouta.close();
            foutb.close();
          }
          catch (Exception e2)
          {}
          System.out.println("");
          System.out.println("Error while processing file ...");
          System.exit(1);
        }

        try  
        {
          fouta.close();
          foutb.close();
        }
        catch (Exception e5)  
        {
          System.out.println("");
          System.out.println("Error while closing file ...");
          System.exit(1);
        }

        System.out.println("ok");
      }
      else
      {
        System.out.println("not found");
      }
    }
  }
}
