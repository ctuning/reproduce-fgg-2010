//
// "Fresh Optimizing Software"
//
// Copyright (C) 2000-2005 by Grigori G.Fursin
//
// http://homepages.inf.ed.ac.uk/gfursin
//
// INRIA Futurs (France) / University of Edinburgh (UK)
//

import java.io.*;

public class fco_phases_repp_create_plot
{
  public static void main(String args[])
  {
    String fname="_finfo_phases.";
    String fname1="fco_phases_repp.plot";
    String fdata=".a.dat";
    String fdatb=".b.dat";
    String feps=".eps";
    String fd2=".diag2";
    String fd3=".diag3";

    String str="";

    boolean success=false;

    BufferedReader fin=null;
    BufferedWriter fout=null;

    try 
    {
      fout=new BufferedWriter(new FileWriter(fname1));
    }
    catch (IOException e1) 
    {
      System.out.println("");
      System.out.println("Error while opening file "+fname1+" ...");
      System.exit(1);
    }

    try
    {
      fout.write("set terminal postscript eps color"); fout.newLine();
      fout.write(""); fout.newLine();
      fout.write("set xlabel \"calls\""); fout.newLine();
      fout.write(""); fout.newLine();
    }
    catch (Exception e3)  
    {
      try  
      {
        fout.close();
      }
      catch (Exception e4)  {}
      System.out.println("");
      System.out.println("Error while processing file ...");
      System.exit(1);
    }

    for (int t=1; t<128; t++)
    {
      //trying to process diag2 file
      str=fname+String.valueOf(t)+fd2;

      System.out.print("Processing file "+str+": ");

      fin=null;

      success=true;
      try 
      {
        fin=new BufferedReader(new FileReader(str));
      }
      catch (IOException e1) 
      {
        success=false;
      }

      if (success)
      {
        try
        {
          fout.write("set output \"_finfo_phases."+String.valueOf(t)+".diag2.a.dat.eps\""); fout.newLine();
          fout.write("set title \"execution time for each call\""); fout.newLine();
          fout.write("set ylabel \"execution time (s.)\""); fout.newLine();
          fout.write("set boxwidth 0.5"); fout.newLine();
          fout.write("set xrange [0:]"); fout.newLine();
          fout.write("plot \"_finfo_phases."+String.valueOf(t)+".diag2.a.dat\" notitle with boxes"); fout.newLine();
          fout.write(""); fout.newLine();

          fout.write("set output \"_finfo_phases."+String.valueOf(t)+".diag2.b.dat.eps\""); fout.newLine();
          fout.write("set title \"IPC for each call\""); fout.newLine();
          fout.write("set ylabel \"execution time (s.)\""); fout.newLine();
          fout.write("set boxwidth 0.5"); fout.newLine();
          fout.write("set xrange [0:]"); fout.newLine();
          fout.write("plot \"_finfo_phases."+String.valueOf(t)+".diag2.b.dat\" notitle with boxes"); fout.newLine();
          fout.write(""); fout.newLine();
        }
        catch (Exception e3)  
        {
          try  
          {
            fout.close();
          }
          catch (Exception e4)  {}
          System.out.println("");
          System.out.println("Error while processing file ...");
          System.exit(1);
        }

        System.out.println("ok");
      }
      else
      {
        System.out.println("not found");
      }
    }

    try
    {
      fout.write("set terminal postscript eps color"); fout.newLine();
      fout.write(""); fout.newLine();
      fout.write("set xlabel \"versions\""); fout.newLine();
      fout.write(""); fout.newLine();
    }
    catch (Exception e3)  
    {
      try  
      {
        fout.close();
      }
      catch (Exception e4)  {}
      System.out.println("");
      System.out.println("Error while processing file ...");
      System.exit(1);
    }

    for (int t=1; t<128; t++)
    {
      //trying to process diag3 file
      str=fname+String.valueOf(t)+fd3;

      System.out.print("Processing file "+str+": ");

      fin=null;

      success=true;
      try 
      {
        fin=new BufferedReader(new FileReader(str));
      }
      catch (IOException e1) 
      {
        success=false;
      }

      if (success)
      {
        try
        {
          fout.write("set output \"_finfo_phases."+String.valueOf(t)+".diag3.a.dat.eps\""); fout.newLine();
          fout.write("set title \"execution time for each call\""); fout.newLine();
          fout.write("set ylabel \"execution time (s.)\""); fout.newLine();
          fout.write("set boxwidth 0.5"); fout.newLine();
          fout.write("set xrange [0:]"); fout.newLine();
          fout.write("plot \"_finfo_phases."+String.valueOf(t)+".diag3.a.dat\" notitle with boxes"); fout.newLine();
          fout.write(""); fout.newLine();

          fout.write("set output \"_finfo_phases."+String.valueOf(t)+".diag3.b.dat.eps\""); fout.newLine();
          fout.write("set title \"execution time for each call\""); fout.newLine();
          fout.write("set ylabel \"execution time (s.)\""); fout.newLine();
          fout.write("set boxwidth 0.5"); fout.newLine();
          fout.write("set xrange [0:]"); fout.newLine();
          fout.write("plot \"_finfo_phases."+String.valueOf(t)+".diag3.b.dat\" notitle with boxes"); fout.newLine();
          fout.write(""); fout.newLine();
        }
        catch (Exception e3)  
        {
          try  
          {
            fout.close();
          }
          catch (Exception e4)  {}
          System.out.println("");
          System.out.println("Error while processing file ...");
          System.exit(1);
        }

        System.out.println("ok");
      }
      else
      {
        System.out.println("not found");
      }
    }

    try  
    {
      fout.close();
    }
    catch (Exception e5)  
    {
      System.out.println("");
      System.out.println("Error while closing file ...");
      System.exit(1);
    }
  }
}
