/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include <papi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define _fp        "_finfo_papi"
#define _fp1       "_finfo_papi.out"
#define _frun      "_fbrun"           //run batch file

char str1[1024];  //Not very clean, should change when have time
char str2[1024];

void fparse1(char* str);

int main(int argc, char* argv[])
{
  FILE* ff;
  FILE* ff1;

  int retval, i;
  int EventSet=PAPI_NULL, count = 0;
  long_long values1;
  long_long values2;
  PAPI_event_info_t info;
  long event;

  printf("FCO PAPI check\n");

  retval = PAPI_library_init(PAPI_VER_CURRENT);
  if (retval != PAPI_VER_CURRENT)
  {
    printf("Error: PAPI_library_init\n");
    exit(1);
  }

  retval = PAPI_create_eventset(&EventSet);
  if (retval != PAPI_OK)
  {
    printf("Error: PAPI_create_eventset\n");
    exit(1);
  } 
 
  if ((ff=fopen(_fp, "r"))==NULL)
  {
    printf("ERROR: Can't open file with PAPI events...\n");
    exit(1);
  }

  if ((ff1=fopen(_fp1, "w"))==NULL)
  {
    printf("ERROR: Can't open file to write PAPI events...\n");
    exit(1);
  }

  while (feof(ff)==0)
  {
    if (fgets(str1, 1024, ff)!=NULL)
    {
      if (fgets(str2, 1024, ff)!=NULL)
      {
        fparse1(str2);
        event=atol(str1);
        printf("Checking event %s (%d) ...\n", str2, event);

        if (PAPI_add_event(EventSet, event) != PAPI_OK) 
        {
          printf("\nError: can't add PAPI event");
          exit(1);
       }

       if ((retval = PAPI_start(EventSet)) != PAPI_OK)
       {
          printf("\nError: can't start PAPI");
          exit(1);
       }

       if ((retval = PAPI_read(EventSet, &values1)) != PAPI_OK)
       {
          printf("\nError: can't read PAPI event");
          exit(1);
       }

       //call program
       system(_frun);

       if ((retval = PAPI_read(EventSet, &values2)) != PAPI_OK)
       {
          printf("\nError: can't read PAPI event");
          exit(1);
       }

       printf("Collected value %15s = %15lld\n", str2, values2-values1);
       fprintf(ff1, "%15s = %15lld\n", str2, values2-values1);

       retval = PAPI_stop(EventSet,NULL);
       retval = PAPI_remove_event(EventSet, event);
      }
    }
  }
  
  retval = PAPI_cleanup_eventset(EventSet);

  fclose(ff1);
  fclose(ff);
}

void fparse1(char* str)
{
  int i=strlen(str);
  if (i>0)
  {
    int found=0;
    for (int j=0; (j<i) && (found==0); j++)
    {
      if (str[j]=='\r' || str[j]=='\n')
      {
        str[j]=0;
	found=1;
      }
    }
  }
}
