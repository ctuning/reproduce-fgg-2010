/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fp        "_finfo_papi"
#define _fp1       "_finfo_papi.out"

#define _fcmd      "_finfo_cmd_run"

#define _ftmp1      "ftmp_papi1.tmp"
#define _ftmp2      "ftmp_papi2.tmp"

char str1[1024];  //Not very clean, should change when have time
char str2[1024];
char str3[1024];
char cmd[1024];

void fparse1(char* str);

int main(int argc, char* argv[])
{
  FILE* ff;
  FILE* ff1;
  FILE* ff2;
  FILE* ff3;
  FILE* ff4;

  printf("FCO PAPI check all events\n");

  if ((ff=fopen(_fp, "r"))==NULL)
  {
    printf("ERROR: Can't open file with PAPI events...\n");
    exit(1);
  }

  if ((ff2=fopen(_fcmd, "r"))==NULL)
  {
    printf("ERROR: Can't open file with CMD...\n");
    exit(1);
  }
  
  strcpy(cmd, "");
  if (fgets(cmd, 1024, ff2)!=NULL)
  {
    fparse1(cmd);
  }
  fclose(ff2);

  if ((ff1=fopen(_fp1, "w"))==NULL)
  {
    printf("ERROR: Can't open file to write PAPI events...\n");
    exit(1);
  }

  while (feof(ff)==0)
  {
    if (fgets(str1, 1024, ff)!=NULL)
    {
      fparse1(str1);
      printf("Checking event %s ...\n", str1);

      strcpy(str2, "papiex -e ");
      strcat(str2, str1);
      strcat(str2, " -q -F " _ftmp2 " a.out ");
      strcat(str2, cmd);

      if ((ff3=fopen(_ftmp1, "w"))==NULL)
      {
        printf("ERROR: Can't open file to write tmp CMD ...\n");
        exit(1);
      }

      fprintf(ff3, "%s\n", str2);
      fclose(ff3);

      remove(_ftmp2);

      system("chmod 755 " _ftmp1);
      system(_ftmp1);

      strcpy(str3, "");
      if ((ff4=fopen(_ftmp2, "r"))!=NULL)
      {
        if (fgets(str2, 1024, ff4)!=NULL)
        {
          if (fgets(str2, 1024, ff4)!=NULL)
          {
            if (fgets(str2, 1024, ff4)!=NULL)
            {
              if (fgets(str2, 1024, ff4)!=NULL)
              {
                if (fgets(str2, 1024, ff4)!=NULL)
                {
                  fparse1(str2);
                  strcpy(str3, str2);
                  for (int i=0; i<strlen(str3); i++)
		  {
		    if (str3[i]==' ')
		    {
		      str3[i]=0;
		      break;
		    }
		  }
                }
              }
	    }
          }
	}
        fclose(ff4);
      }

      fprintf(ff1, "%20s = %16s\n", str1, str3);
      fflush(ff1);
    }
  }

  fclose(ff1);
  fclose(ff);
}

void fparse1(char* str)
{
  int i=strlen(str);
  if (i>0)
  {
    int found=0;
    for (int j=0; (j<i) && (found==0); j++)
    {
      if (str[j]=='\r' || str[j]=='\n')
      {
        str[j]=0;
	found=1;
      }
    }
  }
}
