/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include "fdatabase.h"
#include "ftransformations.h"
#include "futils.h"
#include "fids.h"
#include "param.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define _fff       "_finfo_funcs"     //file with the list of functions to transform
#define _ftr       "_finfo_tr"        //file with the list of transformations used
#define _fic       "_finfo_iter"      //current iteration
#define _fic_cur   ".cur"             //extension for current iteration
#define _fic_db    ".fdb"             //extension for transformation database
#define _fic_inf   ".info"            //extension for info
#define _fic_stat  ".stat"            //extension for statistics
#define _fic_tri1  ".tr_i1"           //extension for transformation info1
#define _fic_tri2  ".tr_i2"           //extension for transformation info2

char str1[1024];  //Not very clean, should change when have time
char str2[1024];

char db_r[1024];
char db_w[1024];

long findInArray(long fc, long* buf, long lbuf);
void sortArray(long* buf, long* buf1, long lbuf);

int main(int argc, char* argv[])
{
  FILE* fil;
  
  long iter=0;

  printf("FCO Statistics   V1.00   (C) by Grigori G.Fursin   January,2006\n");

  if (argc<=1) iter=0;
  else iter=atol(argv[1]);

  printf("\n");
  printf("Gathering statistics for the iteration %u ...\n", iter);

  sprintf(db_r, _fic ".%06u" _fic_db, iter);
  sprintf(db_w, _fic "");
  sprintf(str1, _fic ".%06u" _fic_stat, iter);

  if ((fil=fopen(str1, "w"))==NULL)
  {
    printf("\nError: Can't open file for writing\n");
    exit(1);
  }

  long tr_max=findNumberOfTransformations(db_r);
  fprintf(fil, "transformation_records_all=%u\n", tr_max);
  long tr_max1=0;

  long trx=1;    

  int lbuf=2048;
  //list of transformation_records and real transformations
  long tr_unroll_fully_c=0;
  long tr_unroll_c=0;
  long tr_unroll_p[lbuf];
  long tr_unroll_pc[lbuf];
  long tr_unroll_pl=0;
  long tr_pf_c=0;
  long tr_pf_p[lbuf];
  long tr_pf_pc[lbuf];
  long tr_pf_pl=0;
  long tr_inline_c=0;
  long tr_fusion_c=0;
  long tr_fission_c=0;
  long tr_simd_c=0;
  long tr_simd_p1[lbuf];
  long tr_simd_p1c[lbuf];
  long tr_simd_p1l=0;
  long tr_simd_p2[lbuf];
  long tr_simd_p2c[lbuf];
  long tr_simd_p2l=0;
  long tr_simd_p3[lbuf];
  long tr_simd_p3c[lbuf];
  long tr_simd_p3l=0;
  long tr_pad_local_c=0;
  long tr_pad_global_c=0;
  long tr_pad_global_p[lbuf];
  long tr_pad_global_pc[lbuf];
  long tr_pad_global_pl=0;
  long tr_snl_c=0;
  long tr_i_c=0;
  long tr_rt_c=0;
  long tr_rt_p[lbuf];
  long tr_rt_pc[lbuf];
  long tr_rt_pl=0;
  long tr_ln_p[lbuf];
  long tr_ln_pc[lbuf];
  long tr_ln_pl=0;
  long tr_t_c=0;
  long tr_t_p1[lbuf];
  long tr_t_p1c[lbuf];
  long tr_t_p1l=0;
  long tr_t_p2[lbuf];
  long tr_t_p2c[lbuf];
  long tr_t_p2l=0;

  while(trx<=tr_max)
  {
    //to transform all functions, put "" instead of _fff
    int tr=0;
      
    setDBIO(db_r, db_w);
    tr=getTransformation(trx, _fff);

    if (tr>=0) 
    {
      if (tr==iid_tr_unroll)
      {
        tr_max1++;
        findLineFromCurrentTransformation(id_unroll_fully, str2);
        if (atoi(str2)==1)
	{
          tr_unroll_fully_c++;
	}
	else
	{
          tr_unroll_c++;
	  
          findLineFromCurrentTransformation(id_unroll_factor, str2);

          long fc=atol(str2);
	  
          long i=findInArray(fc, tr_unroll_p, tr_unroll_pl);
          if (i==-1)
	  {
            tr_unroll_p[tr_unroll_pl]=fc;
            tr_unroll_pc[tr_unroll_pl++]=1;
	  }
	  else
	  {
            tr_unroll_pc[i]++;
	  }
        }
      }
      else if (tr==iid_tr_inline)
      {
        findLineFromCurrentTransformation(id_status, str2);
        if (atoi(str2)==1)
	{
          tr_max1++;
          tr_inline_c++;
	}
      }
      else if (tr==iid_tr_ff)
      {
        findLineFromCurrentTransformation(id_status, str2);
        if (atoi(str2)==1)
	{
          tr_max1++;

          findLineFromCurrentTransformation(id_ff_type, str2);

          if  (atoi(str2)==0) tr_fusion_c++; else tr_fission_c++;
	}
      }
      else if (tr==iid_tr_simd)
      {
        findLineFromCurrentTransformation(id_status, str2);
        if (atoi(str2)==1)
	{
          findLineFromCurrentTransformation(id_simd_vectors, str2);

          long fc=atol(str2);
	  
          long i=findInArray(fc, tr_simd_p1, tr_simd_p1l);
          if (i==-1)
	  {
            tr_simd_p1[tr_simd_p1l]=fc;
            tr_simd_p1c[tr_simd_p1l++]=1;
	  }
	  else
	  {
            tr_simd_p1c[i]++;
	  }

          findLineFromCurrentTransformation(id_simd_ut, str2);

          fc=atol(str2);
	  
          i=findInArray(fc, tr_simd_p2, tr_simd_p2l);
          if (i==-1)
	  {
            tr_simd_p2[tr_simd_p2l]=fc;
            tr_simd_p2c[tr_simd_p2l++]=1;
	  }
	  else
	  {
            tr_simd_p2c[i]++;
	  }

          findLineFromCurrentTransformation(id_simd_atb, str2);

          fc=atol(str2);
	  
          i=findInArray(fc, tr_simd_p3, tr_simd_p3l);
          if (i==-1)
	  {
            tr_simd_p3[tr_simd_p3l]=fc;
            tr_simd_p3c[tr_simd_p3l++]=1;
	  }
	  else
	  {
            tr_simd_p3c[i]++;
	  }

          tr_max1++;
          tr_simd_c++;
	}
      }
      else if (tr==iid_tr_snl)
      {
        findLineFromCurrentTransformation(id_status, str2);
        if (atoi(str2)==1)
	{
          tr_max1++;
          tr_snl_c++;

          int n=getSNL_LoopNests(trx);
          int bs=getSNL_TilingStatus(trx);

          int i=findInArray(n, tr_ln_p, tr_ln_pl);
          if (i==-1)
          {
            tr_ln_p[tr_ln_pl]=n;
            tr_ln_pc[tr_ln_pl++]=1;
          }
          else
          {
            tr_ln_pc[i]++;
          }


          getTransformation(trx, _fff); //to init

          int interchange=0;          
          findLineFromCurrentTransformation(id_lnt_outer, str2);
          int lo=atoi(str1);
          for (int j=1; j<=n; j++)
          {
            findLineFromCurrentTransformationX(id_lnt_new_loop_order, str2, j-1);
            if ((atoi(str2)-lo+1)!=j) interchange=1;

            findLineFromCurrentTransformationX(id_lnt_new_reg_tiling, str2, j-1);
            long fc=atol(str2);
	  
            if (fc!=1)
	    {
              tr_rt_c++;
	      
              i=findInArray(fc, tr_rt_p, tr_rt_pl);
              if (i==-1)
              {
                tr_rt_p[tr_rt_pl]=fc;
                tr_rt_pc[tr_rt_pl++]=1;
  	      }
	      else
	      {
                tr_rt_pc[i]++;
	      }
            }
          }
          if (interchange!=0) tr_i_c++;

          if (bs!=0)
	  {
	    int b=getSNL_NumberOfTiles(trx);

            for (int j=1; j<=b; j++)
            {
              tr_t_c++;

              findLineFromCurrentTransformationX(id_lnt_loop_strip, str2, j-1);
              long fc=atol(str2);
	  
              tr_t_c++;
	      
              i=findInArray(fc, tr_t_p1, tr_t_p1l);
              if (i==-1)
              {
                tr_t_p1[tr_t_p1l]=fc;
                tr_t_p1c[tr_t_p1l++]=1;
  	      }
	      else
	      {
                tr_t_p1c[i]++;
	      }

              findLineFromCurrentTransformationX(id_lnt_cache_level, str2, j-1);
              fc=atol(str2);
	  
              i=findInArray(fc, tr_t_p2, tr_t_p2l);
              if (i==-1)
              {
                tr_t_p2[tr_t_p2l]=fc;
                tr_t_p2c[tr_t_p2l++]=1;
  	      }
	      else
	      {
                tr_t_p2c[i]++;
	      }
            }
          }
	}
      }
      else if (tr==iid_tr_pf)
      {
        findLineFromCurrentTransformation(id_status, str2);
        if (atoi(str2)==1)
	{
          tr_max1++;
          tr_pf_c++;

          findLineFromCurrentTransformation(id_pf_offset, str2);

          long fc=atol(str2);
	  
          long i=findInArray(fc, tr_pf_p, tr_pf_pl);
          if (i==-1)
	  {
            tr_pf_p[tr_pf_pl]=fc;
            tr_pf_pc[tr_pf_pl++]=1;
	  }
	  else
	  {
            tr_pf_pc[i]++;
	  }
	}
      }
      else if (tr==iid_tr_pad_global)
      {
        tr_max1++;
        tr_pad_global_c++;

        findLineFromCurrentTransformation(id_array_pad, str2);

        long fc=atol(str2);
	  
        long i=findInArray(fc, tr_pad_global_p, tr_pad_global_pl);
        if (i==-1)
        {
          tr_pad_global_p[tr_pad_global_pl]=fc;
          tr_pad_global_pc[tr_pad_global_pl++]=1;
        }
	else
	{
          tr_pad_global_pc[i]++;
	}
      }
      else if (tr==iid_tr_pad_local)
      {
        findLineFromCurrentTransformation(id_status, str2);
        if (atoi(str2)==1)
	{
          tr_max1++;
          tr_pad_local_c++;
	}
      }
    }

    trx++;
  }

  fprintf(fil, "transformations_on=%u\n", tr_max1);
  fprintf(fil, "\n");

  sortArray(tr_unroll_p, tr_unroll_pc, tr_unroll_pl);
  fprintf(fil, id_tr_unroll1_f "%u\n", tr_unroll_fully_c);
  fprintf(fil, "\n");

  fprintf(fil, id_tr_unroll1 "%u\n", tr_unroll_c);
  int i=0;
  for (i=0; i<tr_unroll_pl; i++) fprintf(fil, id_tr_unroll1buf "%u (factor=%u)\n", 
    tr_unroll_pc[i], tr_unroll_p[i]);
  fprintf(fil, "\n");

  fprintf(fil, id_tr_inline1 "%u\n", tr_inline_c);
  fprintf(fil, "\n");

  sortArray(tr_pf_p, tr_pf_pc, tr_pf_pl);
  fprintf(fil, id_tr_pf1 "%u\n", tr_pf_c);
  for (i=0; i<tr_pf_pl; i++) fprintf(fil, id_tr_pf1buf "%u (factor=%u)\n", 
    tr_pf_pc[i], tr_pf_p[i]);
  fprintf(fil, "\n");

  fprintf(fil, id_tr_fusion1 "%u\n", tr_fusion_c);
  fprintf(fil, "\n");

  fprintf(fil, id_tr_fission1 "%u\n", tr_fission_c);
  fprintf(fil, "\n");

  fprintf(fil, id_tr_simd1 "%u\n", tr_simd_c);
  sortArray(tr_simd_p1, tr_simd_p1c, tr_simd_p1l);
  sortArray(tr_simd_p2, tr_simd_p2c, tr_simd_p2l);
  sortArray(tr_simd_p3, tr_simd_p3c, tr_simd_p3l);
  for (i=0; i<tr_simd_p1l; i++) fprintf(fil, id_tr_simd1p1buf "%u (vector=%u)\n", 
    tr_simd_p1c[i], tr_simd_p1[i]);
  for (i=0; i<tr_simd_p2l; i++) fprintf(fil, id_tr_simd1p2buf "%u (unroll_times=%u)\n", 
    tr_simd_p2c[i], tr_simd_p2[i]);
  for (i=0; i<tr_simd_p3l; i++) fprintf(fil, id_tr_simd1p3buf "%u (add_to_base=%u)\n", 
    tr_simd_p3c[i], tr_simd_p3[i]);
  fprintf(fil, "\n");

  fprintf(fil, id_tr_pad_local1 "%u\n", tr_pad_local_c);
  fprintf(fil, "\n");

  sortArray(tr_pad_global_p, tr_pad_global_pc, tr_pad_global_pl);
  fprintf(fil, id_tr_pad_global1 "%u\n", tr_pad_global_c);
  for (i=0; i<tr_pad_global_pl; i++) fprintf(fil, id_tr_pad_global1buf "%u (factor=%u)\n", 
    tr_pad_global_pc[i], tr_pad_global_p[i]);
  fprintf(fil, "\n");

  sortArray(tr_ln_p, tr_ln_pc, tr_ln_pl);
  fprintf(fil, id_tr_snl1 "%u\n", tr_snl_c);
  for (i=0; i<tr_ln_pl; i++) fprintf(fil, id_tr_ln1buf "%u (nest=%u)\n", 
    tr_ln_pc[i], tr_ln_p[i]);
  fprintf(fil, "\n");

  fprintf(fil, id_tr_i1 "%u\n", tr_i_c);
  fprintf(fil, "\n");

  sortArray(tr_rt_p, tr_rt_pc, tr_rt_pl);
  fprintf(fil, id_tr_rt1 "%u\n", tr_rt_c);
  for (i=0; i<tr_rt_pl; i++) fprintf(fil, id_tr_rt1buf "%u (factor=%u)\n", 
    tr_rt_pc[i], tr_rt_p[i]);
  fprintf(fil, "\n");

  fprintf(fil, id_tr_t1 "%u\n", tr_t_c);
  sortArray(tr_t_p1, tr_t_p1c, tr_t_p1l);
  sortArray(tr_t_p2, tr_t_p2c, tr_t_p2l);
  for (i=0; i<tr_t_p1l; i++) fprintf(fil, id_tr_t1p1buf "%u (factor=%u)\n", 
    tr_t_p1c[i], tr_t_p1[i]);
  for (i=0; i<tr_t_p2l; i++) fprintf(fil, id_tr_t1p2buf "%u (cache_level=%u)\n", 
    tr_t_p2c[i], tr_t_p2[i]);
  fprintf(fil, "\n");

  fclose(fil);
  
  return 0;
}

long findInArray(long fc, long* buf, long lbuf)
{
  long ret=-1;

  for (int i=0; i<lbuf; i++)
  {
    if (buf[i]==fc)
    {
      ret=i;
      break;
    }
  }

  return ret;
}

/* fgg - bubble sort */
void sortArray(long* buf, long* buf1, long lbuf)
{
  for (int i=0; i<lbuf-1; i++)
  {
    for (int j=0; j<lbuf-i-1; j++)
    {
      if (buf[j+1]<buf[j])
      {
        long tmp=buf[j];
	buf[j]=buf[j+1];
	buf[j+1]=tmp;

        tmp=buf1[j];
	buf1[j]=buf1[j+1];
	buf1[j+1]=tmp;
      }
    }
  }
}
