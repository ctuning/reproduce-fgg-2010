/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#ifndef param_INCLUDED
#define param_INCLUDED

//opts
#define paramHelp         0 
#define paramVersion      1
#define paramVerbose      2
#define paramMTR          3
#define paramMIG          4
#define paramTT           5
#define paramTC           6
#define paramTR           7

#define ido_mtr            "mtr="
#define ido_mig            "mig="
#define ido_tt             "tt="
#define ido_tc             "tc="
#define ido_tr             "tr="

#define ido_tr_pf            "tr_pf="
#define ido_tr_pf_min        "tr_pf_min="
#define ido_tr_pf_max        "tr_pf_max="
#define ido_tr_pf_step       "tr_pf_step="
#define ido_tr_snl           "tr_snl="
#define ido_tr_interchange   "tr_interchange="
#define ido_tr_regt          "tr_snl_regt="
#define ido_tr_regt_min      "tr_snl_regt_min="
#define ido_tr_regt_max      "tr_snl_regt_max="
#define ido_tr_regt_step     "tr_snl_regt_step="
#define ido_tr_t             "tr_snl_t="
#define ido_tr_t_min         "tr_snl_t_min="
#define ido_tr_t_max         "tr_snl_t_max="
#define ido_tr_t_step        "tr_snl_t_step="
#define ido_tr_simd          "tr_simd="
#define ido_tr_unroll        "tr_unroll="
#define ido_tr_unroll_min    "tr_unroll_min="
#define ido_tr_unroll_max    "tr_unroll_max="
#define ido_tr_unroll_step   "tr_unroll_step="
#define ido_tr_ff            "tr_ff="
#define ido_tr_inline        "tr_inline="
#define ido_tr_pl            "tr_pad_local="
#define ido_tr_pl_min        "tr_pad_local_min="
#define ido_tr_pl_max        "tr_pad_local_max="
#define ido_tr_pl_step       "tr_pad_local_step="
#define ido_tr_pg            "tr_pad_global="
#define ido_tr_pg_min        "tr_pad_global_min="
#define ido_tr_pg_max        "tr_pad_global_max="
#define ido_tr_pg_step       "tr_pad_global_step="

#endif // param_INCLUDED

