/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include <stdio.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

long filelength (char* filename)
{
  struct stat *st;

  if (stat (filename, st) == -1)
  {
    return 0;
  }
  return st->st_size;
}

int main(int argc, char* argv[])
{
  long fl1=0;
  long fl2=0;

  char str1[1024];
  char str2[1024];

  if (argc!=3)
  {
    printf("Usage: fco_diff <file1> <file2>\n");
    return 1;
  }

  strcpy(str1, argv[1]);
  strcpy(str2, argv[2]);

  fl1=filelength(str1);
  fl2=filelength(str2);

  printf("");    //mistery - one some platforms if I delete
                 //this line, it causes segmentation fault...
  if (fl1!=fl2)
  {
    printf("Files have different size (%u vs %u)!\n", fl1, fl2);
    return 3;
  }

  return 0;
}
