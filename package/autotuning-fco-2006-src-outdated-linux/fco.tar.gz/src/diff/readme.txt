Since after some transformations the output is not the same
due to floating-point arithmetics precision and not due
to the illigality of these transformations, we need to compare
just the sizes of the output files and not the content.
This is a temporal walk around the problem on Athlon shuttles at INRIA.
