/*
 * Copyright (C) 2004-2006 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "futils.h"

#define _fcomp     "_fbcomp"              //compile batch file
#define _frun      "_fbrun"               //run batch file
#define _fcopy     "_fbcopy"              //copy1 batch file
#define _fdiff     "_fbdiff"              //diff1 batch file
#define _fclean1   "_fbclean1"            //clean std files
#define _fopts     "_finfo_opts"          //file with the list of options used
#define _fc        "_finfo_cmd_comp"      //file with compiler switches
#define _fcs       "_finfo_cmd_comp.std"  //file with compiler switches (std)
#define _fext      ".opt"                  
#define _fic       "_finfo_iter"          //current iteration
#define _fic_cur   ".cur"                 //extension for current iteration
#define _fic_db    ".fdb"                 //extension for transformation database
#define _fic_tim   ".time"                //extension for time (run)
#define _fic_timc  ".timec"               //extension for time (compilation)
#define _fic_inf   ".info"                //extension for info
#define _fic_tri1  ".tr_i1"               //extension for transformation info1
#define _fic_tri2  ".tr_i2"               //extension for transformation info2
#define _fout      "a.out"                //exe file
#define _ftime     "ftmp_time"            //file with time (run)
#define _ftimec    "ftmp_timec"           //file with time (compilation)
#define _ftmp_diff "ftmp_diff"            //file with diff

char str1[1024];
char str2[1024];
char str3[1024];
char stropt[1024];

void writeRep(char* name, double tt, long iter);
void copy_str(char* stro, char* stri, int j);

#define sep1 "==============================================================================="
#define sep2 "-------------------------------------------------------------------------------"
#define sep_tr "================================================================================"

#define rand_seed 12345
#define rand_max      4
#define rand_sel1     2
#define rand_sel2     6

int main(int argc, char* argv[])
{
  FILE* f;
  FILE* f1;
  
  long iter, iterM;
  double t1, t2, tt;
  double t1x, t2x;
  int ls;
  int i;
  int l;

  int iv, iv_min, iv_max;

  int param;

  double _ftime_threshold=2.0;

  char opts[16384];
  int iopts[1024];
  int iused[1024];
  int ioptsm=0;
  int ix=0;

  int mode=0;
  int found=0;

  /********************************************************************/
  printf("FCO OPT\n");

  ls=1;
  iterM=32767;
  if (argc>=2) ls=atoi(argv[1]);
  if (argc>=3) iterM=atoi(argv[2]);

  iter=readLastIteration(_fic _fic_cur);
  iter++;

  if (iter==0)
  {
    printf(sep1 "\n");
    printf("Mode: first run ...\n");

    system("cp " _fc " " _fcs);

    printf("\n");

    printf("Clean std files ...\n");
    system(_fclean1);

    printf("Compile program ...\n");
    system(_fcomp);

    t1=getTime1(_ftimec);
    t2=getTime2(_ftimec);
    tt=t1+t2;
    printf("Compile Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    sprintf(str2, _fic ".%06u" _fic_timc, 0);
    writeTime(str2, t1, t2);

    if (fileExist(_fout)!=1)
    {
      printf("Error: Executable is not created!\n");
      exit(1);
    }

    printf("Run program (1) ...\n");
    system(_frun);

    t1x=getTime1(_ftime);
    t2x=getTime2(_ftime);

    printf("Run program (2) ...\n");
    system(_frun);

    t1=getTime1(_ftime);
    t2=getTime2(_ftime);
    tt=t1+t2;
    printf("Run Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    sprintf(str2, _fic ".%06u" _fic_tim, iter);
    writeTime1(str2, t1, t2, t1x, t2x);

    printf("Copy std files ...\n");
    system(_fcopy);

    printf("\n");
    
    writeIteration(_fic _fic_cur, iter);
    iter++;
  }
  else
  {
    printf("Mode: continuous optimizations\n");
    printf("      last iteration=%u\n", iter-1);
  }

  //read file with std options
  f = fopen (_fcs, "r");
  if (f!=NULL)
  {
    if (fgets(str1, 1023, f)!=NULL)
    {
      fparse1(str1);
      strcpy(stropt, str1);
    }
    else
    {
      printf("\nError: Can't read file with standard compiler switches!\n");
      exit(1);
    }
    fclose(f);
  }
  else
  {
    printf("\nError: Can't find file with standard compiler switches!\n");
    exit(1);
  }

  //read options
  f = fopen (_fopts, "r");
  if (f!=NULL)
  {
    ioptsm=0;
    ix=0;
    while ((fgets(str1, 1023, f)!=NULL) && (feof(f)==0))
    {
      fparse1(str1);

      if (strlen(str1)==0)
      {
        printf("\nError: Inconsistent file with switches!\n");
        exit(1);
      }

      strcpy(&opts[ix], str1);
      iopts[ioptsm]=ix;
      ioptsm++;
      ix+=strlen(str1)+1;
    }
    fclose (f1);
  }
  else
  {
    printf("Error: Can't write file with command line switches!\n");
    exit(1);
  }

  if (ls==0) {ls=ioptsm; mode=1;}
  
  printf("\n");
  printf("Length of the sequence: %u\n", ls);
  printf("Number of iterations: %u\n", iterM);

  srand(rand_seed);

  //start iterations
  while (iter<=iterM)
  {
    printf(sep1 "\n");
    printf("Iteration: %u ...\n", iter);
  
    //prepare opt file
    f1 = fopen (_fc, "w");
    if (f1!=NULL)
    {
      fprintf(f1, "%s", stropt);

      for (i=0; i<ioptsm; i++) iused[i]=0;

      for (l=0; l<ls; l++)
      {
        if (mode==1) iused[l]=1;
	else
	{
          found=0;
	  while (found==0)
	  {
            param=rand() % ioptsm;
            if (iused[param]==0)
	    {
              found=1;
              iused[param]=1;
	    }
	  }
	}
      }
      
      for (i=0; i<ioptsm; i++)
      {
        if (iused[i]==1)
	{
          strcpy(str1, &opts[iopts[i]]);
	  	  
          strcpy(str2, "");
          if (str1[0]=='2')
          {
            if (mode==1)
	    {
              param=rand() % rand_sel1;
              if (param==1)
              {
                copy_str(str2, str1, 2);
              }
	    }
            else
	    {
              copy_str(str2, str1, 2);
	    }

          }
          else if (str1[0]=='1')
          {
            int j=2;
            int k=0;
            strcpy(str3, "");
            for (; j<strlen(str1); j++)
  	    {
	      if (str1[j]==',') break;
              else str3[k++]=str1[j];
	    }
	    if (j==strlen(str1))
	    {
              printf("\nError: Inconsistent file with switches!\n");
  	      exit(1);
	    }
            str3[k]=0;
            iv_min=atoi(str3);
            j++;

            k=0;
            strcpy(str3, "");
            for (; j<strlen(str1); j++)
	    {
	      if (str1[j]==',') break;
              else str3[k++]=str1[j];
	    }
	    if (j==strlen(str1))
	    {
              printf("\nError: Inconsistent file with switches!\n");
  	      exit(1);
	    }
            str3[k]=0;
            iv_max=atoi(str3);
	    j++;
 
            copy_str(str2, str1, j);

            iv=iv_min + (rand() % (rand_max)) * (iv_max-iv_min+1) / rand_max;
	    
	    sprintf(str3, "%d", iv);
            strcat(str2, str3);
          }
          else if (str1[0]=='0')
  	  {
            copy_str(str2, str1, 2);
            param=rand() % rand_sel1;
            if (param==1) strcat(str2, "on");
  	    else          strcat(str2, "off");
	  }
  	  else
	  {
            printf("\nError: Inconsistent file with switches!\n");
	    exit(1);
	  }
        
          fprintf(f1, "%s", str2);
        }
      }
      
      fprintf(f1, "\n");
      fclose (f1);
    }
    else
    {
      printf("Error: Can't write file with command line switches!\n");
      exit(1);
    }
  
    sprintf(str1, _fic ".%06u" _fext, iter);
    copyFile(_fc, str1);

    printf("Compile program ...\n");
    system(_fcomp);

    t1=getTime1(_ftimec);
    t2=getTime2(_ftimec);
    tt=t1+t2;
    printf("Compile Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

    sprintf(str2, _fic ".%06u" _fic_timc, iter);
    writeTime(str2, t1, t2);
    
    if (fileExist(_fout)!=1)
    {
      printf("Warning: a.out is not created!\n");

      sprintf(str2, _fic ".%06u" _fic_inf, iter);
      writeIterStatus(str2, 0, 0, 0);
    }
    else
    {
      printf("Run program (1) ...\n");
      system(_frun);

      t1x=getTime1(_ftime);
      t2x=getTime2(_ftime);

      printf("Run program (2) ...\n");
      system(_frun);

      printf("\n");
  
      t1=getTime1(_ftime);
      t2=getTime2(_ftime);
      tt=t1+t2;
      printf("Run Time: user=(%6.1f), sys=(%6.1f), total=(%6.1f)\n", t1, t2, tt);

      sprintf(str2, _fic ".%06u" _fic_tim, iter);
      writeTime1(str2, t1, t2, t1x, t2x);

      int inf1=1;
      int inf2=1;
	
      printf("\n");
      if (tt<_ftime_threshold)
      {
        inf1=0;
        printf("Warning: Execution time too low!\n");
      }
      if (fileDiffCorrect(_fdiff, _ftmp_diff)!=1)
      {
        int inf2=0;
        printf("Warning: Output is different from the original!\n");
      }

      sprintf(str2, _fic ".%06u" _fic_inf, iter);
      writeIterStatus(str2, 1, inf1, inf2);
    }      
      
    printf("\n");

    writeIteration(_fic _fic_cur, iter);
    iter++;
  }
}

void writeRep(char* name, double tt, long iter)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "at"))!=NULL)
  {
    fprintf(fil, "%20f %6u", tt, iter);
    fclose(fil);
  }
}

void copy_str(char* stro, char* stri, int j)
{
  int i;
  for (i=j; i<=strlen(stri); i++) stro[i-j]=stri[i];
}
