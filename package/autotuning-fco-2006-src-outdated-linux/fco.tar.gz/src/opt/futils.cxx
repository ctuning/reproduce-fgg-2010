/*
 * Copyright (C) 2004-2005 by Grigori G.Fursin
 *
 * http://homepages.inf.ed.ac.uk/gfursin
 *
 * INRIA Futurs, France
 * and ICSA, University of Edinburgh, UK
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char stra1[1024];

void setFComp(char* name, int mode, char* fr, char* fw)
{
  FILE* fil=NULL;
  
  if (mode==0) remove(name);
  else
  {
    if ((fil=fopen(name, "w"))!=NULL)
    {
      fprintf(fil, "%u\n", mode);
      if (strcmp(fr, "")!=0)
      {
        fprintf(fil, "%s\n", fr);
        if (strcmp(fw, "")!=0)
        {
          fprintf(fil, "%s\n", fw);
	}
      }
                
      fclose(fil);
    }
    if ((mode==2) || (mode==4)) remove(fw); //w or rw
  }
}

double getTime1(char* name)
{
  FILE* fil=NULL;
  double ret=0;
  char str1[1024];

  if ((fil=fopen(name, "r"))!=NULL)
  {
    fgets(str1, 1023, fil);
    ret=atof(str1);
    fclose(fil);
  }

  return ret;
}

double getTime2(char* name)
{
  FILE* fil=NULL;
  double ret=0;
  char str1[1024];

  if ((fil=fopen(name, "r"))!=NULL)
  {
    fgets(str1, 1023, fil);
    fgets(str1, 1023, fil);
    ret=atof(str1);
    fclose(fil);
  }

  return ret;
}

int fileExist(char* name)
{
  FILE* fil=NULL;
  int ret=0;

  if ((fil=fopen(name, "r"))!=NULL)
  {
    ret=1;
    fclose(fil);
  }

  return ret;
}

int fileDiffCorrect(char* bat, char* name)
{
  FILE* fil=NULL;
  int ret=0;
  char str1[1024];

  system(bat);

  if ((fil=fopen(name, "r"))!=NULL)
  {
    if (fgets(str1, 1023, fil)==NULL) ret=1;
    if (strcmp(str1,"")==0) ret=1;
    if (feof(fil)!=0) ret=1;
    fclose(fil);
  }

  return ret;
}

long readLastIteration(char* name)
{
  FILE* fil=NULL;
  long ret=-1;
  char str1[1024];

  if ((fil=fopen(name, "r"))!=NULL)
  {
    if ((feof(fil)==0) && (fgets(str1, 1023, fil)!=NULL))
    {
      ret=atol(str1);
    }
    fclose(fil);
  }

  return ret;
}

long readLastIterationS(char* name)
{
  FILE* fil=NULL;
  long ret=-1;
  char str1[1024];

  if ((fil=fopen(name, "r"))!=NULL)
  {
    if ((feof(fil)==0) && (fgets(str1, 1023, fil)!=NULL))
    {
      if ((feof(fil)==0) && (fgets(str1, 1023, fil)!=NULL))
      {
        ret=atol(str1);
      }
    }
    fclose(fil);
  }

  return ret;
}

void writeIteration(char* name, long mode)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "w"))!=NULL)
  {
    fprintf(fil, "%lu\n", mode);
    fclose(fil);
  }
}

void writeIterationS(char* name, long mode, long mode1)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "w"))!=NULL)
  {
    fprintf(fil, "%lu\n", mode);
    fprintf(fil, "%lu\n", mode1);
    fclose(fil);
  }
}

void writeTime(char* name, double t1, double t2)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "w"))!=NULL)
  {
    fprintf(fil, "%f\n", t1);
    fprintf(fil, "%f\n", t2);
    fclose(fil);
  }
}

void writeTime1(char* name, double t1, double t2, double t1x, double t2x)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "w"))!=NULL)
  {
    fprintf(fil, "%f\n", t1);
    fprintf(fil, "%f\n", t2);
    fprintf(fil, "%f\n", t1x);
    fprintf(fil, "%f\n", t2x);
    fclose(fil);
  }
}

void writeIterStatus(char* name, int inf0, int inf1, int inf2)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "w"))!=NULL)
  {
    fprintf(fil, "%d ;executable is created\n", inf0);
    fprintf(fil, "%d ;time is not too low\n", inf1);
    fprintf(fil, "%d ;output is correct\n", inf2);
    fclose(fil);
  }
}

void cleanFile(char* name)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "w"))!=NULL)
  {
    fclose(fil);
  }
}

void writeInfo(char* name, char* str)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "w"))!=NULL)
  {
    fprintf(fil, "%s", str);
    fclose(fil);
  }
}

void appendOut(char* name, char* str)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "a"))!=NULL)
  {
    fprintf(fil, "%s\n", str);
    fclose(fil);
  }
}

void appendOutPrint(char* name, char* str)
{
  FILE* fil=NULL;

  if ((fil=fopen(name, "a"))!=NULL)
  {
    fprintf(fil, "%s", str);
    printf("%s", str);
    fclose(fil);
  }
}

void fparse(char* str)
{
  int i=strlen(str);
  if (i>0)
  {
    int found=0;
    for (int j=0; (j<i) && (found==0); j++)
    {
      if (str[j]==' '  || str[j]=='\r' || str[j]=='\n')
      {
        str[j]=0;
	found=1;
      }
    }
  }
}

void fparse1(char* str)
{
  int i=strlen(str);
  if (i>0)
  {
    int found=0;
    for (int j=0; (j<i) && (found==0); j++)
    {
      if (str[j]=='\r' || str[j]=='\n')
      {
        str[j]=0;
	found=1;
      }
    }
  }
}

int copyFile(char* fin, char* fout)
{
  int ret=0;
  FILE* f1=NULL;
  FILE* f2=NULL;
  
  if ((f1=fopen(fin, "r"))==NULL) return -1;

  if ((f2=fopen(fout, "w"))==NULL)
  {
    fclose(f1);
    return -2;
  }

  while ((fgets(stra1, 1023, f1)!=NULL) && (feof(f1)==0))
  {
    fputs(stra1, f2);
  }

  fclose(f1);
  fclose(f2);

  return ret;
}
