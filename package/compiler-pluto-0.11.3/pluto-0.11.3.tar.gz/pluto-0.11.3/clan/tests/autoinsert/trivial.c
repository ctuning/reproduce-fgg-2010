int i, *A;

for (i = 1; i < N; i++)
  A[i] = A[i - 1];

