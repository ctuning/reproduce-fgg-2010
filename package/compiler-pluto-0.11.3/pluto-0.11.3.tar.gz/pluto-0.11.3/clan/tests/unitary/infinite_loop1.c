#pragma scop
while (1)
  S1();
#pragma endscop
