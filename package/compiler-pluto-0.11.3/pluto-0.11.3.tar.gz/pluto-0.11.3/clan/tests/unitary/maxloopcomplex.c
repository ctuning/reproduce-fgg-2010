#pragma scop
for (i = max(max(m,n),max(p,q)); i < n; ++i)
  a = 0;
#pragma endscop
