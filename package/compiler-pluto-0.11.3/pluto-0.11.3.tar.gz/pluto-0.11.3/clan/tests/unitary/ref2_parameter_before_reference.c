#pragma scop
for (i = 0; i < n ; i++)
  a = n;
#pragma endscop

