#pragma scop
if (M > N)
  a;
if (M <= N)
  b;
#pragma endscop
