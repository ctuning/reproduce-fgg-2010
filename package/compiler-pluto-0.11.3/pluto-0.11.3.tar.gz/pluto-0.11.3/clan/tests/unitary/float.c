#pragma scop
a = 0.6f;
b = 120.7234234E1;
c = 4.0;
d = 5;
#pragma endscop
