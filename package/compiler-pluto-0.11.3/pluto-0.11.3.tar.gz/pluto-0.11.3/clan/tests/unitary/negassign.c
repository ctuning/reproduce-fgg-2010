#pragma scop
for (k=1; k < N; k++)
  {
    alpha = -sum;
  }
#pragma endscop
