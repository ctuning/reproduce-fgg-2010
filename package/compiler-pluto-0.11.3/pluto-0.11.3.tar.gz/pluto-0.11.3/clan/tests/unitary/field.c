#pragma scop
for (i = 0; i < N; ++i) {
  a.b = c;
}
c.d = a.b;
#pragma endscop
