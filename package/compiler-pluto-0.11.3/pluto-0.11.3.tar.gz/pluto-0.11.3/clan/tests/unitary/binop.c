#pragma scop
a += b;
--a;
b++;
#pragma endscop
