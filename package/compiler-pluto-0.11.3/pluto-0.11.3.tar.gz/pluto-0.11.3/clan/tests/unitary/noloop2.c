#pragma scop
a;
b;
#pragma endscop
