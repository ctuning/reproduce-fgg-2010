#pragma scop
if (M > N && M > Q)
  if (Q > P)
    a;
b;
if (M > P)
  c;
#pragma endscop
