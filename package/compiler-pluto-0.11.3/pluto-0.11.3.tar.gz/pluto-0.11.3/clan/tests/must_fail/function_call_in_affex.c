#pragma scop
for (i = f(n); i < n; ++i)
  a = 0;
#pragma endscop
