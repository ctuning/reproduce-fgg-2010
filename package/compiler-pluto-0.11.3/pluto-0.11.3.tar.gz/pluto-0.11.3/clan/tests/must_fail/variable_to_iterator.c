#pragma scop
i = 0;
for (i = 0; i < n ; i++)
  a = i;
#pragma endscop

