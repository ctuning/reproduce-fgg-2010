#pragma scop
for (i = 0; i < n ; i++)
  i = n;
#pragma endscop

