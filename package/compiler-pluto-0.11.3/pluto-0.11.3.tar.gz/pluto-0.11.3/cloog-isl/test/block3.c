/* Generated from ../../../git/cloog/test/block3.cloog by CLooG 0.16.2-4-gba4e834 gmp bits in 0.00s. */
S1();
S3(0);
S2();
S3(1);
