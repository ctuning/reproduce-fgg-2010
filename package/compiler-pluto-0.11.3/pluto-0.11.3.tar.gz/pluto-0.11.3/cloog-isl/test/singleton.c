/* Generated from /home/skimo/git/cloog/test/singleton.cloog by CLooG 0.14.0-242-g720faff gmp bits in 0.00s. */
S2();
S1();
