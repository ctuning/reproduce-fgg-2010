/* Generated from ./multi-stride2.cloog by CLooG 0.18.1-2-g43fc508 gmp bits in 0.00s. */
for (i=5;i<=100;i+=6) {
  S1(i,((i-1)/2),((i-2)/3));
}
