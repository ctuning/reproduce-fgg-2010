/* Generated from ./mod4.cloog by CLooG 0.18.1-2-g43fc508 gmp bits in 0.00s. */
for (j=2;j<=10;j+=3) {
  S1(j,((j+1)/3),((j+1)/3),2,((j-2)/3));
  S2(j,((j+1)/3),((j+1)/3),2,((j-2)/3));
  S3(j,((j+1)/3),((j+1)/3),2,((j-2)/3));
}
