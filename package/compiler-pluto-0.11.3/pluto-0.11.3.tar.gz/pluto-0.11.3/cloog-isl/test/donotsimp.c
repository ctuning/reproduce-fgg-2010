/* Generated from ../../../git/cloog/test/donotsimp.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.01s. */
for (c2=1;c2<=10;c2++) {
  for (c4=1;c4<=c2;c4++) {
    S1(c2,c4) ;
  }
  for (c4=11;c4<=M;c4++) {
    S2(c2,c4) ;
  }
}
