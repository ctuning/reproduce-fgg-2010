/* Generated from /home/skimo/git/cloog/test/block.cloog by CLooG 0.14.0-170-g72daac3 gmp bits in 0.00s. */
S1();
S3(0);
S2();
S3(1);
