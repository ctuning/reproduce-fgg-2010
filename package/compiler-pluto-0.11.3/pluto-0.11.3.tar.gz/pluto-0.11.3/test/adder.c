CONSTANT n;

for (i=0; i<=n-1; i++)
{
  for (j=0; j<=min(n-1, i+2); j++)
	PS[i] = PS[i] + A[i,j]
  TS = TS + PS[i]
}
