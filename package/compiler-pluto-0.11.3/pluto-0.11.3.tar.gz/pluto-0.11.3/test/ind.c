 constant N;

 i1 = 4;

 for (i=0; i<N; i++)    {
     a[i1] = a[i-1] + 1;
 }
