constant n, m;

a[10] = 5;

do i = 1, n
    a[i] = a[i+n+1];
end do
