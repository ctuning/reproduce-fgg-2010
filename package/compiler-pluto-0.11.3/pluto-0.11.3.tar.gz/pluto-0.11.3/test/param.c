
/* pluto start (N, M) */

for (i=0; i<N; i++) 
{
    a[i] = 5;
    a[i] = 1;
}

/* pluto end */
