/* pluto start (N) */

DO i=1, N
      s = s +  a[i]
END DO

DO i=1, N
      s = s +  a[i]
END DO

DO i=1, N
      s = s +  a[i]
END DO

DO i=1, N
      s = s +  a[i]
END DO
/* pluto end */
