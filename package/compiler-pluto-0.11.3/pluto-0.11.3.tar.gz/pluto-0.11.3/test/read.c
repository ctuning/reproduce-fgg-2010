
constant n;

do i = 1, n
c[i] = a[i] + b[i];
end do

do j = 1, n
d[i] = a[i] + b[i];
end do
